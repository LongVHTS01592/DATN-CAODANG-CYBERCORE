package entity;

import java.sql.Timestamp;

public class Banner {
    private int bannerID;
    private String title;
    private String imageURL;
    private String position;
    private String targetLink;
    private Timestamp startDate;
    private Timestamp endDate;
    private boolean isActive;
    private Timestamp createdAt;

    public Banner() {
    }

    // Getters and Setters
    public int getBannerID() { return bannerID; }
    public void setBannerID(int bannerID) { this.bannerID = bannerID; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getImageURL() { return imageURL; }
    public void setImageURL(String imageURL) { this.imageURL = imageURL; }

    public String getPosition() { return position; }
    public void setPosition(String position) { this.position = position; }

    public String getTargetLink() { return targetLink; }
    public void setTargetLink(String targetLink) { this.targetLink = targetLink; }

    public Timestamp getStartDate() { return startDate; }
    public void setStartDate(Timestamp startDate) { this.startDate = startDate; }

    public Timestamp getEndDate() { return endDate; }
    public void setEndDate(Timestamp endDate) { this.endDate = endDate; }

    // DÀNH CHO JAVA (DAO/Controller) GỌI KHÔNG BỊ ĐỎ
    public boolean isActive() { return isActive; }

    // DÀNH CHO TOMCAT (JSP EL) ĐỌC KHÔNG BỊ LỖI 500
    public boolean getIsActive() { return isActive; }

    public void setActive(boolean active) { this.isActive = active; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}