package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Review {
    private int reviewID;
    private int userID;
    private int productID;
    private User user;
    private Product product;
    private int rating;
    private String comment;
    private Timestamp createdAt;
    private String username;

    // THÊM DÒNG NÀY VÀO ĐỂ HẾT BỊ ĐỎ TRONG CONTROLLER
    private String avatarText;
}