package entity;

public class RevenueReport {
    private int reportYear;
    private int reportMonth;
    private double totalRevenue;
    private int totalOrders;

    // Constructor để khởi tạo đối tượng
    public RevenueReport(int reportYear, int reportMonth, double totalRevenue, int totalOrders) {
        this.reportYear = reportYear;
        this.reportMonth = reportMonth;
        this.totalRevenue = totalRevenue;
        this.totalOrders = totalOrders;
    }

    // Getters và Setters để truy xuất dữ liệu
    public int getReportYear() { return reportYear; }
    public void setReportYear(int reportYear) { this.reportYear = reportYear; }

    public int getReportMonth() { return reportMonth; }
    public void setReportMonth(int reportMonth) { this.reportMonth = reportMonth; }

    public double getTotalRevenue() { return totalRevenue; }
    public void setTotalRevenue(double totalRevenue) { this.totalRevenue = totalRevenue; }

    public int getTotalOrders() { return totalOrders; }
    public void setTotalOrders(int totalOrders) { this.totalOrders = totalOrders; }
}
