package com.tuanphat.entity;

import java.sql.Timestamp;

public class SystemLog {
    private int logID;
    private Integer userID;
    private String logLevel;
    private String logMessage;
    private Timestamp createdAt;

    public SystemLog() {}

    public int getLogID() { return logID; }
    public void setLogID(int logID) { this.logID = logID; }

    public Integer getUserID() { return userID; }
    public void setUserID(Integer userID) { this.userID = userID; }

    public String getLogLevel() { return logLevel; }
    public void setLogLevel(String logLevel) { this.logLevel = logLevel; }

    public String getLogMessage() { return logMessage; }
    public void setLogMessage(String logMessage) { this.logMessage = logMessage; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
}