package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart {
    private int cartID;
    private int userID;
    private Timestamp createdAt;
    private Timestamp updatedAt;
    private List<CartDetail> details; // Lưu ý: Cần có file Entity CartDetail.java tương ứng
}