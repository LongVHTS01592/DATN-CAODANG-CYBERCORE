package servlet;

import dao.BrandDAO;
import dao.CategoryDAO;
import dao.ProductDAO;
import entity.Brand;
import entity.Category;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/StaffProductController")
public class StaffProductController extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BrandDAO brandDAO = new BrandDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        // Xử lý các luồng thao tác (Thêm/Sửa/Cập nhật kho)
        if ("add".equals(action)) {
            response.getWriter().println("Chức năng: Nhập linh kiện mới");
            return;
        } else if ("edit".equals(action)) {
            String id = request.getParameter("id");
            response.getWriter().println("Chức năng: Sửa linh kiện mã số #" + id);
            return;
        } else if ("updateStock".equals(action)) {
            String id = request.getParameter("id");
            response.getWriter().println("Chức năng: Cập nhật số kho cho mã số #" + id);
            return;
        }

        // --- ĐỔ DỮ LIỆU CHO BỘ LỌC SEARCH CHỌN ---
        List<Category> categoriesList = categoryDAO.findAll();
        List<Brand> brandsList = brandDAO.findAll();
        request.setAttribute("categories", categoriesList);
        request.setAttribute("brands", brandsList);

        // Đọc các bộ lọc tìm kiếm
        String searchKeyword = request.getParameter("search");
        String categoryIdParam = request.getParameter("category");
        String brandIdParam = request.getParameter("brand");

        List<Product> productsList;

        if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            productsList = productDAO.searchByName(searchKeyword.trim());
            request.setAttribute("selectedSearch", searchKeyword);
        } else if (categoryIdParam != null && !categoryIdParam.trim().isEmpty()) {
            int categoryId = Integer.parseInt(categoryIdParam);
            productsList = productDAO.findByCategory(categoryId);
            request.setAttribute("selectedCat", categoryId);
        } else if (brandIdParam != null && !brandIdParam.trim().isEmpty()) {
            int brandId = Integer.parseInt(brandIdParam);
            productsList = productDAO.findByBrand(brandId);
            request.setAttribute("selectedBrand", brandId);
        } else {
            productsList = productDAO.findAll();
        }

        // Đẩy danh sách sản phẩm thật và chuyển tiếp sang JSP
        request.setAttribute("products", productsList);
        request.getRequestDispatcher("/staff/staff_product.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}