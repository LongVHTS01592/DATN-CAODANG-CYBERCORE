package servlet;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "PaymentWebhookServlet", value = "/api/payment-webhook")
public class PaymentWebhookServlet extends HttpServlet {

    // Thay thế printStackTrace() bằng Logger chuẩn theo khuyến nghị bảo mật
    private static final Logger LOGGER = Logger.getLogger(PaymentWebhookServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }
        String payload = buffer.toString();

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(payload);

            long orderCode = rootNode.path("data").path("orderCode").asLong();

            if (payload.contains("\"success\":true") || payload.contains("isSuccess")) {
                LOGGER.info("============== CYBERCORE PAYMENT SUCCESS ==============");
                LOGGER.info("DON HANG MA SO: " + orderCode + " DA THANH TOAN THANH CONG REALTIME!");
                LOGGER.info("=======================================================");

                // OrderDAO orderDAO = new OrderDAO();
                // orderDAO.updateStatus(orderCode, "Đã thanh toán");
            }

            response.setStatus(HttpServletResponse.SC_OK);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"status\": \"success\"}");

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Loi xu ly dữ liệu webhook từ PayOS", e);
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        response.getWriter().println("Phuong thuc khong duoc ho tro.");
    }
}