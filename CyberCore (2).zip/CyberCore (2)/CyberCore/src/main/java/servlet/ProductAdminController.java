package servlet;

import dao.ProductDAO;
import dao.CategoryDAO;
import dao.SystemLogDAO; // IMPORT DAO LOG
import entity.Product;
import entity.Category;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.util.List;

@WebServlet("/ProductAdminController")
public class ProductAdminController extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT ADMIN
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                productDAO.delete(Integer.parseInt(idStr));

                // GHI LOG: XÓA SẢN PHẨM
                SystemLogDAO logDAO = new SystemLogDAO();
                int adminId = user.getUserID();
                logDAO.insertLog(adminId, "ERROR", "CẢNH BÁO: Admin đã xóa vĩnh viễn linh kiện ID #" + idStr);
            }
            response.sendRedirect(request.getContextPath() + "/ProductAdminController");
            return;
        } else if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                Product p = productDAO.findById(Integer.parseInt(idStr));
                request.setAttribute("productEdit", p);
            }
        }

        List<Product> products = productDAO.findAll();
        request.setAttribute("products", products);

        List<Category> categories = categoryDAO.findAll();
        request.setAttribute("categories", categories);

        request.getRequestDispatcher("/admin/admin_product.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        String name = request.getParameter("productName");
        String categoryIdStr = request.getParameter("categoryID");
        String brandIdStr = request.getParameter("brandID");
        String originalPriceStr = request.getParameter("originalPrice");
        String sellPriceStr = request.getParameter("sellPrice");
        String imgUrl = request.getParameter("mainImageURL");
        String warrantyStr = request.getParameter("warrantyMonths");
        String statusStr = request.getParameter("status");
        String desc = request.getParameter("description");

        // Lấy thông tin Admin đang thao tác để ghi Log
        HttpSession session = request.getSession();
        User admin = (User) session.getAttribute("userAccount");
        Integer adminId = (admin != null) ? admin.getUserID() : null; // <--- Đổi int thành Integer, đổi 0 thành null
        SystemLogDAO logDAO = new SystemLogDAO();

        // ====================================================================================
        // THUẬT TOÁN TẢI ẢNH CHỐNG CHẶN & LỌC SẠCH KÝ TỰ ĐẶC BIỆT CỦA WINDOWS (FIX DỨT ĐIỂM)
        // ====================================================================================
        String finalImageName = imgUrl;

        if (imgUrl != null && (imgUrl.startsWith("http://") || imgUrl.startsWith("https://"))) {
            InputStream in = null;
            try {
                String cleanUrl = imgUrl;
                if (cleanUrl.contains("?")) {
                    cleanUrl = cleanUrl.substring(0, cleanUrl.indexOf("?"));
                }

                String fileNameFromUrl = cleanUrl.substring(cleanUrl.lastIndexOf("/") + 1);
                fileNameFromUrl = fileNameFromUrl.replaceAll("[\\\\/:*?\"<>|]", "_");

                if (fileNameFromUrl.trim().isEmpty() || !fileNameFromUrl.contains(".")) {
                    fileNameFromUrl = "downloaded_image.jpg";
                }

                finalImageName = System.currentTimeMillis() + "_" + fileNameFromUrl;

                String pathVoiGoc = "C:\\Users\\longv\\IdeaProjects\\CyberCore\\src\\main\\webapp\\images";
                String pathTomcat = getServletContext().getRealPath("/images");

                java.net.HttpURLConnection connection = (java.net.HttpURLConnection) new URL(imgUrl).openConnection();
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
                connection.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);

                int responseCode = connection.getResponseCode();
                if (responseCode >= 200 && responseCode < 300) {
                    in = connection.getInputStream();
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int bytesRead;
                    while ((bytesRead = in.read(buffer)) != -1) {
                        baos.write(buffer, 0, bytesRead);
                    }
                    byte[] imageBytes = baos.toByteArray();

                    File dirGoc = new File(pathVoiGoc);
                    if (!dirGoc.exists()) dirGoc.mkdirs();
                    try (java.io.FileOutputStream fosGoc = new java.io.FileOutputStream(new File(dirGoc, finalImageName))) {
                        fosGoc.write(imageBytes);
                    }

                    File dirTomcat = new File(pathTomcat);
                    if (!dirTomcat.exists()) dirTomcat.mkdirs();
                    try (java.io.FileOutputStream fosTomcat = new java.io.FileOutputStream(new File(dirTomcat, finalImageName))) {
                        fosTomcat.write(imageBytes);
                    }
                    System.out.println("==> [THÀNH CÔNG RỰC RỠ] Đã tải ảnh sạch ký tự: " + finalImageName);
                } else {
                    System.err.println("==> [TỪ CHỐI] Mã lỗi HTTP từ server ảnh: " + responseCode);
                    finalImageName = imgUrl;
                }
            } catch (Exception e) {
                System.err.println("==> [NGOẠI LỆ] Lỗi tải ảnh: " + e.getMessage());
                finalImageName = imgUrl;
            } finally {
                if (in != null) {
                    try { in.close(); } catch (Exception ignored) {}
                }
            }
        }
        // ====================================================================================

        Product p = new Product();
        p.setProductName(name);
        p.setCategoryID(Integer.parseInt(categoryIdStr != null && !categoryIdStr.isEmpty() ? categoryIdStr : "1"));
        p.setBrandID(Integer.parseInt(brandIdStr != null && !brandIdStr.isEmpty() ? brandIdStr : "1"));
        p.setOriginalPrice(new BigDecimal(originalPriceStr != null && !originalPriceStr.isEmpty() ? originalPriceStr : "0"));
        p.setSellPrice(new BigDecimal(sellPriceStr != null && !sellPriceStr.isEmpty() ? sellPriceStr : "0"));

        p.setMainImageURL(finalImageName);

        p.setWarrantyMonths(Integer.parseInt(warrantyStr != null && !warrantyStr.isEmpty() ? warrantyStr : "12"));
        p.setDescriptionText(desc);
        p.setStatus(Integer.parseInt(statusStr != null && !statusStr.isEmpty() ? statusStr : "1"));

        if ("insert".equals(action)) {
            productDAO.insert(p);
            // GHI LOG: THÊM SẢN PHẨM MỚI
            logDAO.insertLog(adminId, "INFO", "Admin đã thêm linh kiện mới: " + name);

        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                p.setProductID(Integer.parseInt(idStr));
                productDAO.update(p);
                // GHI LOG: CẬP NHẬT SẢN PHẨM CHI TIẾT
                logDAO.insertLog(adminId, "WARN", "Admin đã cập nhật ID #" + idStr + ": " + name + " (Giá mới: " + sellPriceStr + " VNĐ)");
            }
        }

        response.sendRedirect(request.getContextPath() + "/ProductAdminController");
    }
}