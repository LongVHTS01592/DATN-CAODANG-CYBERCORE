package servlet;

import dao.ReportDAO;
import entity.RevenueReport;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/revenue-report")
public class RevenueController extends HttpServlet {

    private final ReportDAO reportDAO = new ReportDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // ĐÃ SỬA: Gọi đúng tên hàm getMonthlyRevenue() của ReportDAO
        List<RevenueReport> list = reportDAO.getMonthlyRevenue();

        request.setAttribute("revenueList", list);
        request.getRequestDispatcher("/admin/revenue-report.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}