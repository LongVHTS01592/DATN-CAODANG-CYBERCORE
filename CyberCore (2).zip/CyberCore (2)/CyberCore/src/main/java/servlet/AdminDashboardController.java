package servlet;

import dao.BillDAO;
import dao.ReportDAO; // Import thêm DAO mới
import entity.Bill;
import entity.User;
import entity.RevenueReport; // Import thêm Entity mới
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map; // Import Map

@WebServlet("/admin/dashboard")
public class AdminDashboardController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    // 1. Khởi tạo thêm đối tượng ReportDAO
    private final ReportDAO reportDAO = new ReportDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Chỉ Admin(1) hoặc Staff(2) mới được vào
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // --- CÁC CHỈ SỐ THỐNG KÊ HIỆN TẠI CỦA BẠN ---
        BigDecimal totalRevenue = billDAO.getTotalRevenue();
        int pendingOrders = billDAO.countPendingOrders();
        List<Bill> recentOrders = billDAO.getRecentOrders(5);

        // --- CÁC CHỈ SỐ THỐNG KÊ MỚI THÊM VÀO ---
        // Lấy dữ liệu 4 thẻ (Tổng SP, Tổng User...)
        Map<String, Object> stats = reportDAO.getDashboardStats();
        // Lấy dữ liệu doanh thu từng tháng để vẽ biểu đồ
        List<RevenueReport> revenueList = reportDAO.getMonthlyRevenue();

        // Gắn dữ liệu cũ
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("newOrdersCount", pendingOrders);
        request.setAttribute("recentOrders", recentOrders);

        // Gắn dữ liệu mới
        request.setAttribute("stats", stats);
        request.setAttribute("revenueList", revenueList);

        // Giữ nguyên đường dẫn forward của bạn
        request.getRequestDispatcher("/admin/admin_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}