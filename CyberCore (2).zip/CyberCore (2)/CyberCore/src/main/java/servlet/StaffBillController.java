package servlet;

import dao.BillDAO;
import dao.BillDetailDAO;
import entity.Bill;
import entity.BillDetail;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/StaffBillController")
public class StaffBillController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final BillDetailDAO billDetailDAO = new BillDetailDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String idParam = request.getParameter("id");

        // 1. XỬ LÝ CÁC THAO TÁC NHANH TỪ NÚT BẤM (APPROVE / CANCEL / DETAIL)
        if (action != null && idParam != null) {
            int billId = Integer.parseInt(idParam);

            if ("approve".equals(action)) {
                // Duyệt đơn: Chuyển trạng thái từ Pending sang Shipping
                billDAO.updateStatus(billId, "Shipping");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Pending");
                return;

            } else if ("cancel".equals(action)) {
                // Hủy đơn: Chuyển trạng thái sang Cancelled
                billDAO.updateStatus(billId, "Cancelled");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Pending");
                return;

            } else if ("detail".equals(action)) {
                // Xem chi tiết: Lấy thông tin đơn và danh sách sản phẩm bên trong đơn hàng
                Bill bill = billDAO.findById(billId);
                List<BillDetail> details = billDetailDAO.findByBillId(billId);

                request.setAttribute("selectedBill", bill);
                request.setAttribute("billDetails", details);
                // Điều hướng sang trang xem chi tiết hóa đơn (nếu bạn có làm trang riêng)
                request.getRequestDispatcher("/staff/staff_bill_detail.jsp").forward(request, response);
                return;
            }
        }

        // 2. XỬ LÝ LỌC THEO TAB TRẠNG THÁI VÀ TÌM KIẾM
        String status = request.getParameter("status");
        if (status == null || status.trim().isEmpty()) {
            status = "Pending"; // Mặc định khi vừa vào trang sẽ là tab Chờ duyệt
        }

        String searchBill = request.getParameter("searchBill");

        // Lấy toàn bộ danh sách hóa đơn từ SQL Server
        List<Bill> allBills = billDAO.findAll();
        List<Bill> filteredBills = new ArrayList<>();

        if (allBills != null) {
            final String finalStatus = status;
            // Thực hiện lọc theo trạng thái tab hiện tại
            filteredBills = allBills.stream()
                    .filter(b -> finalStatus.equalsIgnoreCase(b.getOrderStatus()))
                    .collect(Collectors.toList());

            // Nếu nhân viên có nhập từ khóa tìm kiếm (Mã đơn hoặc Tên khách hàng)
            if (searchBill != null && !searchBill.trim().isEmpty()) {
                String keyword = searchBill.trim().toLowerCase();
                filteredBills = filteredBills.stream()
                        .filter(b -> String.valueOf(b.getBillID()).contains(keyword)
                                || (b.getShippingRecipientName() != null && b.getShippingRecipientName().toLowerCase().contains(keyword)))
                        .collect(Collectors.toList());
            }
        }

        // 3. ĐẨY DỮ LIỆU SANG JSP
        request.setAttribute("bills", filteredBills);
        request.setAttribute("currentStatus", status); // Dùng để highlight tab trên giao diện

        request.getRequestDispatcher("/staff/staff_bill.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}