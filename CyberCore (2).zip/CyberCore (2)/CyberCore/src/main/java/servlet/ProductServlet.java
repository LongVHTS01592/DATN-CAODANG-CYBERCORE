package servlet;

import dao.CategoryDAO;
import dao.ProductDAO;
import entity.Category;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8"); // Xử lý Tiếng Việt trên thanh URL khi tìm kiếm

        // Lấy danh sách danh mục để đổ vào thanh lọc (Filter)
        List<Category> categories = categoryDAO.findAll();
        request.setAttribute("categories", categories);

        String keyword = request.getParameter("keyword");
        String categoryIdStr = request.getParameter("categoryId");

        List<Product> products;

        // Xử lý logic tìm kiếm và lọc
        if (keyword != null && !keyword.trim().isEmpty()) {
            products = productDAO.searchByName(keyword);
        } else if (categoryIdStr != null && !categoryIdStr.trim().isEmpty()) {
            try {
                int categoryId = Integer.parseInt(categoryIdStr);
                products = productDAO.findByCategory(categoryId);
            } catch (NumberFormatException e) {
                products = productDAO.findAll();
            }
        } else {
            products = productDAO.findAll();
        }

        request.setAttribute("products", products);
        request.getRequestDispatcher("/views/product_list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        doGet(request, response); // Chuyển luồng Post về Get để xử lý đồng nhất
    }
}