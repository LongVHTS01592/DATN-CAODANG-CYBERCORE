package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

@WebServlet(name = "PaymentServlet", value = "/checkout-payment")
public class PaymentServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(PaymentServlet.class.getName());

    // Bộ mã chuẩn xác lấy từ ảnh Dashboard của bạn
    private final String CLIENT_ID = "abaf8b27-e255-4ac7-be13-83724cd7eed8";
    private final String API_KEY = "ac71291d-5d9c-4393-948f-b71a2312f0da";
    private final String CHECKSUM_KEY = "2d3bdfd022ca4a301d7867a76bb8ea288bb3c78efbe4e40a0c405063399a466a";

    // Hàm hỗ trợ lọc sạch ký tự lạ và parse chuỗi giá tiền an toàn sang kiểu int
    private int parseAmountString(String amountStr) {
        try {
            String cleanStr = amountStr.replaceAll("[^\\d.]", "");
            if (cleanStr.contains(".")) {
                cleanStr = cleanStr.substring(0, cleanStr.indexOf("."));
            }
            return Integer.parseInt(cleanStr);
        } catch (NumberFormatException e) {
            return 2000;
        }
    }

    // Hàm tự băm mã bảo mật HMAC-SHA256 bằng thư viện gốc của Java
    private String hmacSha256(String data, String key) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] byteKey = key.getBytes(StandardCharsets.UTF_8);
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secret_key = new SecretKeySpec(byteKey, "HmacSHA256");
        sha256_HMAC.init(secret_key);
        byte[] mac_data = sha256_HMAC.doFinal(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder();
        for (byte b : mac_data) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int totalAmount = 2000;
            boolean foundPrice = false;

            // ƯU TIÊN 1: Lấy số tiền truyền trực tiếp từ URL nút bấm (?amount=xxx)
            String amountParam = request.getParameter("amount");
            if (amountParam != null && !amountParam.trim().isEmpty()) {
                totalAmount = parseAmountString(amountParam);
                foundPrice = true;
            }

            // ƯU TIÊN 2: Nếu URL không có tham số, tự động rà quét tổng tiền trong Session giỏ hàng
            if (!foundPrice) {
                HttpSession session = request.getSession();
                String[] sessionAttributes = {"totalPrice", "tongTien", "total", "cartTotal", "grandTotal"};
                for (String attr : sessionAttributes) {
                    Object priceObj = session.getAttribute(attr);
                    if (priceObj != null) {
                        totalAmount = parseAmountString(priceObj.toString());
                        break;
                    }
                }
            }

            if (totalAmount < 1000) {
                totalAmount = 2000;
            }

            long orderId = System.currentTimeMillis();
            String description = "CyberCore" + orderId;

            String returnUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/pages/success.jsp";
            String cancelUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/views/cart.jsp";

            String signatureData = "amount=" + totalAmount + "&cancelUrl=" + cancelUrl + "&description=" + description + "&orderCode=" + orderId + "&returnUrl=" + returnUrl;
            String signature = hmacSha256(signatureData, CHECKSUM_KEY);

            String jsonPayload = String.format(
                    "{\"orderCode\":%d,\"amount\":%d,\"description\":\"%s\",\"returnUrl\":\"%s\",\"cancelUrl\":\"%s\",\"signature\":\"%s\"}",
                    orderId, totalAmount, description, returnUrl, cancelUrl, signature
            );

            URL url = new URL("https://api-merchant.payos.vn/v2/payment-requests");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("x-client-id", CLIENT_ID);
            conn.setRequestProperty("x-api-key", API_KEY);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                String respStr = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

                String qrCodeUrl = "";
                if (respStr.contains("\"checkoutUrl\":\"")) {
                    int start = respStr.indexOf("\"checkoutUrl\":\"") + 15;
                    int end = respStr.indexOf("\"", start);
                    qrCodeUrl = respStr.substring(start, end).replace("\\/", "/");
                }

                // ĐÃ SỬA: Tự động chuyển hướng (Redirect) sang trang thanh toán chuẩn của PayOS thay vì forward
                if (qrCodeUrl != null && !qrCodeUrl.isEmpty()) {
                    response.sendRedirect(qrCodeUrl);
                } else {
                    throw new Exception("Khong lay duoc checkoutUrl tu he thong PayOS.");
                }
            } else {
                throw new Exception("PayOS API tra ve loi HTTP code: " + responseCode);
            }

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Loi ket noi cong thanh toan", e);
            response.getWriter().println("Loi cong thanh toan: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}