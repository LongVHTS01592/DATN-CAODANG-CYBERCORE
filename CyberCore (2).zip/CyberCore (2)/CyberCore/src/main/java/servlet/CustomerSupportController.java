package servlet;

import dao.ReviewDAO;
import dao.UserDAO;
import entity.Review;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/CustomerSupportController")
public class CustomerSupportController extends HttpServlet {

    private final ReviewDAO reviewDAO = new ReviewDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ratingParam = request.getParameter("rating");
        List<Review> reviewList;

        if ("bad".equals(ratingParam)) {
            reviewList = reviewDAO.findBadReviews();
        } else if (ratingParam != null && !ratingParam.trim().isEmpty()) {
            int rating = Integer.parseInt(ratingParam);
            reviewList = reviewDAO.findByRating(rating);
        } else {
            reviewList = reviewDAO.findAll();
        }

        // ĐỒNG BỘ ĐỐI TƯỢNG USER & TẠO AVATAR TEXT BẰNG JAVA
        // 2. ĐỒNG BỘ ĐỐI TƯỢNG USER & TẠO AVATAR TEXT BẰNG JAVA
        if (reviewList != null) {
            for (Review rev : reviewList) {
                User u = userDAO.findById(rev.getUserID());
                if (u != null) {
                    rev.setUser(u);

                    // Lấy username nếu có, không thì mặc định là "KH"
                    String name = (u.getUsername() != null && !u.getUsername().isEmpty()) ? u.getUsername() : "KH";

                    if (name.length() >= 2) {
                        rev.setAvatarText(name.substring(0, 2).toUpperCase());
                    } else {
                        rev.setAvatarText(name.toUpperCase());
                    }
                } else {
                    rev.setAvatarText("KH");
                }
            }
        }

        request.setAttribute("reviews", reviewList);
        request.getRequestDispatcher("/staff/customer_support.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // XỬ LÝ KHI NHÂN VIÊN GỬI PHẢN HỒI ĐÁNH GIÁ
        String reviewIdParam = request.getParameter("reviewID");
        String replyComment = request.getParameter("replyComment");

        if (reviewIdParam != null && replyComment != null) {
            int reviewId = Integer.parseInt(reviewIdParam);

            // Ở đây bạn có thể cập nhật trạng thái đã phản hồi, hoặc thêm dòng dữ liệu vào bảng phản hồi riêng.
            System.out.println("Nhân viên phản hồi cho Review #" + reviewId + ": " + replyComment);

            // Ví dụ tạm thời: Lưu log hoặc cập nhật trực tiếp. Để demo chạy được, ta redirect lại trang.
        }

        // Sau khi xử lý xong quay lại danh sách
        response.sendRedirect(request.getContextPath() + "/CustomerSupportController");
    }
}