package servlet;

import dao.BillDAO;
import dao.ProductDAO;
import entity.Bill;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/staff/dashboard")
public class StaffDashboardController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. ĐẾM SỐ ĐƠN HÀNG MỚI (Trạng thái 'Pending')
        int newOrdersCount = billDAO.countPendingOrders();

        // 2. ĐẾM SỐ SẢN PHẨM HẾT HÀNG (Dựa trên cấu trúc trường Status = 2 trong ProductDAO)
        List<Product> allProducts = productDAO.findAll();
        long lowStockCount = 0;
        if (allProducts != null) {
            lowStockCount = allProducts.stream()
                    .filter(p -> p.getStatus() == 2)
                    .count();
        }

        // Đẩy các số liệu thống kê ra thuộc tính Request
        request.setAttribute("newOrdersCount", newOrdersCount);
        request.setAttribute("lowStockCount", (int) lowStockCount);

        // 3. LẤY DANH SÁCH ĐƠN HÀNG MỚI NHẤT CẦN XỬ LÝ (Lấy top 5 hoặc 10 đơn tùy nhu cầu)
        List<Bill> recentOrders = billDAO.getRecentOrders(5);

        // Đẩy danh sách đơn hàng thực tế qua trang JSP
        request.setAttribute("recentOrders", recentOrders);

        // 4. Chuyển tiếp luồng xử lý đến trang hiển thị giao diện
        request.getRequestDispatcher("/staff/staff_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}