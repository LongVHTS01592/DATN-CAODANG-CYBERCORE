package servlet;

import dao.BannerDAO;
import entity.Banner;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

@WebServlet("/BannerAdminController")
public class BannerAdminController extends HttpServlet {

    private final BannerDAO bannerDAO = new BannerDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT ADMIN
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                bannerDAO.delete(Integer.parseInt(idStr));
            }
            response.sendRedirect(request.getContextPath() + "/BannerAdminController");
            return;
        } else if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                Banner b = bannerDAO.findById(Integer.parseInt(idStr));
                request.setAttribute("bannerEdit", b);

                // Chuyển đổi định dạng ngày để hiển thị lên input datetime-local
                if (b.getStartDate() != null) {
                    request.setAttribute("startDateStr", b.getStartDate().toString().replace(" ", "T").substring(0, 16));
                }
                if (b.getEndDate() != null) {
                    request.setAttribute("endDateStr", b.getEndDate().toString().replace(" ", "T").substring(0, 16));
                }
            }
        }

        List<Banner> listBanners = bannerDAO.findAll();
        request.setAttribute("listBanners", listBanners);
        request.getRequestDispatcher("/admin/admin_banner.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        String title = request.getParameter("title");
        String imageURL = request.getParameter("imageURL");
        String position = request.getParameter("position");
        String targetLink = request.getParameter("targetLink");
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");
        String isActiveStr = request.getParameter("isActive");

        Banner b = new Banner();
        b.setTitle(title);
        b.setImageURL(imageURL != null && !imageURL.isEmpty() ? imageURL : "default_banner.jpg");
        b.setPosition(position);
        b.setTargetLink(targetLink);

        // Xử lý chuyển đổi chuỗi từ input datetime-local thành SQL Timestamp
        try {
            if (startDateStr != null && !startDateStr.isEmpty()) {
                b.setStartDate(Timestamp.valueOf(startDateStr.replace("T", " ") + ":00"));
            }
            if (endDateStr != null && !endDateStr.isEmpty()) {
                b.setEndDate(Timestamp.valueOf(endDateStr.replace("T", " ") + ":00"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        b.setActive("1".equals(isActiveStr));

        if ("insert".equals(action)) {
            bannerDAO.insert(b);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                b.setBannerID(Integer.parseInt(idStr));
                bannerDAO.update(b);
            }
        }

        response.sendRedirect(request.getContextPath() + "/BannerAdminController");
    }
}