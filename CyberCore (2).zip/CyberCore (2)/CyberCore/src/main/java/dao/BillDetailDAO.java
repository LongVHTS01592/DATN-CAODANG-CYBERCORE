package dao;

import entity.BillDetail;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BillDetailDAO {

    // Hàm Map dữ liệu dùng chung
    private BillDetail map(ResultSet rs) throws SQLException {
        BillDetail b = new BillDetail();
        b.setBillDetailID(rs.getInt("BillDetailID"));
        b.setBillID(rs.getInt("BillID"));
        b.setProductID(rs.getInt("ProductID"));
        b.setQuantity(rs.getInt("Quantity"));
        b.setPriceAtSale(rs.getBigDecimal("PriceAtSale"));
        return b;
    }

    public List<BillDetail> findByBillId(int billId) {
        List<BillDetail> list = new ArrayList<>();
        String sql = "SELECT * FROM BillDetails WHERE BillID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, billId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public boolean insert(BillDetail b) {
        String sql = "INSERT INTO BillDetails (BillID, ProductID, Quantity, PriceAtSale) VALUES (?,?,?,?)";
        // Gom gọn 1 dòng duy nhất nhờ JdbcUtil
        return JdbcUtil.executeUpdate(sql, b.getBillID(), b.getProductID(), b.getQuantity(), b.getPriceAtSale()) > 0;
    }

    public boolean deleteByBillId(int billId) {
        String sql = "DELETE FROM BillDetails WHERE BillID=?";
        // Gom gọn 1 dòng duy nhất
        return JdbcUtil.executeUpdate(sql, billId) > 0;
    }
}