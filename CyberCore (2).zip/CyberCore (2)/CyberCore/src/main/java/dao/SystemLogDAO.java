package dao;

import com.tuanphat.entity.SystemLog;
import util.JdbcUtil;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SystemLogDAO {

    // Lấy 50 log mới nhất để hiển thị lên Console
    public List<SystemLog> getRecentLogs() {
        List<SystemLog> list = new ArrayList<>();
        String sql = "SELECT TOP 50 * FROM SystemLogs ORDER BY CreatedAt ASC"; // Xếp ASC để log cũ ở trên, mới ở dưới
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                SystemLog log = new SystemLog();
                log.setLogID(rs.getInt("LogID"));
                log.setUserID(rs.getObject("UserID") != null ? rs.getInt("UserID") : null);
                log.setLogLevel(rs.getString("LogLevel"));
                log.setLogMessage(rs.getString("LogMessage"));
                log.setCreatedAt(rs.getTimestamp("CreatedAt"));
                list.add(log);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Hàm dùng để ghi log mới từ các Servlet khác (Thêm/Sửa/Xóa)
    public boolean insertLog(Integer userId, String level, String message) {
        String sql = "INSERT INTO SystemLogs (UserID, LogLevel, LogMessage) VALUES (?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, userId, level, message) > 0;
    }
}