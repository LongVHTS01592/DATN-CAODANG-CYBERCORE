package dao;

import entity.User;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserID(rs.getInt("UserID"));
        u.setUsername(rs.getString("Username"));
        u.setPasswordHash(rs.getString("PasswordHash"));
        u.setFullName(rs.getString("FullName"));
        u.setEmail(rs.getString("Email"));
        u.setPhone(rs.getString("Phone"));
        u.setRoleID(rs.getInt("RoleID"));
        u.setActive(rs.getBoolean("IsActive"));
        u.setCreatedAt(rs.getTimestamp("CreatedAt"));
        u.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
        return u;
    }

    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        // FIX LỖI TỐC ĐỘ: Thêm TOP 50 để tránh kéo toàn bộ DB làm treo server
        String sql = "SELECT TOP 50 * FROM Users ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public User findById(int id) {
        String sql = "SELECT * FROM Users WHERE UserID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public User findByUsername(String username) {
        String sql = "SELECT * FROM Users WHERE Username=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, username);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    // Hàm xử lý Đăng nhập ĐÃ GẮN CÔNG CỤ DEBUG
    public User login(String loginIdentifier, String passwordHash) {
        System.out.println("=== DEBUG ĐĂNG NHẬP CYBERCORE ===");
        System.out.println("1. Tài khoản Client gửi lên: [" + loginIdentifier + "]");
        System.out.println("2. Mật khẩu Client gửi lên: [" + passwordHash + "]");

        String sql = "SELECT * FROM Users WHERE (Username=? OR Email=?) AND PasswordHash=? AND IsActive=1";

        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, loginIdentifier, loginIdentifier, passwordHash);

            if (rs.next()) {
                System.out.println("3. TRẠNG THÁI: Tìm thấy tài khoản trong Database! Đang map dữ liệu...");
                User u = map(rs);
                System.out.println("4. TRẠNG THÁI: Map dữ liệu thành công cho user: " + u.getFullName());
                return u;
            } else {
                System.out.println("3. LỖI LOGIC: Không tìm thấy tài khoản (Sai Pass, Sai Tên hoặc bị khóa IsActive=0)");
            }
        } catch (Exception e) {
            System.out.println("3. LỖI CRASH HỆ THỐNG: Có cột dữ liệu bị lệch tên hoặc sai kiểu dữ liệu!");
            e.printStackTrace();
        }

        return null;
    }

    public boolean insert(User u) {
        String sql = "INSERT INTO Users (Username, PasswordHash, FullName, Email, Phone, RoleID, IsActive) VALUES (?,?,?,?,?,?,?)";
        return JdbcUtil.executeUpdate(sql, u.getUsername(), u.getPasswordHash(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRoleID(), u.isActive()) > 0;
    }

    public boolean update(User u) {
        String sql = "UPDATE Users SET PasswordHash=?, FullName=?, Email=?, Phone=?, RoleID=?, IsActive=?, UpdatedAt=GETDATE() WHERE UserID=?";
        return JdbcUtil.executeUpdate(sql, u.getPasswordHash(), u.getFullName(), u.getEmail(), u.getPhone(), u.getRoleID(), u.isActive(), u.getUserID()) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Users WHERE UserID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }
}