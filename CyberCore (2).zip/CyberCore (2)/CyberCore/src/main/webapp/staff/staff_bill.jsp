<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberCore Staff - Xử Lý Đơn Hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
        .wrapper { display: flex; min-height: 100vh; }

        /* SIDEBAR TÔNG TÍM ĐỒNG BỘ */
        .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
        .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

        .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
        .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
        .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }

        .main-content { flex-grow: 1; padding: 2rem; }

        /* ĐỒNG BỘ EFFECT HOVER TÍM */
        .nav-tabs .nav-link { color: #4a376b; font-weight: 600; border: none; padding: 0.75rem 1.25rem; }
        .nav-tabs .nav-link.active { color: #a855f7; border-bottom: 3px solid #a855f7; background: none; }

        .btn-purple { background-color: #a855f7; color: white; }
        .btn-purple:hover { background-color: #9333ea; color: white; }
        .btn-outline-purple { color: #a855f7; border-color: #a855f7; }
        .btn-outline-purple:hover { background-color: #a855f7; color: white; }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0">
            <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
        </div>
        <div class="sidebar-user mb-3">
            <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
            <div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div>
            <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
        </div>

        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử nhập kho</a>
            </li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary">
                <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h2 fw-bolder text-dark mb-1">Xử lý đơn đặt hàng</h1>
                <p class="text-secondary">Tiếp nhận đơn hàng mới, đóng gói và bàn giao vận chuyển linh kiện.</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-4 rounded-3 bg-white">
            <div class="card-header bg-white border-0 pt-3">
                <ul class="nav nav-tabs card-header-tabs border-bottom-0">
                    <li class="nav-item">
                        <a class="nav-link ${currentStatus == 'Pending' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController?status=Pending">
                            <i class="fa-solid fa-clock me-2"></i>Chờ duyệt
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ${currentStatus == 'Shipping' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController?status=Shipping">
                            <i class="fa-solid fa-truck me-2"></i>Đang giao
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ${currentStatus == 'Completed' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController?status=Completed">
                            <i class="fa-solid fa-circle-check me-2"></i>Đã hoàn thành
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link ${currentStatus == 'Cancelled' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController?status=Cancelled">
                            <i class="fa-solid fa-circle-xmark me-2"></i>Đã hủy
                        </a>
                    </li>
                </ul>
            </div>

            <div class="card-body border-top">
                <form method="GET" action="${pageContext.request.contextPath}/StaffBillController" class="row g-2">
                    <div class="col-md-6 col-10">
                        <input type="text" name="searchBill" class="form-control" placeholder="Nhập mã đơn hoặc tên khách hàng cần tìm...">
                    </div>
                    <div class="col-md-2 col-2">
                        <button type="submit" class="btn btn-dark w-100 fw-bold"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 bg-white">
            <div class="table-responsive px-3 py-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>Mã đơn</th>
                        <th>Người nhận</th>
                        <th>Số điện thoại</th>
                        <th>Ngày đặt hàng</th>
                        <th>Tổng thanh toán</th>
                        <th>Trạng thái</th>
                        <th class="text-center">Thao tác</th>
                    </tr>
                    </thead>
                    <tbody>
                    <%-- Vòng lặp lấy data đổ ra từ List của backend gửi sang --%>
                    <c:forEach items="${bills}" var="b">
                        <tr>
                            <td class="fw-bold text-dark">#ORD-${b.billID}</td>
                            <td>${b.shippingRecipientName}</td>
                            <td><span class="text-secondary">${b.shippingPhone}</span></td>
                            <td><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm"/></td>
                            <td class="fw-bold text-dark">
                                <fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/>
                                Safe</td>
                            <td>
                                <c:choose>
                                    <c:when test="${b.orderStatus == 'Pending'}">
                                        <span class="badge bg-warning text-dark px-2.5 py-1.5 rounded-pill">Chờ duyệt</span>
                                    </c:when>
                                    <c:when test="${b.orderStatus == 'Shipping'}">
                                        <span class="badge bg-info text-white px-2.5 py-1.5 rounded-pill">Đang giao</span>
                                    </c:when>
                                    <c:when test="${b.orderStatus == 'Completed'}">
                                        <span class="badge bg-success text-white px-2.5 py-1.5 rounded-pill">Đã hoàn thành</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge bg-danger text-white px-2.5 py-1.5 rounded-pill">Đã hủy</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td class="text-center">
                                <a href="${pageContext.request.contextPath}/StaffBillController?action=detail&id=${b.billID}"
                                   class="btn btn-sm btn-outline-purple me-1" title="Xem chi tiết đơn">
                                    <i class="fa-solid fa-eye"></i>
                                </a>

                                    <%-- Nếu đơn hàng đang chờ duyệt thì hiện thêm nút duyệt nhanh / hủy nhanh --%>
                                <c:if test="${b.orderStatus == 'Pending'}">
                                    <a href="${pageContext.request.contextPath}/StaffBillController?action=approve&id=${b.billID}"
                                       class="btn btn-sm btn-success me-1" title="Duyệt đơn và Đóng gói">
                                        <i class="fa-solid fa-check"></i>
                                    </a>
                                    <a href="${pageContext.request.contextPath}/StaffBillController?action=cancel&id=${b.billID}"
                                       class="btn btn-sm btn-danger" title="Hủy đơn" onclick="return confirm('Bạn có chắc muốn hủy đơn hàng này không?')">
                                        <i class="fa-solid fa-xmark"></i>
                                    </a>
                                </c:if>
                            </td>
                        </tr>
                    </c:forEach>

                    <%-- Hiển thị khi không có đơn hàng nào trong danh sách --%>
                    <c:if test="${empty bills}">
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="fa-solid fa-folder-open fs-2 d-block mb-2 text-secondary"></i>
                                Hiện tại không có đơn đặt hàng nào trong mục này.
                            </td>
                        </tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>