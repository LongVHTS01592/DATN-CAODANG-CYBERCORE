<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="activePage" value="bill" />
<jsp:include page="/layout/header.jsp" />

<style>
  .wrapper { display: flex; min-height: calc(100vh - 80px); background-color: #f4f3f8; }
  .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
  .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
  .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
  .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
  .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
  .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
  .main-content { flex-grow: 1; padding: 2rem; }
  .btn-purple { background-color: #a855f7; color: white; }
  .btn-purple:hover { background-color: #9333ea; color: white; }
</style>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0"><i class="fa-solid fa-microchip"></i> CYBERCORE STAFF</div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>
    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử kho</a></li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2"></i> Về Cửa Hàng</a></li>
      <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Chi Tiết Đơn: #ORD-${bill.billID}</h1>
        <p class="text-secondary">Xem xét thông tin vận chuyển và các linh kiện khách đã đặt.</p>
      </div>
      <a href="${pageContext.request.contextPath}/StaffBillController" class="btn btn-outline-secondary fw-bold"><i class="fa-solid fa-arrow-left me-2"></i>Quay lại</a>
    </div>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 bg-white p-4 h-100">
          <h5 class="fw-bold border-bottom pb-2 mb-3"><i class="fa-solid fa-truck text-purple me-2"></i> Giao Hàng</h5>
          <p class="mb-2"><strong>Người nhận:</strong> ${bill.shippingRecipientName}</p>
          <p class="mb-2"><strong>SĐT:</strong> ${bill.shippingPhone}</p>
          <p class="mb-2"><strong>Địa chỉ:</strong> ${bill.shippingAddressText}</p>
          <p class="mb-2"><strong>Ngày đặt:</strong> <fmt:formatDate value="${bill.orderDate}" pattern="dd/MM/yyyy HH:mm"/></p>
          <hr>
          <p class="mb-2"><strong>Trạng thái:</strong>
            <span class="badge ${bill.orderStatus == 'Pending' ? 'bg-warning text-dark' : (bill.orderStatus == 'Completed' ? 'bg-success' : 'bg-danger')}">${bill.orderStatus}</span>
          </p>

          <c:if test="${bill.orderStatus == 'Pending'}">
            <div class="d-flex gap-2 mt-4">
              <a href="${pageContext.request.contextPath}/StaffBillController?action=approve&id=${bill.billID}" class="btn btn-success w-100 fw-bold"><i class="fa-solid fa-check me-1"></i> Duyệt Đơn</a>
              <a href="${pageContext.request.contextPath}/StaffBillController?action=cancel&id=${bill.billID}" class="btn btn-danger w-100 fw-bold" onclick="return confirm('Xác nhận hủy?')"><i class="fa-solid fa-xmark me-1"></i> Hủy</a>
            </div>
          </c:if>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden h-100">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light text-uppercase small">
              <tr>
                <th class="ps-4">Tên Thiết Bị</th>
                <th class="text-center">Số Lượng</th>
                <th class="text-end pe-4">Đơn Giá</th>
              </tr>
              </thead>
              <tbody>
              <c:forEach items="${bill.details}" var="detail">
                <tr>
                  <td class="ps-4 fw-semibold">${detail.product.productName}</td>
                  <td class="text-center">${detail.quantity}</td>
                  <td class="text-danger fw-bold text-end pe-4"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td>
                </tr>
              </c:forEach>
              </tbody>
              <tfoot class="table-light">
              <tr>
                <td colspan="2" class="text-end fw-bold text-uppercase pt-3">Tổng Cộng:</td>
                <td class="text-danger fw-bolder text-end pe-4 pt-3 fs-5"><fmt:formatNumber value="${bill.totalAmount}" type="currency" currencySymbol="đ"/></td>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>

<jsp:include page="/layout/footer.jsp" />