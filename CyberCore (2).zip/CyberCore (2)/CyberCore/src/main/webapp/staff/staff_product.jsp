<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberCore Staff - Quản Lý Kho Hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
        .wrapper { display: flex; min-height: 100vh; }

        .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
        .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

        .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
        .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
        .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }

        .main-content { flex-grow: 1; padding: 2rem; }
        .text-primary { color: #a855f7 !important; }
        .btn-purple { background-color: #a855f7; color: white; }
        .btn-purple:hover { background-color: #9333ea; color: white; }

        .product-img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0">
            <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
        </div>
        <div class="sidebar-user mb-3">
            <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
            <div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div>
            <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
        </div>

        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử nhập kho</a>
            </li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary">
                <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h2 fw-bolder text-dark mb-1">Quản lý kho linh kiện</h1>
                <p class="text-secondary">Xem tình trạng tồn kho, cập nhật giá bán và trạng thái hàng hóa.</p>
            </div>
            <a href="${pageContext.request.contextPath}/StaffProductController?action=add" class="btn btn-purple fw-bold shadow-sm">
                <i class="fa-solid fa-plus me-2"></i>Nhập linh kiện mới
            </a>
        </div>

        <div class="card border-0 shadow-sm p-3 mb-4 rounded-3">
            <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/StaffProductController">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" value="${selectedSearch}" placeholder="Tìm tên linh kiện...">
                </div>
                <div class="col-md-3">
                    <select name="category" class="form-select">
                        <option value="">-- Chọn danh mục --</option>
                        <c:forEach items="${categories}" var="cat">
                            <option value="${cat.categoryID}" ${cat.categoryID == selectedCat ? 'selected' : ''}>${cat.categoryName}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="brand" class="form-select">
                        <option value="">-- Chọn thương hiệu --</option>
                        <c:forEach items="${brands}" var="b">
                            <option value="${b.brandID}" ${b.brandID == selectedBrand ? 'selected' : ''}>${b.brandName}</option>
                        </c:forEach>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-dark w-100 fw-bold">Lọc hàng</button>
                </div>
            </form>
        </div>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="table-responsive px-3 py-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>Mã SP</th>
                        <th>Hình ảnh</th>
                        <th>Tên linh kiện</th>
                        <th>Giá bán lẻ</th>
                        <th>Bảo hành</th>
                        <th>Trạng thái</th>
                        <th class="text-center">Thao tác</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach items="${products}" var="prod">
                        <tr>
                            <td class="fw-bold text-secondary">#SP-${prod.productID}</td>
                            <td>
                                <img src="${pageContext.request.contextPath}/images/${prod.mainImageURL}"
                                     alt="img" class="product-img border"
                                     onerror="this.src='https://via.placeholder.com/50'">
                            </td>
                            <td>
                                <div class="fw-bold text-dark">${prod.productName}</div>
                                <small class="text-muted">Thương hiệu:
                                    <c:forEach items="${brands}" var="br">
                                        <c:if test="${br.brandID == prod.brandID}">${br.brandName}</c:if>
                                    </c:forEach>
                                </small>
                            </td>
                            <td class="fw-bold text-dark">
                                <fmt:formatNumber value="${prod.sellPrice}" type="currency" currencySymbol="đ"/>
                            </td>
                            <td><span class="badge bg-light text-dark border">${prod.warrantyMonths} Tháng</span></td>
                            <td>
                                <c:choose>
                                    <c:when test="${prod.status == 1}">
                                        <span class="badge bg-success-subtle text-success border border-success-subtle">Đang bán</span>
                                    </c:when>
                                    <c:when test="${prod.status == 2}">
                                        <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Hết hàng</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Tạm ngưng</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td class="text-center">
                                <a href="${pageContext.request.contextPath}/StaffProductController?action=edit&id=${prod.productID}"
                                   class="btn btn-sm btn-outline-secondary me-1" title="Sửa thông tin">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                                <a href="${pageContext.request.contextPath}/StaffProductController?action=updateStock&id=${prod.productID}"
                                   class="btn btn-sm btn-outline-primary" title="Cập nhật số kho">
                                    <i class="fa-solid fa-warehouse"></i>
                                </a>
                            </td>
                        </tr>
                    </c:forEach>

                    <c:if test="${empty products}">
                        <tr>
                            <td colspan="7" class="text-center text-muted py-5">
                                <i class="fa-solid fa-box-open fs-2 d-block mb-2 text-secondary"></i>
                                Không tìm thấy linh kiện nào trong kho hàng.
                            </td>
                        </tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>