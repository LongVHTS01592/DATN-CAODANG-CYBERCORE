<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="activePage" value="product" />
<jsp:include page="/layout/header.jsp" />

<style>
    .wrapper { display: flex; min-height: calc(100vh - 80px); background-color: #f4f3f8; }
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .main-content { flex-grow: 1; padding: 2rem; }
    .btn-purple { background-color: #a855f7; color: white; }
    .btn-purple:hover { background-color: #9333ea; color: white; }
    .product-img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }
</style>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0"><i class="fa-solid fa-microchip"></i> CYBERCORE STAFF</div>
        <div class="sidebar-user mb-3"><img src="${pageContext.request.contextPath}/images/avatar-staff.png" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'"><div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div><div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div></div>
        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử kho</a></li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h2 fw-bolder text-dark mb-1">Quản lý kho linh kiện</h1>
                <p class="text-secondary">Xem tình trạng tồn kho, cập nhật giá bán.</p>
            </div>
            <a href="${pageContext.request.contextPath}/StaffProductController?action=add" class="btn btn-purple fw-bold shadow-sm"><i class="fa-solid fa-plus me-2"></i>Nhập linh kiện mới</a>
        </div>

        <div class="card border-0 shadow-sm p-3 mb-4 rounded-3">
            <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/StaffProductController">
                <div class="col-md-4"><input type="text" name="search" class="form-control" value="${selectedSearch}" placeholder="Tìm tên linh kiện..."></div>
                <div class="col-md-3">
                    <select name="category" class="form-select">
                        <option value="">-- Danh mục --</option>
                        <c:forEach items="${categories}" var="cat"><option value="${cat.categoryID}" ${cat.categoryID == selectedCat ? 'selected' : ''}>${cat.categoryName}</option></c:forEach>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="brand" class="form-select">
                        <option value="">-- Thương hiệu --</option>
                        <c:forEach items="${brands}" var="b"><option value="${b.brandID}" ${b.brandID == selectedBrand ? 'selected' : ''}>${b.brandName}</option></c:forEach>
                    </select>
                </div>
                <div class="col-md-2"><button type="submit" class="btn btn-dark w-100 fw-bold">Lọc hàng</button></div>
            </form>
        </div>

        <div class="card border-0 shadow-sm rounded-4 bg-white">
            <div class="table-responsive px-3 py-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr><th>Mã SP</th><th>Hình ảnh</th><th>Tên linh kiện</th><th>Giá bán lẻ</th><th>Trạng thái</th><th class="text-center">Thao tác</th></tr>
                    </thead>
                    <tbody>
                    <c:forEach items="${products}" var="prod">
                        <tr>
                            <td class="fw-bold text-secondary">#SP-${prod.productID}</td>
                            <td><img src="${pageContext.request.contextPath}/images/${prod.mainImageURL}" class="product-img border" onerror="this.src='https://via.placeholder.com/50'"></td>
                            <td><div class="fw-bold text-dark">${prod.productName}</div><small class="text-muted">Bảo hành: ${prod.warrantyMonths}T</small></td>
                            <td class="fw-bold text-dark"><fmt:formatNumber value="${prod.sellPrice}" type="currency" currencySymbol="đ"/></td>
                            <td><span class="badge ${prod.status == 1 ? 'bg-success' : 'bg-warning'} text-white border">${prod.status == 1 ? 'Đang bán' : 'Tạm ngưng'}</span></td>
                            <td class="text-center">
                                <a href="${pageContext.request.contextPath}/StaffProductController?action=edit&id=${prod.productID}" class="btn btn-sm btn-outline-secondary me-1"><i class="fa-solid fa-pen-to-square"></i></a>
                            </td>
                        </tr>
                    </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<jsp:include page="/layout/footer.jsp" />