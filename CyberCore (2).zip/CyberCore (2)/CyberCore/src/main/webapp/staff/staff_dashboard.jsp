<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<jsp:useBean id="now" class="java.util.Date" />
<c:set var="activePage" value="dashboard" />
<jsp:include page="/layout/header.jsp" />

<style>
    .wrapper { display: flex; min-height: calc(100vh - 80px); background-color: #f4f3f8; }
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .main-content { flex-grow: 1; padding: 2rem; }
    .task-card { background: #fff; padding: 1.5rem; border-radius: 10px; box-shadow: 0 5px 15px rgba(168, 85, 247, 0.05); transition: transform 0.2s; }
    .task-card:hover { transform: translateY(-3px); }
    .card-label { color: #7c728e; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; }
    .card-value { color: #2e1f47; font-size: 2.2rem; font-weight: 800; margin: 0.5rem 0; }
    .quick-action-btn { background: #fff; padding: 1.5rem; border-radius: 10px; text-align: center; border: 2px solid #e6e1f0; color: #4a376b; text-decoration: none; display: block; transition: all 0.2s; }
    .quick-action-btn:hover { border-color: #a855f7; background-color: #faf5ff; color: #a855f7; }
    .quick-action-btn i { font-size: 2.5rem; display: block; margin-bottom: 0.5rem; color: #a855f7; }
    .text-primary { color: #a855f7 !important; }
</style>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0"><i class="fa-solid fa-microchip"></i> CYBERCORE STAFF</div>
        <div class="sidebar-user mb-3"><img src="${pageContext.request.contextPath}/images/avatar-staff.png" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'"><div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div><div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div></div>
        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử kho</a></li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h1 class="h1 fw-bolder text-dark mb-1">Cổng vận hành CyberCore</h1>
                <p class="text-secondary fs-5">Chào bạn trở lại! Chúc bạn một ngày làm việc hiệu quả.</p>
            </div>
            <div class="text-muted border p-3 rounded-pill bg-white shadow-sm">
                <i class="fa-regular fa-clock me-2 text-primary"></i> Giờ hiện tại: <fmt:formatDate value="${now}" pattern="HH:mm, dd/MM/yyyy" />
            </div>
        </div>

        <h4 class="mb-3 text-secondary fw-bold text-uppercase">Tác vụ hôm nay</h4>
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="task-card text-center"><div class="card-label">Đơn mới <span class="text-danger">(Chờ duyệt)</span></div><div class="card-value text-warning">${newOrdersCount != null ? newOrdersCount : 0}</div><p class="text-muted small mb-0">Cần đóng gói sớm</p></div>
            </div>
            <div class="col-md-4">
                <div class="task-card text-center"><div class="card-label">Sản phẩm sắp <span class="text-danger">(Hết hàng)</span></div><div class="card-value text-danger">${lowStockCount != null ? lowStockCount : 0}</div><p class="text-muted small mb-0">Liên hệ Admin nhập kho</p></div>
            </div>
            <div class="col-md-4">
                <div class="task-card text-center"><div class="card-label">Hỗ trợ mới <span class="text-danger">(Chưa đọc)</span></div><div class="card-value text-info">3</div><p class="text-muted small mb-0">Cần phản hồi khách hàng</p></div>
            </div>
        </div>

        <h4 class="mb-3 text-secondary fw-bold text-uppercase">Bảng thao tác nhanh</h4>
        <div class="row g-4 mb-5">
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffBillController?status=Pending" class="quick-action-btn"><i class="fa-solid fa-cash-register"></i><div class="fw-bold">Xử lý<br>đơn hàng mới</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffProductController?action=add" class="quick-action-btn"><i class="fa-solid fa-plus-circle"></i><div class="fw-bold">Thêm<br>linh kiện mới</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffProductController?action=import" class="quick-action-btn"><i class="fa-solid fa-warehouse"></i><div class="fw-bold">Phiếu<br>nhập kho hàng</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffBillController?action=history" class="quick-action-btn"><i class="fa-solid fa-list-ul"></i><div class="fw-bold">Tìm kiếm<br>đơn hàng</div></a></div>
        </div>
    </main>
</div>

<jsp:include page="/layout/footer.jsp" />