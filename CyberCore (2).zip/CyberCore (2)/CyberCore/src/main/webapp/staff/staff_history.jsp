<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="activePage" value="history" />
<jsp:include page="/layout/header.jsp" />

<style>
    .wrapper { display: flex; min-height: calc(100vh - 80px); background-color: #f4f3f8; }
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .main-content { flex-grow: 1; padding: 2rem; }
    .mini-stat-card { background: #fff; border-radius: 12px; padding: 1.25rem; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.02); }
    .text-purple { color: #a855f7 !important; }
    .bg-purple-light { background-color: #faf5ff; }
</style>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0"><i class="fa-solid fa-microchip"></i> CYBERCORE STAFF</div>
        <div class="sidebar-user mb-3"><img src="${pageContext.request.contextPath}/images/avatar-staff.png" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'"><div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div><div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div></div>
        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử kho</a></li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div><h1 class="h2 fw-bolder text-dark mb-1">Nhật ký lịch sử</h1></div>
            <button class="btn btn-outline-secondary fw-bold" onclick="window.print()"><i class="fa-solid fa-file-excel me-2"></i>Xuất Excel</button>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-6"><div class="mini-stat-card d-flex align-items-center justify-content-between"><div><span class="text-muted small fw-bold text-uppercase">Đơn Hoàn Thành</span><h4 class="fw-extrabold mb-0 mt-1 text-success">${completedOrdersCount != null ? completedOrdersCount : 0} Đơn</h4></div></div></div>
            <div class="col-md-6"><div class="mini-stat-card d-flex align-items-center justify-content-between"><div><span class="text-muted small fw-bold text-uppercase">Doanh Số Đối Soát</span><h4 class="fw-extrabold mb-0 mt-1 text-dark"><fmt:formatNumber value="${totalSettledAmount != null ? totalSettledAmount : 0}" type="currency" currencySymbol="đ"/></h4></div></div></div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 bg-white">
            <div class="table-responsive px-3 py-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light"><tr><th>Mã đơn</th><th>Thời gian chốt</th><th>Khách hàng</th><th>Tổng tiền</th><th>Thanh toán</th><th>Kết quả</th></tr></thead>
                    <tbody>
                    <c:forEach items="${historyStatements}" var="stmt">
                        <tr>
                            <td class="fw-bold text-dark">#ORD-${stmt.billID}</td>
                            <td><fmt:formatDate value="${stmt.orderDate}" pattern="dd/MM/yyyy HH:mm"/></td>
                            <td><span class="fw-bold">${stmt.customerName}</span></td>
                            <td class="fw-bold"><fmt:formatNumber value="${stmt.totalAmount}" type="currency" currencySymbol="đ"/></td>
                            <td><span class="badge bg-primary-subtle text-primary border">${stmt.paymentMethod}</span></td>
                            <td><span class="badge ${stmt.orderStatus == 'Completed' ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} rounded-pill">${stmt.orderStatus}</span></td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty historyStatements}"><tr><td colspan="6" class="text-center text-muted py-5">Chưa có nhật ký giao dịch.</td></tr></c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<jsp:include page="/layout/footer.jsp" />