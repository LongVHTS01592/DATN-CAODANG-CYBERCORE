<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="activePage" value="support" />
<jsp:include page="/layout/header.jsp" />

<style>
    .wrapper { display: flex; min-height: calc(100vh - 80px); background-color: #f4f3f8; }
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .main-content { flex-grow: 1; padding: 2rem; }
    .text-purple { color: #a855f7; }
    .btn-purple { background-color: #a855f7; color: white; }
    .btn-purple:hover { background-color: #9333ea; color: white; }
    .review-card { background: #fff; border-radius: 12px; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.03); transition: transform 0.2s; }
    .avatar-user-review { width: 45px; height: 45px; object-fit: cover; background-color: #e6e1f0; color: #4a376b; font-weight: bold; display: flex; align-items: center; justify-content: center; }
</style>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0"><i class="fa-solid fa-microchip"></i> CYBERCORE STAFF</div>
        <div class="sidebar-user mb-3"><img src="${pageContext.request.contextPath}/images/avatar-staff.png" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'"><div class="fw-bold text-white">${sessionScope.userAccount.fullName}</div><div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div></div>
        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing"></i> Quản lý kho</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast"></i> Xử lý đơn hàng</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments"></i> Hỗ trợ khách</a></li>
            <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice"></i> Lịch sử kho</a></li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2"></i> Về Cửa Hàng</a></li>
            <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div><h1 class="h2 fw-bolder text-dark mb-1">Phản hồi & Đánh giá</h1><p class="text-secondary">Lắng nghe ý kiến khách hàng.</p></div>
        </div>

        <div class="d-flex flex-column gap-3">
            <c:forEach items="${reviews}" var="rev">
                <div class="card review-card p-4">
                    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                        <div class="d-flex gap-3">
                            <div class="avatar-user-review rounded-circle text-uppercase">${rev.avatarText}</div>
                            <div>
                                <h6 class="fw-bold mb-0 text-dark">Khách hàng: ${rev.user != null ? rev.user.username : 'Ẩn danh'}</h6>
                                <p class="mb-1 text-muted small">SP: <a href="#" class="text-purple fw-semibold text-decoration-none">#SP-${rev.productID}</a></p>
                                <div class="text-warning small mb-2"><c:forEach begin="1" end="${rev.rating}"><i class="fa-solid fa-star"></i></c:forEach></div>
                            </div>
                        </div>
                        <span class="text-muted small"><fmt:formatDate value="${rev.createdAt}" pattern="dd/MM/yyyy HH:mm"/></span>
                    </div>
                    <div class="bg-light p-3 rounded-3 my-2 text-dark border-start border-3 border-purple">"${rev.comment != null ? rev.comment : 'Trống'}"</div>
                    <div class="d-flex justify-content-end gap-2 mt-2">
                        <button class="btn btn-sm btn-outline-purple" data-bs-toggle="collapse" data-bs-target="#replyBox-${rev.reviewID}"><i class="fa-solid fa-reply me-1"></i>Phản hồi</button>
                    </div>
                    <div class="collapse mt-3" id="replyBox-${rev.reviewID}">
                        <form action="${pageContext.request.contextPath}/CustomerSupportController" method="POST">
                            <input type="hidden" name="reviewID" value="${rev.reviewID}">
                            <div class="input-group"><input type="text" name="replyComment" class="form-control" placeholder="Nhập lời nhắn..." required><button class="btn btn-purple" type="submit">Gửi</button></div>
                        </form>
                    </div>
                </div>
            </c:forEach>
            <c:if test="${empty reviews}"><div class="card border-0 shadow-sm p-5 text-center text-muted rounded-4 bg-white"><h5>Chưa có phản hồi nào!</h5></div></c:if>
        </div>
    </main>
</div>

<jsp:include page="/layout/footer.jsp" />