<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
</main>

<footer class="bg-dark-custom text-white pt-5 pb-3 mt-auto border-top border-warning border-3">
  <div class="container text-md-left">
    <div class="row text-md-left">
      <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 fw-bold text-warning tracking-wide"><i class="fa-solid fa-microchip me-2"></i>CyberCore</h5>
        <p class="text-light opacity-75" style="line-height: 1.8;">Hệ thống bán lẻ linh kiện PC Custom, Laptop và thiết bị mạng chuẩn doanh nghiệp hàng đầu, cam kết chất lượng tuyệt đối.</p>
      </div>
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 fw-bold">Sản phẩm</h5>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Vi xử lý (CPU)</a></p>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Bo mạch chủ (Mainboard)</a></p>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Card đồ họa (VGA)</a></p>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Ổ cứng (SSD)</a></p>
      </div>
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 fw-bold">Hỗ trợ</h5>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Chính sách bảo hành</a></p>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Chính sách đổi trả</a></p>
        <p><a href="#" class="text-light opacity-75 text-decoration-none shadow-hover">Tra cứu đơn hàng</a></p>
      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
        <h5 class="text-uppercase mb-4 fw-bold">Liên hệ</h5>
        <p class="text-light opacity-75"><i class="fas fa-home me-3 text-warning"></i> QTSC, Quận 12, TP. HCM</p>
        <p class="text-light opacity-75"><i class="fas fa-envelope me-3 text-warning"></i> support@cybercore.vn</p>
        <p class="text-light opacity-75"><i class="fas fa-phone me-3 text-warning"></i> +84 900 123 456</p>
      </div>
    </div>
    <hr class="mb-4 border-secondary">
    <div class="row align-items-center">
      <div class="col-md-7 col-lg-8">
        <p class="mb-0 text-light opacity-75">&copy; 2026 Bản quyền thuộc về <strong>CyberCore Enterprise</strong>. Dự án sinh viên SD20307.</p>
      </div>
      <div class="col-md-5 col-lg-4 text-md-end">
        <a href="#" class="text-white me-4 fs-5 opacity-75 shadow-hover"><i class="fab fa-facebook-f"></i></a>
        <a href="#" class="text-white me-4 fs-5 opacity-75 shadow-hover"><i class="fab fa-discord"></i></a>
        <a href="#" class="text-white me-4 fs-5 opacity-75 shadow-hover"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>