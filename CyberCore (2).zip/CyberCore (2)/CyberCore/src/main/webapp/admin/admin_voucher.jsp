<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Voucher</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <h2 class="fw-bolder text-dark tracking-wide mb-4">Mã Khuyến Mãi Hệ Thống</h2>
            <div class="card card-custom bg-white mb-4">
                <div class="card-header bg-white border-bottom border-warning border-3 py-3"><h5 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-ticket text-warning me-2"></i> Trình Thiết Lập Cấu Hình Mã Giảm Giá</h5></div>
                <div class="card-body p-4 bg-light">
                    <form action="voucher" method="post">
                        <input type="hidden" name="voucherID" value="${voucher.voucherID}">
                        <div class="row g-3">
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Mã Voucher (Code)</label><input type="text" name="voucherCode" class="form-control rounded-3 border-primary text-uppercase fw-bold" value="${voucher.voucherCode}" required></div>
                            <div class="col-md-3">
                                <label class="form-label fw-bold small text-uppercase">Loại giảm</label>
                                <select name="discountType" class="form-select rounded-3">
                                    <option value="PERCENT" <c:if test="${voucher.discountType eq 'PERCENT'}">selected</c:if>>PERCENT (%)</option>
                                    <option value="AMOUNT" <c:if test="${voucher.discountType eq 'AMOUNT'}">selected</c:if>>AMOUNT (VNĐ)</option>
                                </select>
                            </div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Giá Trị Trừ</label><input type="number" step="0.01" min="1" name="discountValue" class="form-control rounded-3" value="${voucher.discountValue}" required></div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Giảm Tối Đa</label><input type="number" step="0.01" min="0" name="maxDiscountAmount" class="form-control rounded-3" value="${voucher.maxDiscountAmount}"></div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Đơn Tối Thiểu</label><input type="number" step="0.01" min="0" name="minOrderValue" class="form-control rounded-3" value="${voucher.minOrderValue}" required></div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Số Lượt Sử Dụng</label><input type="number" min="1" name="usageLimit" class="form-control rounded-3" value="${voucher.usageLimit}" required></div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Ngày Bắt Đầu</label><input type="datetime-local" name="startDate" class="form-control rounded-3" value="${startDateValue}" required></div>
                            <div class="col-md-3"><label class="form-label fw-bold small text-uppercase">Ngày Kết Thúc</label><input type="datetime-local" name="endDate" class="form-control rounded-3" value="${endDateValue}" required></div>
                            <div class="col-md-10"><label class="form-label fw-bold small text-uppercase">Mô Tả</label><input type="text" name="description" class="form-control rounded-3" value="${voucher.description}" required></div>
                            <div class="col-md-2 d-flex align-items-end"><div class="form-check form-switch mb-2 fs-5"><input type="checkbox" name="status" class="form-check-input" id="statusVoucher" <c:if test="${voucher == null || voucher.status}">checked</c:if>><label class="form-check-label ms-2 small fw-bold text-success fs-6" for="statusVoucher">Active</label></div></div>
                        </div>
                        <div class="mt-4 text-end">
                            <c:choose><c:when test="${voucher != null}"><a href="voucher" class="btn btn-light border px-4 me-2 fw-bold">Hủy</a><button type="submit" class="btn btn-warning text-dark fw-bold px-4" name="action" value="update">Cập Nhật</button></c:when><c:otherwise><button type="submit" class="btn btn-primary fw-bold px-4 rounded-pill" name="action" value="add">Kích Hoạt Mã</button></c:otherwise></c:choose>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card card-custom">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted small text-uppercase fw-bold"><tr><th class="ps-4">Code</th><th>Loại Trừ</th><th>Đơn Tối Thiểu</th><th>Đã dùng</th><th>Trạng Thái</th><th class="text-center pe-4">Thao tác</th></tr></thead>
                        <tbody>
                        <c:forEach items="${voucherList}" var="v">
                            <tr>
                                <td class="ps-4"><span class="badge bg-primary px-3 py-2 border bg-opacity-10 text-primary fw-bold">${v.voucherCode}</span></td>
                                <td class="fw-bold text-danger">${v.discountType == 'PERCENT' ? 'Giảm ' += v.discountValue += '%' : 'Trừ ' += v.discountValue += 'đ'}</td>
                                <td class="text-muted small">${v.minOrderValue}đ</td>
                                <td class="fw-bold text-dark">${v.usedCount}/${v.usageLimit}</td>
                                <td><span class="badge ${v.status ? 'bg-success' : 'bg-danger'} rounded-pill">${v.status ? 'Active' : 'Vô hiệu'}</span></td>
                                <td class="text-center pe-4">
                                    <a href="voucher?action=edit&id="${v.voucherID}" class="btn btn-sm btn-light border text-warning rounded-circle shadow-sm"><i class="fa-solid fa-pen"></i></a>
                                    <a href="voucher?action=delete&id="${v.voucherID}" class="btn btn-sm btn-light border text-danger rounded-circle shadow-sm ms-1" onclick="return confirm('Xóa voucher?')"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>
</body>
</html>