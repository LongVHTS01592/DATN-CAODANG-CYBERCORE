<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<%@ page import="dao.SystemLogDAO" %>
<%@ page import="com.tuanphat.entity.SystemLog" %>
<%@ page import="java.util.List" %>
<%
    // Kéo dữ liệu từ DB lên ngay khi load trang
    SystemLogDAO logDAO = new SystemLogDAO();
    List<SystemLog> logs = logDAO.getRecentLogs();
    request.setAttribute("systemLogs", logs);
%>
<c:set var="activePage" value="console" />
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore - System Console</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        /* Console UI */
        .console-container { background-color: #000; border: 1px solid #333; border-radius: 8px; box-shadow: 0 0 20px rgba(0, 255, 0, 0.1); }
        .console-header { background-color: #1a1a1a; padding: 10px 15px; border-bottom: 1px solid #333; border-top-left-radius: 8px; border-top-right-radius: 8px; }
        /* Đã thêm bo góc dưới cho body vì bỏ footer đi */
        .console-body { height: 75vh; overflow-y: auto; padding: 15px; font-family: 'Courier New', Courier, monospace; font-size: 0.9rem; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; }
        .blink-cursor { animation: blinker 1s linear infinite; font-weight: bold; }
        @keyframes blinker { 50% { opacity: 0; } }
        ::-webkit-scrollbar { width: 8px; } ::-webkit-scrollbar-track { background: #111; } ::-webkit-scrollbar-thumb { background: #333; border-radius: 4px; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h3 class="fw-bold m-0 text-dark"><i class="fa-solid fa-terminal text-primary"></i> CyberCore Server Console</h3>
            </div>
            <div class="console-container">
                <div class="console-header d-flex justify-content-between align-items-center">
                    <span class="text-secondary small fw-bold">root@cybercore-server:~#</span>
                    <div>
                        <button class="btn btn-sm btn-outline-success border-0 me-2" onclick="location.reload()"><i class="fa-solid fa-rotate-right"></i> Refresh</button>
                        <span class="badge bg-success">Server Online</span><span class="badge bg-secondary ms-1">Port: 8080</span>
                    </div>
                </div>

                <div class="console-body text-success" id="logOutput">
                    <c:forEach items="${systemLogs}" var="log">
                        <div>
                            <span class="text-secondary">[<fmt:formatDate value="${log.createdAt}" pattern="yyyy-MM-dd HH:mm:ss"/>]</span>

                            <c:choose>
                                <c:when test="${log.logLevel == 'ERROR'}">
                                    <span class="text-danger fw-bold">[${log.logLevel}]</span>
                                </c:when>
                                <c:when test="${log.logLevel == 'WARN'}">
                                    <span class="text-warning fw-bold">[${log.logLevel}]</span>
                                </c:when>
                                <c:when test="${log.logLevel == 'COMMAND'}">
                                    <span class="text-info fw-bold">[${log.logLevel}]</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="text-primary fw-bold">[${log.logLevel}]</span>
                                </c:otherwise>
                            </c:choose>

                            <span class="${log.logLevel == 'ERROR' ? 'text-danger' : (log.logLevel == 'COMMAND' ? 'text-light' : '')}">
                                    ${log.logMessage}
                            </span>
                        </div>
                    </c:forEach>
                    <br>
                    <div class="mt-2">System monitoring active...<span class="blink-cursor">_</span></div>
                </div>
            </div>
        </main>
    </div>
</div>
<script>
    // Tự động cuộn xuống dòng Log mới nhất khi load trang
    window.onload = function() {
        var consoleBody = document.getElementById("logOutput");
        consoleBody.scrollTop = consoleBody.scrollHeight;
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>