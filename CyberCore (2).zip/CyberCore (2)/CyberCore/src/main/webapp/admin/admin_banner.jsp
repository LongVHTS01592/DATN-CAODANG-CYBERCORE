<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:set var="activePage" value="banner" />
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>CyberCore Admin - Quản Lý Quảng Cáo</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
    .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
    .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
    .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
    .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
  </style>
</head>
<body>
<div class="container-fluid p-0">
  <div class="row g-0">
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
      <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
      <ul class="nav flex-column nav-menu">
        <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
        <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
      </ul>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
      <h2 class="fw-bolder text-dark tracking-wide mb-4">Hệ Thống Quản Lý Banner Quảng Cáo</h2>

      <div class="row g-4">
        <div class="col-md-4">
          <div class="card card-custom bg-white">
            <div class="card-header bg-white border-bottom border-warning border-3 py-3">
              <h5 class="mb-0 fw-bold text-dark">${empty bannerEdit ? 'Thêm Chiến Dịch' : 'Cập Nhật Chiến Dịch'}</h5>
            </div>
            <div class="card-body p-4 bg-light">
              <form action="${pageContext.request.contextPath}/BannerAdminController" method="POST">
                <input type="hidden" name="action" value="${empty bannerEdit ? 'insert' : 'update'}">
                <input type="hidden" name="id" value="${bannerEdit.bannerID}">

                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Tên chương trình</label>
                  <input type="text" name="title" class="form-control rounded-3" value="${bannerEdit.title}" placeholder="vd: Mua 2 Tặng 1" required>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Vị trí hiển thị</label>
                  <select name="position" class="form-select rounded-3" required>
                    <option value="LEFT" ${bannerEdit.position == 'LEFT' ? 'selected' : ''}>Bên Trái màn hình</option>
                    <option value="RIGHT" ${bannerEdit.position == 'RIGHT' ? 'selected' : ''}>Bên Phải màn hình</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Tên tệp hình ảnh</label>
                  <input type="text" name="imageURL" class="form-control rounded-3" value="${bannerEdit.imageURL}" placeholder="vd: banner_left.jpg" required>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Đường dẫn đích (Link)</label>
                  <input type="text" name="targetLink" class="form-control rounded-3" value="${bannerEdit.targetLink}" placeholder="vd: /product hoặc /voucher">
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Ngày bắt đầu</label>
                  <input type="datetime-local" name="startDate" class="form-control rounded-3" value="${startDateStr}" required>
                </div>
                <div class="mb-3">
                  <label class="form-label fw-bold small text-uppercase">Ngày kết thúc</label>
                  <input type="datetime-local" name="endDate" class="form-control rounded-3" value="${endDateStr}" required>
                </div>
                <div class="mb-4">
                  <label class="form-label fw-bold small text-uppercase">Trạng thái kích hoạt</label>
                  <select name="isActive" class="form-select rounded-3">
                    <option value="1" ${bannerEdit.bannerID == null || bannerEdit.isActive ? 'selected' : ''}>Bật quảng cáo</option>
                    <option value="0" ${bannerEdit.bannerID != null && !bannerEdit.isActive ? 'selected' : ''}>Tắt / Ẩn đi</option>
                  </select>
                </div>
                <button type="submit" class="btn btn-warning w-100 fw-bold text-dark rounded-pill">Lưu Cấu Hình</button>
                <c:if test="${not empty bannerEdit}">
                  <a href="${pageContext.request.contextPath}/BannerAdminController" class="btn btn-light border w-100 fw-bold rounded-pill mt-2">Hủy chỉnh sửa</a>
                </c:if>
              </form>
            </div>
          </div>
        </div>

        <div class="col-md-8">
          <div class="card card-custom">
            <div class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-muted small text-uppercase fw-bold">
                <tr>
                  <th class="ps-4">Tên chiến dịch</th>
                  <th>Vị trí</th>
                  <th>Thời gian chạy</th>
                  <th>Trạng thái</th>
                  <th class="text-center pe-4">Thao tác</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach items="${listBanners}" var="bn">
                  <tr>
                    <td class="ps-4">
                      <div class="fw-bold text-dark">${bn.title}</div>
                      <small class="text-secondary">File: <code>${bn.imageURL}</code></small>
                    </td>
                    <td>
                                            <span class="badge ${bn.position == 'LEFT' ? 'bg-primary' : 'bg-info'} px-2 py-1 rounded">
                                                ${bn.position}
                                            </span>
                    </td>
                    <td class="small text-muted">
                      Từ: <fmt:formatDate value="${bn.startDate}" pattern="dd/MM/yyyy HH:mm"/><br>
                      Đến: <fmt:formatDate value="${bn.endDate}" pattern="dd/MM/yyyy HH:mm"/>
                    </td>
                    <td>
                                            <span class="badge ${bn.isActive ? 'bg-success' : 'bg-danger'} rounded-pill">
                                                ${bn.isActive ? 'Active' : 'Disabled'}
                                            </span>
                    </td>
                    <td class="text-center pe-4">
                      <a href="${pageContext.request.contextPath}/BannerAdminController?action=edit&id=${bn.bannerID}" class="btn btn-sm btn-light border rounded-circle"><i class="fa-solid fa-pen"></i></a>
                      <a href="${pageContext.request.contextPath}/BannerAdminController?action=delete&id=${bn.bannerID}" class="btn btn-sm btn-light border text-danger rounded-circle ms-1" onclick="return confirm('Xóa chiến dịch quảng cáo này?')"><i class="fa-solid fa-trash"></i></a>
                    </td>
                  </tr>
                </c:forEach>
                <c:if test="${empty listBanners}">
                  <tr><td colspan="5" class="text-center py-4 text-muted">Chưa có biểu ngữ quảng cáo nào được thiết lập.</td></tr>
                </c:if>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
</body>
</html>