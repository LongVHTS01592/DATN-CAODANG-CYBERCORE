<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<% dao.CategoryDAO catDAO = new dao.CategoryDAO(); request.setAttribute("dbCategories", catDAO.findAll()); %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>CyberCore Admin - Sản Phẩm</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
    .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
    .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
    .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
    .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
  </style>
</head>
<body>
<div class="container-fluid p-0">
  <div class="row g-0">
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
      <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
      <ul class="nav flex-column nav-menu">
        <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
        <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
        <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
      </ul>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bolder text-dark tracking-wide">Quản Lý Kho Hàng</h2>
        <button id="btnAddNewProduct" class="btn btn-warning fw-bold text-dark rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#productModal"><i class="fa-solid fa-plus me-1"></i> Thêm Linh Kiện</button>
      </div>

      <div class="card card-custom">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
            <tr><th class="ps-4">Ảnh</th><th>Tên Thiết Bị</th><th>Danh Mục</th><th>Giá Bán</th><th>Bảo Hành</th><th>Trạng Thái</th><th class="text-center pe-4">Thao tác</th></tr>
            </thead>
            <tbody>
            <c:forEach items="${products}" var="p">
              <tr>
                <td class="ps-4"><img src="${pageContext.request.contextPath}/images/${p.mainImageURL}" class="rounded-3 shadow-sm border bg-white p-1" style="width:60px;height:60px;object-fit:contain;"></td>
                <td class="fw-bold text-dark">${p.productName}</td>
                <td>
                  <c:set var="currentCatName" value="Chưa phân loại" />
                  <c:forEach items="${dbCategories}" var="cat"><c:if test="${cat.categoryID == p.categoryID}"><c:set var="currentCatName" value="${cat.categoryName}" /></c:if></c:forEach>
                  <span class="badge bg-light text-dark border">${currentCatName}</span>
                </td>
                <td class="text-danger fw-bold"><fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/></td>
                <td class="text-muted small">${p.warrantyMonths} Tháng</td>
                <td><span class="badge ${p.status == 1 ? 'bg-success' : 'bg-secondary'} rounded-pill">${p.status == 1 ? 'Đang bán' : 'Tạm ngưng'}</span></td>
                <td class="text-center pe-4">
                  <a href="${pageContext.request.contextPath}/ProductAdminController?action=edit&id=${p.productID}" class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm"><i class="fa-solid fa-pen"></i></a>
                  <a href="${pageContext.request.contextPath}/ProductAdminController?action=delete&id=${p.productID}" class="btn btn-sm btn-light border text-danger rounded-circle shadow-sm ms-1" onclick="return confirm('Xóa sản phẩm này?');"><i class="fa-solid fa-trash"></i></a>
                </td>
              </tr>
            </c:forEach>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>

<div class="modal fade" id="productModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4 overflow-hidden">
      <div class="modal-header bg-dark text-white border-warning border-bottom border-3">
        <h5 class="modal-title fw-bold" id="modalTitle"><i class="fa-solid fa-box-open text-warning me-2"></i> Thiết Lập Cấu Hình Linh Kiện</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form id="productForm" action="${pageContext.request.contextPath}/ProductAdminController" method="POST">
        <input type="hidden" name="action" id="formAction" value="${not empty productEdit ? 'update' : 'insert'}">
        <input type="hidden" name="id" id="productId" value="${productEdit.productID}">
        <input type="hidden" name="brandID" value="1">
        <input type="hidden" name="originalPrice" value="0">
        <input type="hidden" name="status" value="1">
        <div class="modal-body p-4 bg-light">
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label fw-bold small text-uppercase">Tên Sản Phẩm</label><input type="text" class="form-control rounded-3" name="productName" value="${productEdit.productName}" required></div>
            <div class="col-md-6">
              <label class="form-label fw-bold small text-uppercase">Danh Mục</label>
              <select class="form-select rounded-3" name="categoryID" required>
                <option value="">-- Chọn danh mục --</option>
                <c:forEach items="${dbCategories}" var="cat"><option value="${cat.categoryID}" ${productEdit.categoryID == cat.categoryID ? 'selected' : ''}>${cat.categoryName}</option></c:forEach>
              </select>
            </div>
            <div class="col-md-6"><label class="form-label fw-bold small text-uppercase">Giá Bán (VNĐ)</label><input type="number" class="form-control rounded-3" name="sellPrice" value="${productEdit.sellPrice}" required></div>
            <div class="col-md-6"><label class="form-label fw-bold small text-uppercase">Tên tệp hình ảnh</label><input type="text" class="form-control rounded-3" name="mainImageURL" value="${productEdit.mainImageURL}" placeholder="vd: cpu1.jpg"></div>
            <div class="col-md-12"><label class="form-label fw-bold small text-uppercase">Bảo Hành (Tháng)</label><input type="number" class="form-control rounded-3" name="warrantyMonths" value="${not empty productEdit ? productEdit.warrantyMonths : 12}"></div>
            <div class="col-12"><label class="form-label fw-bold small text-uppercase">Mô Tả</label><textarea class="form-control rounded-3" name="description" rows="3">${productEdit.descriptionText}</textarea></div>
          </div>
        </div>
        <div class="modal-footer bg-white border-0 pt-0 pb-4 pe-4">
          <button type="submit" class="btn btn-warning fw-bold text-dark px-4 shadow-sm">Lưu Dữ Liệu</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    <c:if test="${not empty productEdit}">var myModal = new bootstrap.Modal(document.getElementById('productModal')); myModal.show();</c:if>
  });
</script>
</body>
</html>