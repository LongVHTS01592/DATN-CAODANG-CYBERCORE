<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5 text-center" style="min-height: 60vh;">
    <h2 class="fw-bold mb-4">Hồ Sơ Thành Viên</h2>
    <div class="card border-0 shadow-sm rounded-4 bg-white p-5 max-width-600 mx-auto">
        <i class="fa-solid fa-user-gear fa-4x text-muted mb-3 opacity-50"></i>
        <h5>Hệ thống đang đồng bộ hồ sơ lưu trữ...</h5>
        <p class="text-muted small">Thông tin chi tiết tài khoản của bạn đang được cập nhật theo chuẩn bảo mật mới.</p>
        <a href="${pageContext.request.contextPath}/home" class="btn btn-dark fw-bold rounded-pill px-4 mt-2">Quay lại trang chủ</a>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />