<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!-- Bắt buộc đăng nhập mới được vào trang này -->
<c:if test="${empty sessionScope.userAccount}"><c:redirect url="/login"/></c:if>

<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 60vh;">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden">
                <!-- Phần Header của Profile -->
                <div class="card-header bg-dark text-white p-4 text-center border-bottom border-warning border-3">
                    <img src="https://ui-avatars.com/api/?name=${sessionScope.userAccount.fullName}&size=100&background=random&color=fff&rounded=true" alt="Avatar" class="shadow border border-3 border-white mb-3">
                    <h4 class="fw-bold mb-0">${sessionScope.userAccount.fullName}</h4>
                    <p class="mb-0 text-warning">@${sessionScope.userAccount.username}</p>
                </div>

                <!-- Phần Body Form nhập liệu -->
                <div class="card-body p-5">
                    <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="fa-solid fa-address-card text-primary me-2"></i> Thông Tin Liên Hệ</h5>

                    <!-- Bạn nhớ điều chỉnh lại tên Servlet xử lý cập nhật ở action nhé -->
                    <form action="${pageContext.request.contextPath}/ProfileController" method="post">
                        <input type="hidden" name="action" value="update">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase">Họ và tên</label>
                                <input type="text" class="form-control" name="fullName" value="${sessionScope.userAccount.fullName}" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-muted text-uppercase">Số điện thoại</label>
                                <input type="text" class="form-control" name="phone" value="${sessionScope.userAccount.phone}" required>
                            </div>
                            <div class="col-md-12">
                                <label class="form-label small fw-bold text-muted text-uppercase">Email</label>
                                <input type="email" class="form-control" name="email" value="${sessionScope.userAccount.email}" readonly style="background-color: #f8f9fa;">
                                <small class="text-danger">* Hộp thư Email dùng làm tài khoản nên không thể thay đổi</small>
                            </div>
                        </div>
                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-warning fw-bold text-dark px-4 rounded-pill shadow-sm">Lưu Thay Đổi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />