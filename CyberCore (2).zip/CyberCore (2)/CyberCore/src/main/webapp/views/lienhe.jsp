<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <div class="text-center mb-5">
        <h2 class="fw-bolder text-uppercase tracking-wide">Liên Hệ Hỗ Trợ</h2>
        <div class="mx-auto bg-warning mb-3" style="height: 4px; width: 60px; border-radius: 2px;"></div>
    </div>

    <div class="row g-4">
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-dark-custom text-white">
                <div class="card-body p-5">
                    <h4 class="fw-bold mb-5 text-warning">Thông Tin Trụ Sở</h4>
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-white text-dark rounded-circle d-flex justify-content-center align-items-center fs-5" style="width: 50px; height: 50px;"><i class="fa-solid fa-location-dot"></i></div>
                        <div class="ms-4"><h6 class="mb-1 text-light opacity-75">Địa chỉ</h6><p class="mb-0 fw-semibold">123 Công Viên Phần Mềm Quang Trung, Q12</p></div>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-white text-dark rounded-circle d-flex justify-content-center align-items-center fs-5" style="width: 50px; height: 50px;"><i class="fa-solid fa-phone"></i></div>
                        <div class="ms-4"><h6 class="mb-1 text-light opacity-75">Đường dây nóng</h6><p class="mb-0 fw-semibold">0900 123 456</p></div>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                        <div class="bg-white text-dark rounded-circle d-flex justify-content-center align-items-center fs-5" style="width: 50px; height: 50px;"><i class="fa-solid fa-envelope"></i></div>
                        <div class="ms-4"><h6 class="mb-1 text-light opacity-75">Email hỗ trợ</h6><p class="mb-0 fw-semibold">support@cybercore.vn</p></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="card border-0 shadow-sm rounded-4 h-100 bg-white">
                <div class="card-body p-5">
                    <h4 class="fw-bold mb-4 text-dark">Gửi Tin Nhắn Nhanh</h4>
                    <form>
                        <div class="mb-3"><label class="form-label fw-bold text-secondary small text-uppercase">Họ tên</label><input type="text" class="form-control bg-light border-0 rounded-3"></div>
                        <div class="mb-3"><label class="form-label fw-bold text-secondary small text-uppercase">Email</label><input type="email" class="form-control bg-light border-0 rounded-3"></div>
                        <div class="mb-4"><label class="form-label fw-bold text-secondary small text-uppercase">Nội dung</label><textarea class="form-control bg-light border-0 rounded-3" rows="4"></textarea></div>
                        <button type="submit" class="btn btn-warning btn-lg w-100 fw-bold rounded-pill text-dark">GỬI YÊU CẦU</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />