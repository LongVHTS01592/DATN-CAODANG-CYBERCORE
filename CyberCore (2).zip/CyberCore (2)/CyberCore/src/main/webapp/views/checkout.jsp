<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <div class="text-center mb-5">
        <h2 class="fw-bolder text-uppercase tracking-wide">Thanh Toán Đơn Hàng</h2>
        <div class="mx-auto bg-warning mb-3" style="height: 4px; width: 60px; border-radius: 2px;"></div>
    </div>

    <form action="${pageContext.request.contextPath}/checkout" method="post">
        <div class="row g-4">
            <div class="col-lg-7">
                <div class="card border-0 shadow-sm rounded-4 bg-white p-4 p-md-5 mb-4">
                    <h5 class="fw-bold mb-4"><i class="fa-solid fa-location-dot text-danger me-2"></i>Thông Tin Giao Hàng</h5>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">Họ Tên Người Nhận</label>
                            <input type="text" name="recipientName" class="form-control bg-light border-0 rounded-3 p-2" value="${sessionScope.userAccount.fullName}" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-uppercase">Số Điện Thoại</label>
                            <input type="text" name="phone" class="form-control bg-light border-0 rounded-3 p-2" value="${sessionScope.userAccount.phone}" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small text-uppercase">Địa Chỉ Nhận Hàng</label>
                            <input type="text" name="address" class="form-control bg-light border-0 rounded-3 p-2" placeholder="Số nhà, tên đường, phường/xã, quận/huyện..." required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-bold small text-uppercase">Ghi Chú Đơn Hàng</label>
                            <textarea name="notes" class="form-control bg-light border-0 rounded-3 p-2" rows="2" placeholder="Ghi chú thêm nếu cần..."></textarea>
                        </div>
                    </div>
                </div>

                <div class="card border-0 shadow-sm rounded-4 bg-white p-4 p-md-5">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-credit-card text-primary me-2"></i>Phương Thức Thanh Toán</h5>
                    <div class="form-check mb-3 p-3 border border-2 border-primary rounded-3 bg-primary bg-opacity-10">
                        <input class="form-check-input ms-1" type="radio" name="paymentMethod" id="payCOD" value="COD" checked>
                        <label class="form-check-label ms-2 fw-bold text-dark" for="payCOD">
                            <i class="fa-solid fa-money-bill-1-wave text-success me-1"></i> Thanh toán khi nhận hàng (COD)
                        </label>
                    </div>
                    <div class="form-check p-3 border rounded-3 bg-light">
                        <input class="form-check-input ms-1" type="radio" name="paymentMethod" id="payBank" value="BANK">
                        <label class="form-check-label ms-2 fw-bold text-dark" for="payBank">
                            <i class="fa-solid fa-qrcode text-primary me-1"></i> Chuyển khoản qua mã QR (Duyệt tự động)
                        </label>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="card border-0 shadow-sm rounded-4 bg-white p-4 p-md-5 position-sticky" style="top: 100px;">
                    <h5 class="fw-bold mb-4"><i class="fa-solid fa-receipt text-secondary me-2"></i>Kiểm Trả Đơn Hàng</h5>

                    <ul class="list-group list-group-flush mb-4">
                        <c:set var="total" value="0" />
                        <c:forEach items="${sessionScope.cartDetails}" var="item">
                            <c:set var="sub" value="${item.product.sellPrice * item.quantity}" />
                            <c:set var="total" value="${total + sub}" />
                            <li class="list-group-item px-0 py-3 d-flex justify-content-between align-items-center">
                                <div class="d-flex align-items-center pe-3">
                                    <div class="position-relative me-3">
                                        <img src="${not empty item.product.mainImageURL ? pageContext.request.contextPath += '/images/' += item.product.mainImageURL : 'https://via.placeholder.com/50'}" class="rounded-3 border" style="width: 50px; height: 50px; object-fit: contain;">
                                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-dark">${item.quantity}</span>
                                    </div>
                                    <span class="fw-semibold text-dark small">${item.product.productName}</span>
                                </div>
                                <span class="text-dark fw-bold"><fmt:formatNumber value="${sub}" type="currency" currencySymbol="đ"/></span>
                            </li>
                        </c:forEach>
                    </ul>

                    <div class="d-flex justify-content-between mb-2 text-muted fw-semibold small">
                        <span>Tạm tính:</span>
                        <span><fmt:formatNumber value="${total}" type="currency" currencySymbol="đ"/></span>
                    </div>
                    <c:if test="${not empty sessionScope.discountAmount && sessionScope.discountAmount > 0}">
                        <div class="d-flex justify-content-between mb-2 fw-semibold small">
                            <span>Giảm giá:</span>
                            <span class="text-success">-<fmt:formatNumber value="${sessionScope.discountAmount}" type="currency" currencySymbol="đ"/></span>
                        </div>
                        <c:set var="total" value="${total - sessionScope.discountAmount}" />
                    </c:if>

                    <hr class="border-secondary opacity-25">
                    <div class="d-flex justify-content-between mb-4 mt-3 align-items-center">
                        <span class="fw-bold fs-5 text-uppercase">Thành Tiền:</span>
                        <span class="fw-bolder fs-3 text-danger"><fmt:formatNumber value="${total}" type="currency" currencySymbol="đ"/></span>
                    </div>

                    <button type="submit" class="btn btn-warning btn-lg w-100 fw-bold rounded-pill text-dark">
                        XÁC NHẬN ĐẶT HÀNG <i class="fa-solid fa-arrow-right ms-2"></i>
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<jsp:include page="/layout/footer.jsp" />