<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
  <div class="text-center mb-5">
    <h2 class="fw-bolder text-uppercase tracking-wide">Danh Sách Linh Kiện</h2>
    <div class="mx-auto bg-warning" style="height: 4px; width: 60px; border-radius: 2px;"></div>
  </div>

  <form action="${pageContext.request.contextPath}/product" method="get">
    <div class="row mb-5 justify-content-center bg-white p-4 rounded-4 shadow-sm border mx-0 align-items-center">
      <div class="col-md-5 mb-3 mb-md-0">
        <div class="input-group input-group-lg shadow-sm rounded-pill overflow-hidden">
          <span class="input-group-text bg-white border-end-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" class="form-control border-start-0 border-end-0 ps-0 fs-6" name="keyword" placeholder="Nhập tên linh kiện..." value="${param.keyword}">
        </div>
      </div>
      <div class="col-md-3 mb-3 mb-md-0">
        <select class="form-select form-select-lg fs-6 rounded-pill shadow-sm" name="categoryId">
          <option value="">-- Tất cả danh mục --</option>
          <c:forEach items="${categories}" var="c">
            <option value="${c.categoryID}" ${param.categoryId == c.categoryID ? 'selected' : ''}>${c.categoryName}</option>
          </c:forEach>
        </select>
      </div>
      <div class="col-md-2 mb-3 mb-md-0">
        <select class="form-select form-select-lg fs-6 rounded-pill shadow-sm" name="status">
          <option value="">Trạng thái</option>
          <option value="1">Còn hàng</option>
          <option value="0">Hết hàng</option>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-dark btn-lg w-100 fw-bold rounded-pill shadow-hover fs-6">LỌC NGAY</button>
      </div>
    </div>
  </form>

  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4" id="productGrid">
    <c:forEach items="${products}" var="p">
      <div class="col">
        <div class="card h-100 shadow-sm rounded-4 border-0 shadow-hover overflow-hidden">
          <div class="card-body text-center p-4 d-flex flex-column bg-white">
            <div class="position-relative mb-3">
              <img src="${pageContext.request.contextPath}/images/${p.mainImageURL}" alt="${p.productName}" class="img-fluid rounded-3" style="height: 180px; object-fit: contain;">
              <c:if test="${p.status == 1}"><span class="position-absolute top-0 start-0 badge bg-success mt-2 ms-2 rounded-pill shadow-sm">Còn hàng</span></c:if>
            </div>
            <h6 class="fw-bold text-dark text-truncate mb-1" title="${p.productName}">${p.productName}</h6>
            <p class="small text-muted mb-3 text-truncate" title="${p.descriptionText}">${not empty p.descriptionText ? p.descriptionText : 'Đang cập nhật'}</p>
            <h5 class="text-danger fw-bolder mt-auto mb-3">
              <fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/>
            </h5>
            <form action="${pageContext.request.contextPath}/cart" method="post" class="mt-auto">
              <input type="hidden" name="action" value="add">
              <input type="hidden" name="productId" value="${p.productID}">
              <input type="hidden" name="quantity" value="1">
              <button type="submit" class="btn btn-outline-dark w-100 fw-bold rounded-pill shadow-hover">
                <i class="fa-solid fa-cart-plus me-2"></i> Thêm Vào Giỏ
              </button>
            </form>
          </div>
        </div>
      </div>
    </c:forEach>
    <c:if test="${empty products}">
      <div class="col-12 text-center py-5">
        <i class="fa-solid fa-box-open fa-4x text-muted mb-3 opacity-50"></i>
        <h5 class="text-muted fw-bold">Không tìm thấy mã sản phẩm nào!</h5>
      </div>
    </c:if>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />