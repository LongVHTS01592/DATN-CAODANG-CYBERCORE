<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5 d-flex align-items-center justify-content-center" style="min-height: 70vh;">
  <div class="w-100" style="max-width: 600px;">
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
      <div class="card-header bg-dark-custom text-white text-center py-4 border-bottom border-success border-3">
        <h4 class="mb-0 fw-bold tracking-wide"><i class="fa-solid fa-user-plus text-success me-2"></i> TẠO TÀI KHOẢN</h4>
      </div>
      <div class="card-body p-4 p-md-5 bg-white">
        <c:if test="${not empty error}">
          <div class="alert alert-danger text-center fw-bold rounded-3 border-0 shadow-sm small mb-4"><i class="fa-solid fa-triangle-exclamation me-1"></i> ${error}</div>
        </c:if>
        <form action="${pageContext.request.contextPath}/register" method="post">
          <div class="row">
            <div class="col-md-6 mb-4">
              <label class="form-label fw-bold text-secondary small text-uppercase">Tên đăng nhập <span class="text-danger">*</span></label>
              <input type="text" class="form-control bg-light border-0 rounded-3" name="username" placeholder="Tạo Username đăng nhập" required>
            </div>
            <div class="col-md-6 mb-4">
              <label class="form-label fw-bold text-secondary small text-uppercase">Họ và Tên</label>
              <input type="text" class="form-control bg-light border-0 rounded-3" name="fullname" placeholder="Họ tên đầy đủ" required>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6 mb-4">
              <label class="form-label fw-bold text-secondary small text-uppercase">Email</label>
              <input type="email" class="form-control bg-light border-0 rounded-3" name="email" placeholder="example@gmail.com" required>
            </div>
            <div class="col-md-6 mb-4">
              <label class="form-label fw-bold text-secondary small text-uppercase">Số điện thoại</label>
              <input type="text" class="form-control bg-light border-0 rounded-3" name="phone" placeholder="0123456789" required>
            </div>
          </div>
          <div class="mb-5">
            <label class="form-label fw-bold text-secondary small text-uppercase">Mật khẩu</label>
            <input type="password" class="form-control bg-light border-0 rounded-3" name="password" placeholder="Tạo mật khẩu bảo mật" required>
          </div>
          <button type="submit" class="btn btn-success btn-lg w-100 fw-bold rounded-pill shadow-hover">GHI DANH THÀNH VIÊN</button>
        </form>
        <div class="mt-4 text-center">
          <p class="text-muted mb-0">Đã là thành viên? <a href="${pageContext.request.contextPath}/login" class="text-decoration-none fw-bold text-dark">Đăng nhập</a></p>
        </div>
      </div>
    </div>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />