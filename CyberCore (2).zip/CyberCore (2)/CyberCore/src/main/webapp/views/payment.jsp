<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container d-flex justify-content-center align-items-center mt-5 mb-5" style="min-height: 60vh;">
    <div class="card border-0 shadow-lg rounded-4 p-4 p-md-5 bg-white" style="max-width: 500px; width: 100%;">
        <div class="text-center mb-4">
            <h3 class="fw-bolder text-uppercase text-dark tracking-wide"><i class="fa-solid fa-qrcode text-primary me-2"></i>Thanh Toán</h3>
            <p class="text-muted small mt-2">Mở ứng dụng Ngân hàng di động (Mobile Banking) quét mã để thanh toán tự động.</p>
        </div>

        <div class="bg-light p-3 rounded-4 text-center mb-4 border border-light">
            <img src="${requestScope.qrCodeUrl}" alt="Mã QR Chuyển Khoản CyberCore" class="img-fluid rounded-3 shadow-sm" style="max-width: 250px;" />
        </div>

        <div class="border-top border-secondary border-opacity-25 pt-4">
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted fw-semibold">Mã đơn hàng:</span>
                <span class="fw-bold text-dark fs-5">#${requestScope.orderId}</span>
            </div>
            <div class="d-flex justify-content-between mb-4 align-items-center">
                <span class="text-muted fw-semibold">Số tiền cần trả:</span>
                <span class="fw-bolder text-danger fs-3">
                    <fmt:formatNumber value="${requestScope.totalAmount}" type="currency" currencySymbol="đ"/>
                </span>
            </div>
        </div>

        <div class="alert alert-primary small d-flex align-items-start border-0 rounded-3 shadow-sm mb-4" role="alert">
            <i class="fa-solid fa-circle-info fs-5 me-3 mt-1"></i>
            <div>
                Hệ thống đã nhúng sẵn <strong>Số tiền</strong> và <strong>Nội dung</strong> vào mã QR. Vui lòng giữ nguyên thông tin khi quét để hệ thống duyệt tự động.
            </div>
        </div>

        <div class="d-grid gap-2 mt-2">
            <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg fw-bold rounded-pill shadow-hover text-dark">
                XÁC NHẬN ĐÃ CHUYỂN KHOẢN
            </a>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />