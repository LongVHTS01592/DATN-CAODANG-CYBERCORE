<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${empty sessionScope.userAccount}"><c:redirect url="/login"/></c:if>

<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 60vh;">
  <h2 class="fw-bold mb-4 text-center">Lịch Sử Mua Hàng Của <span class="text-primary">${sessionScope.userAccount.fullName}</span></h2>

  <c:choose>
    <%-- TRƯỜNG HỢP 1: NẾU TÀI KHOẢN CHƯA CÓ ĐƠN HÀNG NÀO --%>
    <c:when test="${empty bills}">
      <div class="card border-0 shadow-sm rounded-4 bg-white p-5 mx-auto text-center" style="max-width: 600px;">
        <i class="fa-solid fa-clock-rotate-left fa-4x text-muted mb-3 opacity-50"></i>
        <h5>Chưa có hóa đơn giao dịch nào</h5>
        <p class="text-muted small">Hệ thống chưa tìm thấy đơn hàng lịch sử nào liên kết với tài khoản này.</p>
        <a href="${pageContext.request.contextPath}/product" class="btn btn-warning fw-bold rounded-pill text-dark px-4 mt-2 shadow-sm">Khám Phá Cửa Hàng</a>
      </div>
    </c:when>

    <%-- TRƯỜNG HỢP 2: NẾU TÀI KHOẢN ĐÃ CÓ ĐƠN HÀNG --%>
    <c:otherwise>
      <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-dark text-uppercase small">
            <tr>
              <th class="ps-4">Mã Hóa Đơn</th>
              <th>Ngày Đặt</th>
              <th>Người Nhận</th>
              <th>Tổng Thanh Toán</th>
              <th>Tiến Độ</th>
              <th class="text-center pe-4">Chi Tiết</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach items="${bills}" var="b">
              <tr>
                <td class="ps-4 fw-bold text-secondary">#ORD-${b.billID}</td>
                <td class="text-muted"><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                <td class="fw-semibold">${b.shippingRecipientName}</td>
                <td class="fw-bold text-danger"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                <td>
                                        <span class="badge rounded-pill ${b.orderStatus == 'Pending' ? 'bg-warning text-dark' : (b.orderStatus == 'Completed' ? 'bg-success' : (b.orderStatus == 'Cancelled' ? 'bg-danger' : 'bg-info'))}">
                                            ${b.orderStatus}
                                        </span>
                </td>
                <td class="text-center pe-4">
                  <button class="btn btn-sm btn-outline-dark rounded-circle" data-bs-toggle="modal" data-bs-target="#clientOrderModal${b.billID}"><i class="fa-solid fa-eye"></i></button>
                </td>
              </tr>
            </c:forEach>
            </tbody>
          </table>
        </div>
      </div>
    </c:otherwise>
  </c:choose>
</div>

<%-- MODAL CHI TIẾT ĐƠN HÀNG (Tương tự như bên Admin) --%>
<c:if test="${not empty bills}">
  <c:forEach items="${bills}" var="b">
    <div class="modal fade" id="clientOrderModal${b.billID}" tabindex="-1">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
          <div class="modal-header bg-dark text-white border-bottom border-warning border-3">
            <h5 class="modal-title fw-bold">Tra Cứu Đơn Hàng: #ORD-${b.billID}</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4 bg-light">
            <div class="bg-white p-3 rounded-3 shadow-sm border mb-4">
              <h6 class="fw-bold border-bottom pb-2 mb-3 text-uppercase small text-muted">Thông Tin Vận Chuyển</h6>
              <p class="mb-1"><i class="fa-solid fa-user text-primary me-2"></i> <strong>${b.shippingRecipientName}</strong> - ${b.shippingPhone}</p>
              <p class="mb-0"><i class="fa-solid fa-location-dot text-danger me-2"></i> ${b.shippingAddressText}</p>
              <c:if test="${not empty b.notes}">
                <p class="mb-0 mt-2 text-muted"><i class="fa-solid fa-comment-dots text-secondary me-2"></i> Ghi chú: ${b.notes}</p>
              </c:if>
            </div>
            <h6 class="fw-bold mb-3 text-uppercase small text-muted">Linh Kiện Đã Đặt</h6>
            <table class="table table-bordered bg-white shadow-sm align-middle mb-0">
              <thead class="table-light text-muted small text-uppercase">
              <tr>
                <th class="ps-3">Tên Thiết Bị</th>
                <th class="text-center">Số Lượng</th>
                <th class="text-end pe-3">Đơn Giá Mua</th>
              </tr>
              </thead>
              <tbody>
              <c:forEach items="${b.details}" var="detail">
                <tr>
                  <td class="ps-3 fw-semibold">${detail.product.productName}</td>
                  <td class="text-center">${detail.quantity}</td>
                  <td class="text-danger fw-bold text-end pe-3"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td>
                </tr>
              </c:forEach>
              </tbody>
              <tfoot class="table-light">
              <tr>
                <td colspan="2" class="text-end fw-bold text-uppercase">Tổng Cần Thanh Toán:</td>
                <td class="text-danger fw-bolder text-end pe-3 fs-5"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </c:forEach>
</c:if>

<jsp:include page="/layout/footer.jsp" />