<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5 text-center" style="min-height: 60vh;">
  <h2 class="fw-bold mb-4">Lịch Sử Mua Hàng</h2>
  <div class="card border-0 shadow-sm rounded-4 bg-white p-5 max-width-600 mx-auto">
    <i class="fa-solid fa-clock-rotate-left fa-4x text-muted mb-3 opacity-50"></i>
    <h5>Chưa ghi nhận hóa đơn giao dịch</h5>
    <p class="text-muted small">Hệ thống chưa tìm thấy đơn hàng lịch sử nào liên kết với tài khoản này.</p>
    <a href="${pageContext.request.contextPath}/product" class="btn btn-warning fw-bold rounded-pill text-dark px-4 mt-2">Mua sắm ngay</a>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />