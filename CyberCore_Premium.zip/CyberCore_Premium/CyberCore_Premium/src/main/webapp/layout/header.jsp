<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="dao.BannerDAO" %>
<%@ page import="entity.Banner" %>
<%@ page import="java.util.List" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%
    // Tự động gọi DAO quét database xem có chương trình sale nào đang bật không
    try {
        BannerDAO clientBannerDAO = new BannerDAO();
        List<Banner> activeBanners = clientBannerDAO.getActiveBanners();
        request.setAttribute("activeBanners", activeBanners);
    } catch (Exception e) {
        e.printStackTrace();
    }
%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CyberCore - Hệ Thống Linh Kiện Cấp Doanh Nghiệp</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8f9fa;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main { flex: 1; }
        .bg-dark-custom { background-color: #121212; }
        .text-warning { color: #ffc107 !important; }
        .shadow-hover:hover {
            box-shadow: 0 .5rem 1rem rgba(0,0,0,.15)!important;
            transform: translateY(-3px);
            transition: all 0.3s ease;
        }

        /* CSS Cố định 2 banner quảng cáo chạy dọc 2 bên hông */
        .floating-banner-left { position: fixed; top: 120px; left: 15px; z-index: 1050; width: 140px; transition: all 0.3s; }
        .floating-banner-right { position: fixed; top: 120px; right: 15px; z-index: 1050; width: 140px; transition: all 0.3s; }
        .floating-banner-left img, .floating-banner-right img { width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.2); }

        /* Ẩn quảng cáo khi vào bằng điện thoại/tablet để không che khuất màn hình */
        @media (max-width: 1300px) {
            .floating-banner-left, .floating-banner-right { display: none !important; }
        }
    </style>
</head>
<body>

<c:forEach items="${activeBanners}" var="b">
<div class="${b.position == 'LEFT' ? 'floating-banner-left' : 'floating-banner-right'} shadow-hover">
    <a href="${not empty b.targetLink ? pageContext.request.contextPath.concat(b.targetLink) : '#'}">
        <img src="${pageContext.request.contextPath}/images/${b.imageURL}" alt="${b.title}" onerror="this.src='https://via.placeholder.com/140x400?text=CyberCore+Sale'">
    </a>
</div>
</c:forEach>

<main>