<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark-custom sticky-top shadow-sm border-bottom border-secondary border-opacity-50">
    <div class="container">

        <a class="navbar-brand fw-bold text-uppercase fs-4 tracking-wide" href="${pageContext.request.contextPath}/home">
            <i class="fa-solid fa-microchip text-warning me-1"></i> Cyber<span class="text-warning">Core</span>
        </a>

        <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4 fw-semibold">
                <li class="nav-item"><a class="nav-link px-3" href="${pageContext.request.contextPath}/home">Trang chủ</a></li>
                <li class="nav-item"><a class="nav-link px-3" href="${pageContext.request.contextPath}/product">Cửa hàng</a></li>
                <li class="nav-item"><a class="nav-link px-3" href="${pageContext.request.contextPath}/views/gioithieu.jsp">Giới thiệu</a></li>
                <li class="nav-item"><a class="nav-link px-3" href="${pageContext.request.contextPath}/views/lienhe.jsp">Liên hệ</a></li>
            </ul>

            <form action="${pageContext.request.contextPath}/product" method="get" class="d-flex mx-auto w-25 mb-3 mb-lg-0" style="min-width: 250px;">
                <div class="input-group">
                    <input type="text" name="keyword" class="form-control bg-dark text-white border-secondary" placeholder="Tìm linh kiện...">
                    <button class="btn btn-outline-warning" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </form>

            <ul class="navbar-nav ms-auto align-items-center">

                <li class="nav-item me-4 position-relative">
                    <a class="nav-link fs-5 text-white" href="${pageContext.request.contextPath}/cart">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span class="position-absolute top-25 start-100 translate-middle badge rounded-pill bg-warning text-dark border border-dark" style="font-size: 0.6em;">
              <c:out value="${sessionScope.cart != null ? sessionScope.cart.size() : 0}" />
            </span>
                    </a>
                </li>

                <c:if test="${empty sessionScope.userAccount}">
                    <li class="nav-item"><a class="nav-link fw-semibold" href="${pageContext.request.contextPath}/login">Đăng nhập</a></li>
                    <li class="nav-item"><a class="btn btn-warning fw-bold px-4 ms-lg-2 rounded-pill shadow-sm" href="${pageContext.request.contextPath}/register">Đăng ký</a></li>
                </c:if>

                <c:if test="${not empty sessionScope.userAccount}">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle fw-bold text-warning d-flex align-items-center" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <img src="https://ui-avatars.com/api/?name=${sessionScope.userAccount.fullName}&background=ffc107&color=000&rounded=true" class="me-2 shadow-sm" width="30" height="30" alt="Avatar">
                                ${sessionScope.userAccount.fullName}
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-3 rounded-3">
                            <c:if test="${sessionScope.userAccount.roleID == 1}">
                                <li><a class="dropdown-item fw-bold text-primary py-2" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px text-center"></i> Quản Trị Viên</a></li>
                                <li><hr class="dropdown-divider"></li>
                            </c:if>

                            <c:if test="${sessionScope.userAccount.roleID == 2}">
                                <li><a class="dropdown-item fw-bold text-success py-2" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-clipboard-user me-2 w-20px text-center"></i> Bảng Nhân Viên</a></li>
                                <li><hr class="dropdown-divider"></li>
                            </c:if>

                            <li><a class="dropdown-item py-2" href="${pageContext.request.contextPath}/profile"><i class="fa-solid fa-user me-2 text-secondary w-20px text-center"></i> Tài khoản</a></li>
                            <li><a class="dropdown-item py-2" href="${pageContext.request.contextPath}/order-history"><i class="fa-solid fa-clock-rotate-left me-2 text-secondary w-20px text-center"></i> Đơn hàng của tôi</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger fw-semibold py-2" href="${pageContext.request.contextPath}/login?action=logout"><i class="fa-solid fa-right-from-bracket me-2 w-20px text-center"></i> Đăng xuất</a></li>
                        </ul>
                    </li>
                </c:if>

            </ul>
        </div>
    </div>
</nav>