<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5 d-flex align-items-center justify-content-center" style="min-height: 65vh;">
    <div class="w-100" style="max-width: 450px;">
        <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="card-header bg-dark-custom text-white text-center py-4 border-bottom border-warning border-3">
                <h4 class="mb-0 fw-bold tracking-wide"><i class="fa-solid fa-user-shield text-warning me-2"></i> ĐĂNG NHẬP</h4>
            </div>

            <div class="card-body p-4 p-md-5 bg-white">

                <c:if test="${not empty error}">
                    <div class="alert alert-danger text-center fw-bold rounded-3 border-0 shadow-sm small mb-4">
                        <i class="fa-solid fa-triangle-exclamation me-1"></i> ${error}
                    </div>
                </c:if>

                <form action="${pageContext.request.contextPath}/login" method="post">
                    <div class="mb-4">
                        <label class="form-label fw-bold text-secondary small text-uppercase">Tên đăng nhập</label>
                        <input type="text" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6 p-3" name="username" placeholder="Nhập tài khoản hoặc email..." value="${param.username}" required>
                    </div>

                    <div class="mb-4">
                        <div class="d-flex justify-content-between">
                            <label class="form-label fw-bold text-secondary small text-uppercase">Mật khẩu</label>
                            <a href="#" class="text-decoration-none small fw-bold text-primary">Quên mật khẩu?</a>
                        </div>
                        <input type="password" class="form-control form-control-lg bg-light border-0 rounded-3 fs-6 p-3" name="password" placeholder="Nhập mật khẩu" required>
                    </div>

                    <button type="submit" class="btn btn-warning btn-lg w-100 fw-bold rounded-pill shadow-hover mt-2 py-3 text-dark">
                        ĐĂNG NHẬP HỆ THỐNG
                    </button>
                </form>

                <div class="mt-4 text-center">
                    <p class="text-muted mb-0">Chưa có thẻ thành viên? <a href="${pageContext.request.contextPath}/register" class="text-decoration-none fw-bold text-primary">Tạo tài khoản ngay</a></p>
                </div>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />