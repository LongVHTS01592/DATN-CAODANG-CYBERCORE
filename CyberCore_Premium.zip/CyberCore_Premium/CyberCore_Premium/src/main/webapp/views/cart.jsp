<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <h3 class="text-uppercase fw-bold mb-4 tracking-wide"><i class="fa-solid fa-cart-shopping text-warning me-2"></i> Giỏ Hàng Của Bạn</h3>

    <c:choose>
        <c:when test="${empty cartDetails}">
            <div class="alert text-center py-5 shadow-sm rounded-4 bg-white border-0">
                <i class="fa-solid fa-cart-arrow-down fa-5x mb-4 text-muted opacity-50"></i>
                <h4 class="fw-bold text-dark">Giỏ hàng đang trống!</h4>
                <p class="text-muted mb-4">Bạn chưa chọn linh kiện nào. Hãy khám phá ngay nhé.</p>
                <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg fw-bold rounded-pill px-5 shadow-hover">ĐẾN CỬA HÀNG NGAY</a>
            </div>
        </c:when>

        <c:otherwise>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 border-white">
                                <thead class="table-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-4 py-3">Sản phẩm</th>
                                    <th class="py-3">Đơn giá</th>
                                    <th style="width: 130px;" class="py-3 text-center">Số lượng</th>
                                    <th class="py-3 text-end">Thành tiền</th>
                                    <th class="text-center py-3 pe-4">Xóa</th>
                                </tr>
                                </thead>
                                <tbody>
                                <c:set var="totalAmount" value="0" />
                                <c:forEach items="${cartDetails}" var="item">
                                    <c:set var="subtotal" value="${item.product.sellPrice * item.quantity}" />
                                    <c:set var="totalAmount" value="${totalAmount + subtotal}" />
                                    <tr>
                                        <td class="ps-4 py-3">
                                            <div class="d-flex align-items-center">
                                                <c:choose>
                                                    <c:when test="${not empty item.product.mainImageURL}">
                                                        <img src="${pageContext.request.contextPath}/images/${item.product.mainImageURL}" class="rounded-3 shadow-sm me-3 bg-light" style="width: 60px; height: 60px; object-fit: contain;">
                                                    </c:when>
                                                    <c:otherwise>
                                                        <img src="https://via.placeholder.com/60" class="rounded-3 shadow-sm me-3 bg-light" style="width: 60px; height: 60px; object-fit: contain;">
                                                    </c:otherwise>
                                                </c:choose>
                                                <span class="fw-bold text-dark">${item.product.productName}</span>
                                            </div>
                                        </td>
                                        <td class="text-dark fw-semibold"><fmt:formatNumber value="${item.product.sellPrice}" type="currency" currencySymbol="đ"/></td>
                                        <td>
                                            <form action="${pageContext.request.contextPath}/cart" method="post" class="m-0">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="cartDetailId" value="${item.cartDetailID}">
                                                <input type="number" name="quantity" class="form-control text-center rounded-pill bg-light border-0 fw-bold" value="${item.quantity}" min="1" onchange="this.form.submit()">
                                            </form>
                                        </td>
                                        <td class="text-danger fw-bold text-end"><fmt:formatNumber value="${subtotal}" type="currency" currencySymbol="đ"/></td>
                                        <td class="text-center pe-4">
                                            <form action="${pageContext.request.contextPath}/cart" method="post" class="m-0">
                                                <input type="hidden" name="action" value="remove">
                                                <input type="hidden" name="cartDetailId" value="${item.cartDetailID}">
                                                <button type="submit" class="btn btn-sm btn-outline-danger rounded-circle shadow-hover"><i class="fa-solid fa-xmark"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                </c:forEach>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 bg-white">
                        <div class="card-body p-4 p-xl-5">
                            <h5 class="fw-bolder mb-4 text-uppercase"><i class="fa-solid fa-file-invoice-dollar text-secondary me-2"></i> Tóm tắt đơn hàng</h5>

                            <div class="d-flex justify-content-between mb-3 text-muted fw-semibold">
                                <span>Tổng tiền hàng:</span>
                                <span><fmt:formatNumber value="${totalAmount}" type="currency" currencySymbol="đ"/></span>
                            </div>

                            <c:if test="${not empty discountAmount && discountAmount > 0}">
                                <div class="d-flex justify-content-between mb-3 fw-semibold">
                                    <span>Giảm giá (<span class="text-success">${voucherCode}</span>):</span>
                                    <span class="text-danger">-<fmt:formatNumber value="${discountAmount}" type="currency" currencySymbol="đ"/></span>
                                </div>
                            </c:if>

                            <div class="d-flex justify-content-between mb-4 text-muted fw-semibold">
                                <span>Phí giao hàng:</span>
                                <span class="text-success">Miễn phí</span>
                            </div>

                            <hr class="border-secondary opacity-25">

                            <div class="d-flex justify-content-between mb-4 align-items-center">
                                <span class="fw-bold fs-6 text-uppercase">Tổng cộng:</span>
                                <span class="fw-bolder fs-4 text-danger">
                                    <c:set var="finalAmount" value="${totalAmount - (discountAmount != null ? discountAmount : 0)}" />
                                    <fmt:formatNumber value="${finalAmount}" type="currency" currencySymbol="đ"/>
                                </span>
                            </div>

                            <a href="${pageContext.request.contextPath}/checkout" class="btn btn-warning w-100 fw-bold rounded-pill py-3 mb-3 shadow-hover text-dark tracking-wide">XÁC NHẬN ĐẶT HÀNG</a>
                            <a href="${pageContext.request.contextPath}/checkout-payment?amount=${finalAmount}" class="btn btn-dark w-100 fw-bold rounded-pill py-3 mb-4 shadow-hover">
                                <i class="fa-solid fa-qrcode me-2 text-warning"></i> THANH TOÁN QR
                            </a>

                            <div class="bg-light p-3 rounded-4">
                                <form action="${pageContext.request.contextPath}/cart" method="post">
                                    <input type="hidden" name="action" value="applyVoucher">
                                    <label class="form-label fw-bold text-muted small text-uppercase mb-2"><i class="fa-solid fa-ticket me-1"></i> Mã Khuyến Mãi</label>
                                    <div class="input-group">
                                        <input type="text" name="voucherCode" class="form-control border-0 shadow-none" placeholder="Nhập mã voucher..." value="${voucherCode}">
                                        <button type="submit" class="btn btn-success fw-bold px-3">Áp dụng</button>
                                    </div>
                                </form>
                            </div>

                            <c:if test="${not empty voucherMessage}">
                                <div class="alert alert-info mt-3 mb-0 text-center rounded-3 border-0 shadow-sm small fw-semibold">
                                    <i class="fa-solid fa-circle-info me-1"></i> ${voucherMessage}
                                </div>
                            </c:if>
                        </div>
                    </div>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<jsp:include page="/layout/footer.jsp" />