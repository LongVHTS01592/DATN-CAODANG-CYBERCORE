<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>

<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div id="cyberCoreCarousel" class="carousel slide carousel-fade shadow-sm" data-bs-ride="carousel" style="border-bottom: 5px solid #ffc107;">
    <div class="carousel-indicators">
        <button type="button" data-bs-target="#cyberCoreCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
        <button type="button" data-bs-target="#cyberCoreCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
        <button type="button" data-bs-target="#cyberCoreCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
        <div class="carousel-item active" style="min-height: 75vh; background: linear-gradient(rgba(18, 18, 18, 0.8), rgba(18, 18, 18, 0.8)), url('https://images.unsplash.com/photo-1587202372775-e229f172b9d7?q=80&w=1920') center/cover no-repeat;">
            <div class="carousel-caption d-flex flex-column justify-content-center h-100" style="bottom: 0;">
                <div class="container text-center">
                    <h1 class="display-4 fw-bolder text-white tracking-wide">Build PC Đỉnh Cao <br><span class="text-warning">Theo Cách Của Bạn</span></h1>
                    <p class="lead mt-3 text-light opacity-75">Nơi những cỗ máy sức mạnh bắt đầu từ một linh kiện nhỏ nhất.</p>
                    <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg mt-4 fw-bold rounded-pill px-5 shadow-sm shadow-hover">KHÁM PHÁ CỬA HÀNG &rarr;</a>
                </div>
            </div>
        </div>
        <div class="carousel-item" style="min-height: 75vh; background: linear-gradient(rgba(18, 18, 18, 0.8), rgba(18, 18, 18, 0.8)), url('https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?q=80&w=1920') center/cover no-repeat;">
            <div class="carousel-caption d-flex flex-column justify-content-center h-100" style="bottom: 0;">
                <div class="container text-center">
                    <h1 class="display-4 fw-bolder text-white tracking-wide">Linh Kiện Siêu Cấp <br><span class="text-warning">Bứt Phá Hiệu Năng</span></h1>
                    <p class="lead mt-3 text-light opacity-75">Đầy đủ các dòng CPU, VGA, RAM thế hệ mới nhất đến từ các đối tác hàng đầu.</p>
                    <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg mt-4 fw-bold rounded-pill px-5 shadow-sm shadow-hover">XEM SẢN PHẨM &rarr;</a>
                </div>
            </div>
        </div>
        <div class="carousel-item" style="min-height: 75vh; background: linear-gradient(rgba(18, 18, 18, 0.8), rgba(18, 18, 18, 0.8)), url('https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=1920') center/cover no-repeat;">
            <div class="carousel-caption d-flex flex-column justify-content-center h-100" style="bottom: 0;">
                <div class="container text-center">
                    <h1 class="display-4 fw-bolder text-white tracking-wide">Giải Pháp Toàn Diện <br><span class="text-warning">Bảo Hành Dài Lâu</span></h1>
                    <p class="lead mt-3 text-light opacity-75">Hỗ trợ kỹ thuật chuyên sâu, lắp ráp chuyên nghiệp và tối ưu tản nhiệt hệ thống.</p>
                    <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg mt-4 fw-bold rounded-pill px-5 shadow-sm shadow-hover">MUA SẮM NGAY &rarr;</a>
                </div>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#cyberCoreCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#cyberCoreCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>

<div class="container my-5 py-4">
    <div class="row g-4 text-center">
        <div class="col-md-4">
            <div class="p-4 bg-white rounded-4 shadow-sm border-0 h-100 shadow-hover">
                <i class="fa-solid fa-truck-fast fa-3x text-primary mb-3"></i>
                <h5 class="fw-bold">Giao Hàng Toàn Quốc</h5>
                <p class="text-muted small">Miễn phí vận chuyển cho mọi hóa đơn linh kiện từ 5.000.000đ.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="p-4 bg-white rounded-4 shadow-sm border-0 h-100 shadow-hover">
                <i class="fa-solid fa-shield-halved fa-3x text-success mb-3"></i>
                <h5 class="fw-bold">Bảo Hành 1 Đổi 1</h5>
                <p class="text-muted small">Cam kết hàng chính hãng, đổi trả và bảo hành thần tốc trong vòng 30 ngày.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="p-4 bg-white rounded-4 shadow-sm border-0 h-100 shadow-hover">
                <i class="fa-solid fa-headset fa-3x text-warning mb-3"></i>
                <h5 class="fw-bold">Hỗ Trợ Kỹ Thuật 24/7</h5>
                <p class="text-muted small mb-3">Đội ngũ tư vấn viên am hiểu phần cứng luôn sẵn sàng túc trực phục vụ.</p>
                <a href="${pageContext.request.contextPath}/views/lienhe.jsp" class="btn btn-outline-dark btn-sm fw-bold rounded-pill px-4">LIÊN HỆ NGAY</a>
            </div>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />