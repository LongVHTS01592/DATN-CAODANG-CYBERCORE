<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 75vh; font-family: 'Inter', sans-serif;">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/home" class="text-decoration-none text-muted">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="${pageContext.request.contextPath}/product" class="text-decoration-none text-muted">Danh mục</a></li>
            <li class="breadcrumb-item active fw-bold text-dark" aria-current="page">${product.productName}</li>
        </ol>
    </nav>

    <div class="row g-5">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white">
                <div id="productImagesCarousel" class="carousel slide" data-bs-ride="false">
                    <div class="carousel-inner text-center">
                        <div class="carousel-item active">
                            <img src="${pageContext.request.contextPath}/images/${product.mainImageURL}"
                                 class="d-block w-100 img-fluid rounded-3"
                                 style="max-height: 420px; object-fit: contain;"
                                 alt="${product.productName}"
                                 onerror="this.src='https://via.placeholder.com/400?text=CyberCore'">
                        </div>

                        <c:forEach items="${subImages}" var="img">
                            <div class="carousel-item">
                                <c:set var="imgUrl" value="${img.imageURL.startsWith('http') ? img.imageURL : pageContext.request.contextPath.concat('/images/').concat(img.imageURL)}" />
                                <img src="${imgUrl}"
                                     class="d-block w-100 img-fluid rounded-3"
                                     style="max-height: 420px; object-fit: contain;"
                                     alt="Ảnh chi tiết linh kiện"
                                     onerror="this.src='https://via.placeholder.com/400?text=CyberCore+Detail'">
                            </div>
                        </c:forEach>
                    </div>

                    <button class="carousel-control-prev" type="button" data-bs-target="#productImagesCarousel" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon bg-dark rounded-circle p-3" aria-hidden="true"></span>
                        <span class="visually-hidden">Trước</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#productImagesCarousel" data-bs-slide="next">
                        <span class="carousel-control-next-icon bg-dark rounded-circle p-3" aria-hidden="true"></span>
                        <span class="visually-hidden">Sau</span>
                    </button>
                </div>

                <div class="d-flex justify-content-center gap-2 mt-3 overflow-auto py-1">
                    <img src="${pageContext.request.contextPath}/images/${product.mainImageURL}"
                         class="img-thumbnail img-indicator active border-warning border-2"
                         style="width: 65px; height: 65px; object-fit: contain; cursor: pointer;"
                         data-bs-target="#productImagesCarousel" data-bs-slide-to="0"
                         onerror="this.src='https://via.placeholder.com/65?text=CyberCore'">

                    <c:forEach items="${subImages}" var="img" varStatus="status">
                        <c:set var="subImgUrl" value="${img.imageURL.startsWith('http') ? img.imageURL : pageContext.request.contextPath.concat('/images/').concat(img.imageURL)}" />
                        <img src="${subImgUrl}"
                             class="img-thumbnail img-indicator"
                             style="width: 65px; height: 65px; object-fit: contain; cursor: pointer;"
                             data-bs-target="#productImagesCarousel" data-bs-slide-to="${status.index + 1}"
                             onerror="this.src='https://via.placeholder.com/65?text=Detail'">
                    </c:forEach>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="ps-md-2">
                <span class="badge bg-dark text-warning px-3 py-2 rounded-pill mb-2 fw-bold">
                    <i class="fa-solid fa-shield-halved me-1"></i> Bảo hành ${product.warrantyMonths} Tháng
                </span>
                <h1 class="fw-extrabold text-dark mb-3">${product.productName}</h1>

                <div class="mb-4 animate__animated animate__fadeIn">
                    <h2 class="text-danger fw-bolder fs-1 d-inline-block me-3 mb-0">
                        <fmt:formatNumber value="${product.sellPrice}" type="currency" currencySymbol="đ"/>
                    </h2>
                    <c:if test="${not empty product.originalPrice && product.originalPrice > product.sellPrice}">
                        <span class="text-muted text-decoration-line-through fs-5">
                            <fmt:formatNumber value="${product.originalPrice}" type="currency" currencySymbol="đ"/>
                        </span>
                    </c:if>
                </div>

                <hr class="opacity-25 my-4">

                <h5 class="fw-bold mb-2 text-secondary small text-uppercase tracking-wide">Thông số kỹ thuật linh kiện</h5>
                <div class="text-muted lh-relaxed p-3 bg-light rounded-3 shadow-inner" style="white-space: pre-line; min-height: 120px;">
                    <c:choose>
                        <c:when test="${not empty product.descriptionText}">${product.descriptionText}</c:when>
                        <c:otherwise>Linh kiện phần cứng cao cấp chính hãng CyberCore, thông số kỹ thuật chi tiết đang được cập nhật thêm từ nhà sản xuất.</c:otherwise>
                    </c:choose>
                </div>

                <c:choose>
                    <c:when test="${product.stockQuantity > 0}">
                        <form action="${pageContext.request.contextPath}/cart" method="post" class="mt-4">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="productId" value="${product.productID}">

                            <div class="row g-3 align-items-center">
                                <div class="col-auto">
                                    <label class="fw-bold text-secondary small">SỐ LƯỢNG MUA:</label>
                                </div>
                                <div class="col-3 col-lg-2">
                                    <input type="number" name="quantity" class="form-control text-center fw-bold rounded-3 border-secondary-subtle py-2 shadow-sm" value="1" min="1" max="${product.stockQuantity}" required>
                                </div>
                                <div class="col-auto">
                                    <span class="small text-success fw-semibold"><i class="fa-solid fa-boxes-stacked me-1"></i> (Còn lại ${product.stockQuantity} thiết bị sẵn hàng)</span>
                                </div>
                                <div class="col-12 mt-4">
                                    <button type="submit" class="btn btn-warning text-dark btn-lg fw-bold px-4 py-3 w-100 rounded-pill shadow-sm text-uppercase shadow-hover">
                                        <i class="fa-solid fa-cart-plus me-2"></i> THÊM VÀO GIỎ HÀNG
                                    </button>
                                </div>
                            </div>
                        </form>
                    </c:when>

                    <c:otherwise>
                        <div class="mt-4">
                            <div class="row g-3 align-items-center mb-3">
                                <div class="col-auto">
                                    <label class="fw-bold text-secondary small">SỐ LƯỢNG MUA:</label>
                                </div>
                                <div class="col-3 col-lg-2">
                                    <input type="number" class="form-control text-center fw-bold rounded-3 bg-light border-secondary-subtle py-2" value="0" disabled>
                                </div>
                                <div class="col-auto">
                                    <span class="small text-danger fw-bold"><i class="fa-solid fa-triangle-exclamation me-1"></i> (Hết hàng tạm thời)</span>
                                </div>
                            </div>
                            <button type="button" class="btn btn-secondary text-white btn-lg fw-bold px-4 py-3 w-100 rounded-pill text-uppercase opacity-75" disabled style="cursor: not-allowed;">
                                <i class="fa-solid fa-circle-ban me-2"></i> TẠM HẾT HÀNG TRÊN HỆ THỐNG
                            </button>
                        </div>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var carouselElement = document.getElementById('productImagesCarousel');
        var indicators = document.querySelectorAll('.img-indicator');

        if (carouselElement) {
            carouselElement.addEventListener('slide.bs.carousel', function (e) {
                indicators.forEach(function(img) {
                    img.classList.remove('border-warning', 'border-2');
                });
                if(indicators[e.to]) {
                    indicators[e.to].classList.add('border-warning', 'border-2');
                }
            });
        }
    });
</script>

<jsp:include page="/layout/footer.jsp" />