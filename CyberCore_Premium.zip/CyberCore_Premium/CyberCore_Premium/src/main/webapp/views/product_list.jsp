<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
  <div class="text-center mb-5">
    <h2 class="fw-bolder text-uppercase tracking-wide">Danh Sách Linh Kiện</h2>
    <div class="mx-auto bg-warning" style="height: 4px; width: 60px; border-radius: 2px;"></div>
  </div>

  <form action="${pageContext.request.contextPath}/product" method="get">
    <div class="row mb-5 justify-content-center bg-white p-4 rounded-4 shadow-sm border mx-0 align-items-center g-3">
      <div class="col-lg-5 col-md-4">
        <div class="input-group input-group-lg shadow-sm rounded-pill overflow-hidden border">
          <span class="input-group-text bg-white border-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" class="form-control border-0 ps-0 fs-6 shadow-none" name="keyword" placeholder="Nhập tên linh kiện cần tìm..." value="${param.keyword}">
        </div>
      </div>
      <div class="col-lg-3 col-md-3">
        <select class="form-select form-select-lg fs-6 rounded-pill shadow-sm border" name="categoryId">
          <option value="">-- Tất cả danh mục --</option>
          <c:forEach items="${categories}" var="c">
            <option value="${c.categoryID}" ${param.categoryId == c.categoryID ? 'selected' : ''}>${c.categoryName}</option>
          </c:forEach>
        </select>
      </div>
      <div class="col-lg-2 col-md-3">
        <select class="form-select form-select-lg fs-6 rounded-pill shadow-sm border" name="status">
          <option value="">-- Trạng thái --</option>
          <option value="1" ${param.status == '1' ? 'selected' : ''}>Còn hàng</option>
          <option value="0" ${param.status == '0' ? 'selected' : ''}>Hết hàng</option>
        </select>
      </div>
      <div class="col-lg-2 col-md-2">
        <button type="submit" class="btn btn-dark btn-lg w-100 fw-bold rounded-pill shadow-hover fs-6 py-2.5">LỌC NGAY</button>
      </div>
    </div>
  </form>

  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4" id="productGrid">
    <c:forEach items="${products}" var="p">
      <div class="col">
        <div class="card h-100 shadow-sm rounded-4 border-0 shadow-hover overflow-hidden transition-all">
          <div class="card-body text-center p-4 d-flex flex-column bg-white">

            <div class="position-relative mb-3 bg-light rounded-3 p-2 d-flex align-items-center justify-content-center" style="height: 180px;">
              <c:choose>
                <c:when test="${not empty p.mainImageURL}">
                  <img src="${pageContext.request.contextPath}/images/${p.mainImageURL}" alt="${p.productName}" class="img-fluid" style="max-height: 160px; object-fit: contain;" onerror="this.src='https://via.placeholder.com/200?text=CyberCore'">
                </c:when>
                <c:otherwise>
                  <img src="https://via.placeholder.com/200?text=No+Image" alt="No image available" class="img-fluid" style="max-height: 160px; object-fit: contain;">
                </c:otherwise>
              </c:choose>

              <c:if test="${p.status == 1}">
                <span class="position-absolute top-0 start-0 badge bg-success mt-2 ms-2 rounded-pill shadow-sm px-2 py-1 small">Còn hàng</span>
              </c:if>
              <c:if test="${p.status != 1}">
                <span class="position-absolute top-0 start-0 badge bg-secondary mt-2 ms-2 rounded-pill shadow-sm px-2 py-1 small">Hết hàng</span>
              </c:if>
            </div>

            <h6 class="fw-bold text-dark text-truncate mb-1" title="${p.productName}">${p.productName}</h6>
            <p class="small text-muted mb-3 text-truncate-2" style="min-height: 40px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="${p.descriptionText}">
                ${not empty p.descriptionText ? p.descriptionText : 'Thông số kỹ thuật đang được cập nhật liên tục từ nhà sản xuất.'}
            </p>

            <h5 class="text-danger fw-bolder mt-auto mb-3">
              <fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/>
            </h5>

            <form action="${pageContext.request.contextPath}/cart" method="post" class="mt-auto">
              <input type="hidden" name="action" value="add">
              <input type="hidden" name="productId" value="${p.productID}">
              <input type="hidden" name="quantity" value="1">
              <button type="submit" class="btn ${p.status == 1 ? 'btn-outline-dark' : 'btn-light disabled'} w-100 fw-bold rounded-pill shadow-hover transition-all" ${p.status != 1 ? 'disabled' : ''}>
                <i class="fa-solid fa-cart-plus me-2"></i> ${p.status == 1 ? 'Thêm Vào Giỏ' : 'Hết Hàng'}
              </button>
            </form>

          </div>
        </div>
      </div>
    </c:forEach>
  </div>

  <c:if test="${empty products}">
    <div class="text-center py-5">
      <i class="fa-solid fa-box-open fa-5x text-muted mb-3 opacity-50"></i>
      <h4 class="text-dark fw-bold">Không tìm thấy sản phẩm phù hợp!</h4>
      <p class="text-muted small">Vui lòng thay đổi từ khóa tìm kiếm hoặc điều chỉnh lại bộ lọc danh mục.</p>
    </div>
  </c:if>
</div>

<jsp:include page="/layout/footer.jsp" />