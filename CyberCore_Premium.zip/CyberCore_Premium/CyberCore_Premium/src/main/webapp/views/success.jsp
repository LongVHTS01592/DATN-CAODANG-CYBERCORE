<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <div class="card border-0 shadow-lg rounded-4 bg-white p-4 p-md-5 mx-auto" style="max-width: 650px;">

        <div class="text-center mb-4">
            <div class="text-success mb-3 animate__animated animate__zoomIn">
                <i class="fa-solid fa-circle-check" style="font-size: 4.5rem;"></i>
            </div>
            <h2 class="fw-bold text-success text-uppercase tracking-wide">Đặt Hàng Thành Công</h2>
            <p class="text-muted">Cảm ơn bạn đã tin tưởng và mua sắm cấu hình tại <strong>CyberCore</strong>.<br>Đơn hàng của bạn đã được ghi nhận thành công trên hệ thống quản trị.</p>
            <div class="mx-auto bg-success bg-opacity-25 my-3" style="height: 2px; width: 120px;"></div>
        </div>

        <div class="row g-3 text-start px-md-3 bg-light p-4 rounded-4 border border-light shadow-inner">
            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Mã đơn hàng</span>
                <strong class="text-dark fs-5">#ORD-${sessionScope.recentBill.billID}</strong>
            </div>
            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Thời gian đặt mua</span>
                <strong class="text-dark">
                    <c:choose>
                        <c:when test="${not empty sessionScope.recentBill.orderDate}">
                            <fmt:formatDate value="${sessionScope.recentBill.orderDate}" pattern="dd/MM/yyyy HH:mm"/>
                        </c:when>
                        <c:otherwise>Hệ thống ghi nhận vừa xong</c:otherwise>
                    </c:choose>
                </strong>
            </div>
            <div class="col-12"><hr class="m-0 border-secondary opacity-10"></div>

            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Người nhận linh kiện</span>
                <strong class="text-dark">${sessionScope.recentBill.shippingRecipientName}</strong>
            </div>
            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Số điện thoại</span>
                <strong class="text-dark">${sessionScope.recentBill.shippingPhone}</strong>
            </div>
            <div class="col-12 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Địa chỉ bàn giao kiện hàng</span>
                <strong class="text-dark">${sessionScope.recentBill.shippingAddressText}</strong>
            </div>
            <div class="col-12"><hr class="m-0 border-secondary opacity-10"></div>

            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Hình thức thanh toán</span>
                <strong class="text-primary">
                    <c:choose>
                        <c:when test="${sessionScope.recentPaymentMethod == 'BANK'}"><i class="fa-solid fa-qrcode me-1"></i> Chuyển khoản nhanh qua mã QR</c:when>
                        <c:otherwise><i class="fa-solid fa-truck-glove me-1"></i> Thanh toán tiền mặt khi nhận hàng (COD)</c:otherwise>
                    </c:choose>
                </strong>
            </div>
            <div class="col-6 mb-2">
                <span class="text-muted d-block small text-uppercase fw-bold">Tổng thanh toán (Đã bao gồm VAT)</span>
                <strong class="fs-4 text-danger">
                    <fmt:formatNumber value="${sessionScope.recentBill.totalAmount}" type="currency" currencySymbol="đ"/>
                </strong>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 justify-content-center mt-4 pt-2">
            <a href="${pageContext.request.contextPath}/home" class="btn btn-warning fw-bold px-4 py-2.5 rounded-pill text-dark shadow-hover">
                <i class="fa-solid fa-house mt-0.5 me-2"></i>Về Trang Chủ
            </a>
            <a href="${pageContext.request.contextPath}/orders" class="btn btn-dark fw-bold px-4 py-2.5 rounded-pill shadow-hover">
                <i class="fa-solid fa-box-open mt-0.5 me-2"></i>Kiểm Tra Đơn Của Tôi
            </a>
        </div>

    </div>
</div>

<%-- DỌN DẸP SESSION BẰNG JSTL THAY VÌ JAVA SCRIPTLET:
     Giúp ngăn chặn lỗi lặp dữ liệu hoặc hiển thị sai lệch khi khách hàng bấm F5 làm mới lại trang web --%>
<c:remove var="recentBill" scope="session" />
<c:remove var="recentPaymentMethod" scope="session" />

<jsp:include page="/layout/footer.jsp" />