<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Kiểm tra bảo mật: Nếu chưa đăng nhập thì đẩy về trang login --%>
<c:if test="${empty sessionScope.userAccount}">
    <c:redirect url="/login"/>
</c:if>

<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 60vh;">
    <div class="text-center mb-5">
        <h2 class="fw-bolder text-uppercase tracking-wide">Lịch Sử Mua Hàng</h2>
        <p class="text-muted">Quản lý và theo dõi tiến độ các gói linh kiện của <span class="fw-bold text-dark">${sessionScope.userAccount.fullName}</span></p>
        <div class="mx-auto bg-warning" style="height: 4px; width: 60px; border-radius: 2px;"></div>
    </div>

    <c:choose>
        <%-- TRƯỜNG HỢP 1: NẾU TÀI KHOẢN CHƯA CÓ ĐƠN HÀNG NÀO --%>
        <c:when test="${empty bills}">
            <div class="card border-0 shadow-sm rounded-4 bg-white p-5 mx-auto text-center" style="max-width: 600px;">
                <i class="fa-solid fa-clock-rotate-left fa-4x text-muted mb-3 opacity-50"></i>
                <h5 class="fw-bold text-dark">Chưa có hóa đơn giao dịch nào</h5>
                <p class="text-muted small mb-4">Hệ thống chưa tìm thấy đơn hàng lịch sử nào liên kết với tài khoản này.</p>
                <a href="${pageContext.request.contextPath}/product" class="btn btn-warning fw-bold rounded-pill text-dark px-5 py-2 shadow-hover">Khám Phá Cửa Hàng Ngay</a>
            </div>
        </c:when>

        <%-- TRƯỜNG HỢP 2: NẾU TÀI KHOẢN ĐÃ CÓ ĐƠN HÀNG --%>
        <c:otherwise>
            <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark text-uppercase small">
                        <tr>
                            <th class="ps-4 py-3">Mã Hóa Đơn</th>
                            <th>Ngày Đặt</th>
                            <th>Người Nhận</th>
                            <th>Tổng Thanh Toán</th>
                            <th>Tiến Độ</th>
                            <th class="text-center pe-4">Chi Tiết</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach items="${bills}" var="b">
                            <tr>
                                <td class="ps-4 fw-bold text-secondary">#ORD-${b.billID}</td>
                                <td class="text-muted"><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                                <td class="fw-semibold text-dark">${b.shippingRecipientName}</td>
                                <td class="fw-bold text-danger"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                                <td>
                    <span class="badge rounded-pill px-3 py-2
                        ${b.orderStatus == 'Pending' ? 'bg-warning text-dark' :
                          (b.orderStatus == 'Completed' ? 'bg-success text-white' :
                          (b.orderStatus == 'Cancelled' ? 'bg-danger text-white' : 'bg-info text-dark'))}">
                        <i class="fa-solid
                            ${b.orderStatus == 'Pending' ? 'fa-spinner fa-spin' :
                              (b.orderStatus == 'Completed' ? 'fa-circle-check' :
                              (b.orderStatus == 'Cancelled' ? 'fa-circle-xmark' : 'fa-truck'))} me-1"></i>
                        ${b.orderStatus == 'Pending' ? 'Chờ xử lý' :
                                (b.orderStatus == 'Completed' ? 'Đã hoàn thành' :
                                        (b.orderStatus == 'Cancelled' ? 'Đã hủy' : b.orderStatus))}
                    </span>
                                </td>
                                <td class="text-center pe-4">
                                    <button class="btn btn-sm btn-outline-dark rounded-circle p-2 shadow-sm shadow-hover" data-bs-toggle="modal" data-bs-target="#clientOrderModal${b.billID}">
                                        <i class="fa-solid fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<%-- MODAL CHI TIẾT ĐƠN HÀNG --%>
<c:if test="${not empty bills}">
    <c:forEach items="${bills}" var="b">
        <div class="modal fade" id="clientOrderModal${b.billID}" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
                    <div class="modal-header bg-dark text-white border-bottom border-warning border-3 py-3">
                        <h5 class="modal-title fw-bold text-uppercase tracking-wide"><i class="fa-solid fa-receipt text-warning me-2"></i>Chi Tiết Đơn Hàng: #ORD-${b.billID}</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body p-4 bg-light">
                        <div class="bg-white p-4 rounded-4 shadow-sm border-0 mb-4">
                            <h6 class="fw-bold border-bottom pb-2 mb-3 text-uppercase small text-muted tracking-wider"><i class="fa-solid fa-truck-ramp-box me-1"></i> Thông Tin Giao Nhận</h6>
                            <p class="mb-2"><i class="fa-solid fa-user text-primary me-2"></i> <strong>Họ tên:</strong> ${b.shippingRecipientName} - <span class="text-secondary">${b.shippingPhone}</span></p>
                            <p class="mb-2"><i class="fa-solid fa-location-dot text-danger me-2"></i> <strong>Địa chỉ:</strong> ${b.shippingAddressText}</p>
                            <c:if test="${not empty b.notes}">
                                <p class="mb-0 mt-2 text-muted bg-light p-2 rounded-3 small"><i class="fa-solid fa-comment-dots text-secondary me-2"></i> <strong>Ghi chú:</strong> ${b.notes}</p>
                            </c:if>
                        </div>

                        <h6 class="fw-bold mb-3 text-uppercase small text-muted tracking-wider"><i class="fa-solid fa-microchip me-1"></i> Danh Sách Linh Kiện Đã Đặt</h6>
                        <div class="table-responsive rounded-3 shadow-sm bg-white border overflow-hidden">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-3">Tên Thiết Bị</th>
                                    <th class="text-center" style="width: 100px;">Số Lượng</th>
                                    <th class="text-end pe-3" style="width: 180px;">Đơn Giá</th>
                                </tr>
                                </thead>
                                <tbody>
                                <c:forEach items="${b.details}" var="detail">
                                    <tr>
                                        <td class="ps-3 fw-bold text-dark">${detail.product.productName}</td>
                                        <td class="text-center fw-semibold bg-light">${detail.quantity}</td>
                                        <td class="text-danger fw-bold text-end pe-3"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td>
                                    </tr>
                                </c:forEach>
                                </tbody>
                                <tfoot class="table-light border-top">
                                <tr>
                                    <td colspan="2" class="text-end fw-bold text-uppercase text-muted py-3">Tổng giá trị thanh toán:</td>
                                    <td class="text-danger fw-bolder text-end pe-3 fs-5 py-3"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </c:forEach>
</c:if>

<jsp:include page="/layout/footer.jsp" />