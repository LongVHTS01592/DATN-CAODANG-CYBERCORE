<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%-- Cơ chế bảo mật: Bắt buộc đăng nhập mới cho phép truy cập --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 60vh;">
  <div class="row justify-content-center g-4">
    <div class="col-lg-8">
      <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden mb-4">

        <%-- Background động nếu có coverUrl, ngược lại dùng màu đen mặc định --%>
        <div class="card-header p-4 text-center border-bottom border-warning border-3"
             style="background: ${not empty sessionScope.userAccount.coverUrl ? 'url(' += sessionScope.userAccount.coverUrl += ') center/cover no-repeat' : '#212529'}; position: relative;">

          <div style="background: rgba(0,0,0,0.4); position: absolute; top:0; left:0; width:100%; height:100%;"></div>
          <div style="position: relative; z-index: 1;">
            <img src="https://ui-avatars.com/api/?name=${sessionScope.userAccount.fullName}&size=100&background=ffc107&color=121212&rounded=true&bold=true"
                 alt="Avatar" class="shadow border border-3 border-white mb-3">
            <h4 class="fw-bold mb-0 text-white">${sessionScope.userAccount.fullName}</h4>
            <p class="mb-0 text-warning">@${sessionScope.userAccount.username}</p>
          </div>
        </div>

        <div class="card-body p-4 p-md-5">
          <h5 class="fw-bold mb-4 border-bottom pb-2"><i class="fa-solid fa-address-card text-warning me-2"></i> Thông Tin Liên Hệ</h5>

          <c:if test="${not empty error}">
            <div class="alert alert-danger rounded-3 border-0 shadow-sm small mb-4">
              <i class="fa-solid fa-triangle-exclamation me-2"></i> ${error}
            </div>
          </c:if>
          <c:if test="${not empty msg}">
            <div class="alert alert-success rounded-3 border-0 shadow-sm small mb-4">
              <i class="fa-solid fa-circle-check me-2"></i> ${msg}
            </div>
          </c:if>

          <form action="${pageContext.request.contextPath}/ProfileController" method="post" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update">

            <div class="row g-4">
              <div class="col-md-6">
                <label class="form-label small fw-bold text-secondary text-uppercase">Họ và tên</label>
                <input type="text" class="form-control bg-light border-0 p-2.5 rounded-3 fw-semibold text-dark" name="fullName" value="${sessionScope.userAccount.fullName}" required>
              </div>
              <div class="col-md-6">
                <label class="form-label small fw-bold text-secondary text-uppercase">Số điện thoại</label>
                <input type="text" class="form-control bg-light border-0 p-2.5 rounded-3 fw-semibold text-dark" name="phone" value="${sessionScope.userAccount.phone}" required>
              </div>

              <div class="col-md-12">
                <label class="form-label small fw-bold text-secondary text-uppercase">Ảnh Bìa Trang Cá Nhân (Upload từ máy)</label>
                <input type="file" class="form-control bg-light border-0 p-2 rounded-3 text-dark" name="coverFile" accept="image/*">
                <small class="text-muted"><i class="fa-solid fa-image me-1"></i> Định dạng hỗ trợ: JPG, PNG, GIF (Tối đa 10MB)</small>
              </div>

              <div class="col-md-12">
                <label class="form-label small fw-bold text-secondary text-uppercase">Địa chỉ Email</label>
                <input type="email" class="form-control border-0 p-2.5 rounded-3 text-muted" name="email" value="${sessionScope.userAccount.email}" readonly style="background-color: #f1f3f5;">
                <small class="text-danger d-block mt-2"><i class="fa-solid fa-circle-info me-1"></i> Hộp thư Email được sử dụng định danh tài khoản gốc nên không thể thay đổi.</small>
              </div>
            </div>

            <div class="mt-4 text-end">
              <button type="submit" class="btn btn-warning fw-bold text-dark px-4 rounded-pill shadow-sm shadow-hover">Lưu Thông Tin</button>
            </div>
          </form>
        </div>
      </div>

      <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden">
        <div class="card-body p-4 p-md-5">
          <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-2">
            <h5 class="fw-bold mb-0"><i class="fa-solid fa-map-location-dot text-success me-2"></i> Sổ Địa Chỉ Giao Hàng</h5>
            <button class="btn btn-sm btn-outline-success rounded-pill fw-bold" data-bs-toggle="modal" data-bs-target="#addAddressModal">
              <i class="fa-solid fa-plus me-1"></i> Thêm Địa Chỉ
            </button>
          </div>

          <c:choose>
            <c:when test="${not empty sessionScope.userAccount.addresses}">
              <div class="row g-3">
                <c:forEach items="${sessionScope.userAccount.addresses}" var="addr">
                  <div class="col-12">
                    <div class="border rounded-3 p-3 bg-light position-relative">
                      <div class="d-flex justify-content-between align-items-center">
                        <div>
                          <h6 class="fw-bold text-dark mb-1">
                              ${addr.recipientName} <span class="text-secondary fw-normal">| ${addr.phone}</span>
                            <c:if test="${addr.isDefault}">
                                <span class="badge bg-warning text-dark ms-2" style="font-size: 0.7rem;">
                                    <i class="fa-solid fa-star me-1"></i> Mặc định
                                </span>
                            </c:if>
                          </h6>
                          <p class="text-muted small mb-0">${addr.detailedAddress}</p>
                        </div>

                          <%-- CẬP NHẬT: Nút set mặc định dành cho những địa chỉ chưa được chọn --%>
                        <c:if test="${!addr.isDefault}">
                          <form action="${pageContext.request.contextPath}/UserAddressController" method="post" class="m-0">
                            <input type="hidden" name="action" value="setDefault">
                            <input type="hidden" name="addressID" value="${addr.addressID}">
                            <button type="submit" class="btn btn-sm btn-outline-secondary rounded-pill" style="font-size: 0.75rem;">
                              Thiết lập mặc định
                            </button>
                          </form>
                        </c:if>

                      </div>
                    </div>
                  </div>
                </c:forEach>
              </div>
            </c:when>
            <c:otherwise>
              <div class="text-center py-4 text-muted">
                <i class="fa-regular fa-map fa-2x mb-2 text-black-50"></i>
                <p class="mb-0">Bạn chưa có địa chỉ nào. Hãy thêm để đặt hàng nhanh chóng hơn!</p>
              </div>
            </c:otherwise>
          </c:choose>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="addAddressModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow rounded-4">
      <div class="modal-header bg-success text-white border-0">
        <h5 class="modal-title fw-bold">Thêm Địa Chỉ Mới</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form action="${pageContext.request.contextPath}/UserAddressController" method="post">
        <input type="hidden" name="action" value="add">
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label small fw-bold text-secondary">Tên Người Nhận</label>
            <input type="text" name="recipientName" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-bold text-secondary">Số Điện Thoại Nhận Hàng</label>
            <input type="text" name="phone" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label small fw-bold text-secondary">Địa Chỉ Chi Tiết</label>
            <textarea name="detailedAddress" class="form-control" rows="3" required placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/TP"></textarea>
          </div>
          <div class="form-check mt-3">
            <input class="form-check-input" type="checkbox" name="isDefault" id="isDefaultCheck">
            <label class="form-check-label fw-bold text-dark small" for="isDefaultCheck">
              Đặt làm địa chỉ giao hàng mặc định
            </label>
          </div>
        </div>
        <div class="modal-footer border-0 bg-light">
          <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Hủy</button>
          <button type="submit" class="btn btn-success fw-bold rounded-pill px-4">Xác Nhận Đăng Ký</button>
        </div>
      </form>
    </div>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />