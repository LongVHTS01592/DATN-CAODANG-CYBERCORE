<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <div class="text-center mb-5">
        <h2 class="fw-bolder text-uppercase tracking-wide">Giới Thiệu</h2>
        <div class="mx-auto bg-warning mb-3" style="height: 4px; width: 60px; border-radius: 2px;"></div>
        <p class="text-muted">Chào mừng bạn đến với hệ sinh thái công nghệ CyberCore Enterprise.</p>
    </div>

    <div class="row align-items-center bg-white p-4 p-md-5 rounded-4 shadow-sm border-0">
        <div class="col-lg-6 mb-4 mb-lg-0 text-center">
            <img src="${pageContext.request.contextPath}/images/cybercore.png" class="img-fluid rounded-4 shadow" alt="CyberCore Headquarters" style="max-height: 400px; object-fit: cover;" onerror="this.src='https://via.placeholder.com/600x400?text=CyberCore+Enterprise'">
        </div>
        <div class="col-lg-6 ps-lg-5">
            <h3 class="fw-bold mb-4 text-dark">Tầm Nhìn & Sứ Mệnh</h3>
            <p class="text-muted" style="line-height: 1.8;">Chúng tôi là đơn vị chuyên phân phối linh kiện phần cứng máy tính, thiết bị mạng và giải pháp lắp ráp PC Custom chuẩn doanh nghiệp hàng đầu tại Việt Nam.</p>
            <p class="text-muted" style="line-height: 1.8;">CyberCore luôn đặt tính ổn định phần cứng và sự hài lòng tuyệt đối của quý khách lên vị trí hàng đầu. Đội ngũ kỹ thuật viên giàu kinh nghiệm của chúng tôi luôn sẵn sàng hỗ trợ 24/7.</p>
            <a href="${pageContext.request.contextPath}/product" class="btn btn-dark btn-lg fw-bold rounded-pill px-5 shadow-hover mt-3">Trải Nghiệm Ngay</a>
        </div>
    </div>
</div>

<jsp:include page="/layout/footer.jsp" />