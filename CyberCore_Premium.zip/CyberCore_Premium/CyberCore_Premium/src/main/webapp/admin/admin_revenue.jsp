<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="revenue" />

<%-- Phân quyền: Chỉ Admin mới được truy cập --%>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>CyberCore Admin - Báo Cáo Doanh Thu</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
    .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
    .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
    .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
    .w-20px { width: 20px; text-align: center; }
    .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
  </style>
</head>
<body>
<div class="container-fluid p-0">
  <div class="row g-0">
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
      <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
      <ul class="nav flex-column nav-menu">
        <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Tài Khoản</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
        <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
        <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
      </ul>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
      <h2 class="fw-bolder text-dark tracking-wide mb-4">Phân Tích Doanh Số Bán Hàng</h2>

      <div class="row g-4">
        <div class="col-lg-7">
          <div class="card card-custom p-4 h-100 bg-white shadow-sm">
            <h5 class="fw-bold mb-4 text-dark"><i class="fa-solid fa-chart-area text-primary me-2"></i> Đường Biểu Đồ Thống Kê Dòng Tiền</h5>
            <div style="width: 100%;">
              <canvas id="revenueChart"></canvas>
            </div>
          </div>
        </div>

        <div class="col-lg-5">
          <div class="card card-custom h-100 shadow-sm">
            <div class="card-header bg-dark text-white border-bottom border-warning border-3 py-3">
              <h5 class="mb-0 fw-bold"><i class="fa-solid fa-table-list text-warning me-2"></i> Số Liệu Chi Tiết Đơn Hoàn Tất</h5>
            </div>
            <div class="table-responsive bg-white">
              <table class="table table-hover align-middle mb-0">
                <thead class="table-light text-muted small text-uppercase">
                <tr>
                  <th class="ps-4">Tháng</th>
                  <th class="text-center">Số Hóa Đơn</th>
                  <th class="text-end pe-4">Tổng Thu</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach var="item" items="${revenueList}">
                  <tr>
                    <td class="ps-4 fw-bold text-dark">${item.reportMonth}/${item.reportYear}</td>
                    <td class="text-center"><span class="badge bg-primary bg-opacity-10 text-primary px-3 rounded-pill">${item.totalOrders} Đơn</span></td>
                    <td class="text-end pe-4 fw-bolder text-danger">
                      <fmt:formatNumber value="${item.totalRevenue}" type="currency" currencySymbol="đ"/>
                    </td>
                  </tr>
                </c:forEach>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<script>
  const chartLabels = [];
  const chartData = [];

  // Đẩy dữ liệu từ JSP vào mảng của JS.
  // Dùng unshift để đảo ngược mảng (giúp vẽ biểu đồ từ tháng cũ đến tháng mới)
  <c:forEach var="item" items="${revenueList}">
  chartLabels.unshift('${item.reportMonth}/${item.reportYear}');
  chartData.unshift(${item.totalRevenue});
  </c:forEach>

  const ctx = document.getElementById('revenueChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: chartLabels,
      datasets: [{
        label: 'Doanh Thu (VNĐ)',
        data: chartData,
        backgroundColor: 'rgba(56, 189, 248, 0.2)',
        borderColor: 'rgba(56, 189, 248, 1)',
        borderWidth: 3,
        pointBackgroundColor: '#ffc107',
        fill: true,
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        }
      },
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
</body>
</html>