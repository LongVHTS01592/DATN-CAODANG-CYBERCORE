<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Phân quyền: Chỉ Admin (roleID = 1 hoặc 2) mới được truy cập --%>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}">
    <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Quản Lý Đơn Hàng</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .w-20px { width: 20px; text-align: center; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
        .table > :not(caption) > * > * { padding: 1rem 0.75rem; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Tài Khoản</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bolder text-dark tracking-wide m-0">Quản Lý Đơn Hàng</h2>
            </div>

            <div class="card card-custom">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 bg-white">
                        <thead class="table-light text-muted small text-uppercase fw-bold">
                        <tr>
                            <th class="ps-4">Mã Hóa Đơn</th>
                            <th>Người Nhận</th>
                            <th>Ngày Đặt</th>
                            <th class="text-center">Số Lượng</th>
                            <th>Tổng Tiền</th>
                            <th>Trạng Thái</th>
                            <th class="text-center pe-4">Thao Tác</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach items="${bills}" var="b">
                            <tr>
                                <td class="ps-4 fw-bold text-secondary">#ORD-${b.billID}</td>
                                <td class="fw-semibold text-dark">${b.shippingRecipientName}</td>
                                <td class="text-muted small"><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                                <td class="text-center fw-bold text-dark"><span class="bg-light px-2 py-1 rounded">${b.quantity}</span></td>
                                <td class="fw-bold text-danger"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                                <td>
                                    <c:choose>
                                        <c:when test="${b.orderStatus == 'Pending'}"><span class="badge rounded-pill bg-warning text-dark px-3">Chờ duyệt</span></c:when>
                                        <c:when test="${b.orderStatus == 'Processing'}"><span class="badge rounded-pill bg-info text-dark px-3">Đang đóng gói</span></c:when>
                                        <c:when test="${b.orderStatus == 'Completed'}"><span class="badge rounded-pill bg-success px-3">Hoàn thành</span></c:when>
                                        <c:otherwise><span class="badge rounded-pill bg-danger px-3">Đã hủy</span></c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="text-center pe-4">
                                    <button class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" data-bs-toggle="modal" data-bs-target="#orderDetailModal${b.billID}" title="Xem Chi Tiết">
                                        <i class="fa-solid fa-expand"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty bills}">
                            <tr><td colspan="7" class="text-center py-4 text-muted">Chưa có đơn hàng nào trên hệ thống.</td></tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<c:forEach items="${bills}" var="b">
    <div class="modal fade" id="orderDetailModal${b.billID}" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="modal-header bg-dark text-white border-bottom border-warning border-3">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-receipt text-warning me-2"></i> Chi Tiết Đơn #ORD-${b.billID}</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body p-4 bg-light">
                    <div class="bg-white p-3 rounded-3 shadow-sm border mb-4">
                        <p class="mb-2"><i class="fa-solid fa-user-gear text-primary w-20px me-1"></i> Tài khoản mua: <strong class="text-secondary">${b.user.fullName} (@${b.user.username})</strong></p>
                        <p class="mb-2"><i class="fa-solid fa-truck-fast text-success w-20px me-1"></i> Người nhận hàng: <strong>${b.shippingRecipientName}</strong> - ${b.shippingPhone}</p>
                        <p class="mb-0"><i class="fa-solid fa-location-dot text-danger w-20px me-1"></i> Địa chỉ giao: <span class="text-dark">${b.shippingAddressText}</span></p>
                    </div>

                    <div class="table-responsive mb-3 rounded-3 border shadow-sm">
                        <table class="table table-hover table-bordered bg-white mb-0">
                            <thead class="table-light text-muted small text-uppercase">
                            <tr>
                                <th class="ps-3">Tên Sản Phẩm</th>
                                <th class="text-center" width="10%">SL</th>
                                <th class="text-end pe-3" width="30%">Giá Đơn (Lúc Mua)</th>
                            </tr>
                            </thead>
                            <tbody>
                            <c:forEach items="${b.details}" var="detail">
                                <tr>
                                    <td class="ps-3 fw-semibold text-dark">${detail.product.productName}</td>
                                    <td class="text-center fw-bold text-secondary">${detail.quantity}</td>
                                    <td class="text-danger fw-bold text-end pe-3"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td>
                                </tr>
                            </c:forEach>
                            </tbody>
                        </table>
                    </div>

                    <div class="row g-3 mb-4 align-items-stretch">
                        <div class="col-md-7">
                            <div class="bg-white p-3 rounded-3 shadow-sm border h-100">
                                <span class="text-muted small d-block mb-2 fw-bold text-uppercase"><i class="fa-solid fa-comment-dots text-secondary me-1"></i> Ghi chú từ khách:</span>
                                <c:choose>
                                    <c:when test="${not empty b.notes}">
                                        <div class="text-dark bg-light p-2 rounded border-start border-3 border-warning small fst-italic">${b.notes}</div>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="text-muted fst-italic small">Không có ghi chú đặc biệt.</span>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="bg-white p-3 rounded-3 shadow-sm border h-100 text-end d-flex flex-column justify-content-center">
                                <span class="text-muted fw-bold small text-uppercase d-block mb-1">Tổng Thanh Toán:</span>
                                <h3 class="fw-extrabold text-danger m-0"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></h3>
                            </div>
                        </div>
                    </div>

                    <form action="${pageContext.request.contextPath}/BillAdminController" method="post" class="bg-white p-3 rounded-3 shadow-sm border">
                        <input type="hidden" name="billId" value="${b.billID}">
                        <label class="form-label fw-bold text-secondary small text-uppercase mb-2">Cập nhật Trạng Thái Đơn</label>
                        <div class="input-group input-group-lg shadow-sm">
                            <span class="input-group-text bg-light"><i class="fa-solid fa-truck-ramp-box text-muted"></i></span>
                            <select name="orderStatus" class="form-select fw-semibold text-dark fs-6">
                                <option value="Pending" ${b.orderStatus == 'Pending' ? 'selected' : ''}>Chờ duyệt (Chờ xác nhận)</option>
                                <option value="Processing" ${b.orderStatus == 'Processing' ? 'selected' : ''}>Đang đóng gói & Giao hàng</option>
                                <option value="Completed" ${b.orderStatus == 'Completed' ? 'selected' : ''}>Hoàn thành thành công</option>
                                <option value="Cancelled" ${b.orderStatus == 'Cancelled' ? 'selected' : ''}>Hủy đơn hàng</option>
                            </select>
                            <button type="submit" class="btn btn-warning fw-bold text-dark px-4 fs-6 text-uppercase">Cập Nhật</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</c:forEach>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>