<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%-- Phân quyền: Chỉ Admin mới được truy cập --%>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}">
    <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Tài Khoản</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .w-20px { width: 20px; text-align: center; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
        .search-box { background-color: #fff; border-radius: 30px; padding: 5px 15px; border: 1px solid #dee2e6; display: flex; align-items: center; width: 300px;}
        .search-box input { border: none; outline: none; width: 100%; margin-left: 10px; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : 'active'}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Tài Khoản</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">

            <h2 class="fw-bolder text-dark tracking-wide mb-4">Cơ Sở Dữ Liệu Thành Viên</h2>

            <c:if test="${param.error == 'nopermission'}">
                <div class="alert alert-danger mb-4">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i> Bạn không có quyền cấp phát chức vụ Owner (Chủ Cửa Hàng).
                </div>
            </c:if>

            <div class="d-flex justify-content-between align-items-center mb-3 mt-4">
                <h4 class="fw-bold text-secondary mb-0"><i class="fa-solid fa-user-tie me-2"></i>Danh Sách Nhân Viên</h4>
                <div class="d-flex gap-3">
                    <div class="search-box shadow-sm">
                        <i class="fa-solid fa-magnifying-glass text-muted"></i>
                        <input type="text" id="searchStaff" placeholder="Tìm kiếm nhân viên...">
                    </div>
                    <button class="btn btn-warning fw-bold text-dark px-4 rounded-pill shadow-sm" data-bs-toggle="modal" data-bs-target="#createStaffModal">
                        <i class="fa-solid fa-user-plus me-2"></i>Thêm Nhân Viên
                    </button>
                </div>
            </div>

            <div class="card card-custom mb-5">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tableStaff">
                        <thead class="table-light text-muted small text-uppercase fw-bold">
                        <tr>
                            <th class="ps-4">Tài Khoản</th>
                            <th>Tên Đầy Đủ</th>
                            <th>Vai Trò</th>
                            <th>Trạng Thái</th>
                            <th class="text-center pe-4">Thao tác</th>
                        </tr>
                        </thead>
                        <tbody>

                        <%-- CẬP NHẬT 1: Lặp lần 1 - Lôi những người là OWNER (Role 1) lên đầu tiên --%>
                        <c:forEach items="${users}" var="u">
                            <c:if test="${u.roleID == 1}">
                                <tr>
                                    <td class="ps-4 fw-bold text-secondary">@${u.username}</td>
                                    <td class="fw-semibold text-dark"><img src="https://ui-avatars.com/api/?name=${u.fullName}&background=random&color=fff&rounded=true" class="me-2" width="30" height="30">${u.fullName}</td>
                                    <td><span class="badge bg-danger px-3 py-1 rounded-pill">Owner</span></td>
                                    <td><span class="badge ${u.active ? 'bg-success' : 'bg-danger'} rounded-pill">${u.active ? 'Hoạt động' : 'Bị Khóa'}</span></td>
                                    <td class="text-center pe-4">
                                            <%-- Giữ nguyên khối div lưu địa chỉ ẩn --%>
                                        <div id="address_data_${u.userID}" class="d-none">
                                            <c:choose>
                                                <c:when test="${not empty u.addresses}">
                                                    <c:set var="foundDefault" value="false" />
                                                    <c:forEach items="${u.addresses}" var="addr">
                                                        <c:if test="${addr.isDefault}">
                                                            <c:set var="foundDefault" value="true" />
                                                            <div class="border border-secondary-subtle p-2 mb-2 rounded bg-white text-start">
                                                                <strong class="text-dark">${addr.recipientName}</strong> - <span class="text-danger">${addr.phone}</span>
                                                                <span class="badge bg-success ms-1" style="font-size: 0.65rem;">Mặc định</span>
                                                                <br>
                                                                <small class="text-muted">${addr.detailedAddress}</small>
                                                            </div>
                                                        </c:if>
                                                    </c:forEach>
                                                    <c:if test="${!foundDefault}">
                                                        <c:set var="firstAddr" value="${u.addresses[0]}" />
                                                        <div class="border border-secondary-subtle p-2 mb-2 rounded bg-white text-start">
                                                            <strong class="text-dark">${firstAddr.recipientName}</strong> - <span class="text-danger">${firstAddr.phone}</span>
                                                            <br>
                                                            <small class="text-muted">${firstAddr.detailedAddress}</small>
                                                        </div>
                                                    </c:if>
                                                </c:when>
                                                <c:otherwise>
                                                    <div class="alert alert-secondary small py-2 mb-0 text-center">Người dùng chưa thêm địa chỉ nào.</div>
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                        <button class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" onclick="showUserModal('${u.fullName}', '${u.email}', '${u.phone}', 'address_data_${u.userID}')" title="Xem chi tiết"><i class="fa-solid fa-address-card"></i></button>
                                        <button class="btn btn-sm btn-light border text-warning rounded-circle shadow-sm ms-1" onclick="showRoleModal('${u.userID}', '${u.username}', '${u.roleID}')" title="Cấp quyền/Đổi Role"><i class="fa-solid fa-user-shield"></i></button>
                                        <c:if test="${u.roleID > 1}">
                                            <a href="${pageContext.request.contextPath}/UserController?action=toggle&id=${u.userID}" class="btn btn-sm btn-light border text-${u.active ? 'danger' : 'success'} rounded-circle shadow-sm ms-1" title="Khóa/Mở Khóa"><i class="fa-solid ${u.active ? 'fa-lock' : 'fa-unlock'}"></i></a>
                                        </c:if>
                                    </td>
                                </tr>
                            </c:if>
                        </c:forEach>

                        <%-- CẬP NHẬT 2: Lặp lần 2 - In những Admin/Staff (Role 2) ở bên dưới --%>
                        <c:forEach items="${users}" var="u">
                            <c:if test="${u.roleID == 2}">
                                <tr>
                                    <td class="ps-4 fw-bold text-secondary">@${u.username}</td>
                                    <td class="fw-semibold text-dark"><img src="https://ui-avatars.com/api/?name=${u.fullName}&background=random&color=fff&rounded=true" class="me-2" width="30" height="30">${u.fullName}</td>
                                    <td><span class="badge bg-primary px-3 py-1 rounded-pill">Admin/Staff</span></td>
                                    <td><span class="badge ${u.active ? 'bg-success' : 'bg-danger'} rounded-pill">${u.active ? 'Hoạt động' : 'Bị Khóa'}</span></td>
                                    <td class="text-center pe-4">
                                            <%-- Giữ nguyên khối div lưu địa chỉ ẩn --%>
                                        <div id="address_data_${u.userID}" class="d-none">
                                            <c:choose>
                                                <c:when test="${not empty u.addresses}">
                                                    <c:set var="foundDefault" value="false" />
                                                    <c:forEach items="${u.addresses}" var="addr">
                                                        <c:if test="${addr.isDefault}">
                                                            <c:set var="foundDefault" value="true" />
                                                            <div class="border border-secondary-subtle p-2 mb-2 rounded bg-white text-start">
                                                                <strong class="text-dark">${addr.recipientName}</strong> - <span class="text-danger">${addr.phone}</span>
                                                                <span class="badge bg-success ms-1" style="font-size: 0.65rem;">Mặc định</span>
                                                                <br>
                                                                <small class="text-muted">${addr.detailedAddress}</small>
                                                            </div>
                                                        </c:if>
                                                    </c:forEach>
                                                    <c:if test="${!foundDefault}">
                                                        <c:set var="firstAddr" value="${u.addresses[0]}" />
                                                        <div class="border border-secondary-subtle p-2 mb-2 rounded bg-white text-start">
                                                            <strong class="text-dark">${firstAddr.recipientName}</strong> - <span class="text-danger">${firstAddr.phone}</span>
                                                            <br>
                                                            <small class="text-muted">${firstAddr.detailedAddress}</small>
                                                        </div>
                                                    </c:if>
                                                </c:when>
                                                <c:otherwise>
                                                    <div class="alert alert-secondary small py-2 mb-0 text-center">Người dùng chưa thêm địa chỉ nào.</div>
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                        <button class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" onclick="showUserModal('${u.fullName}', '${u.email}', '${u.phone}', 'address_data_${u.userID}')" title="Xem chi tiết"><i class="fa-solid fa-address-card"></i></button>
                                        <button class="btn btn-sm btn-light border text-warning rounded-circle shadow-sm ms-1" onclick="showRoleModal('${u.userID}', '${u.username}', '${u.roleID}')" title="Cấp quyền/Đổi Role"><i class="fa-solid fa-user-shield"></i></button>
                                        <c:if test="${u.roleID > 1}">
                                            <a href="${pageContext.request.contextPath}/UserController?action=toggle&id=${u.userID}" class="btn btn-sm btn-light border text-${u.active ? 'danger' : 'success'} rounded-circle shadow-sm ms-1" title="Khóa/Mở Khóa"><i class="fa-solid ${u.active ? 'fa-lock' : 'fa-unlock'}"></i></a>
                                        </c:if>
                                    </td>
                                </tr>
                            </c:if>
                        </c:forEach>

                        </tbody>
                    </table>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3 border-top pt-4">
                <h4 class="fw-bold text-secondary mb-0"><i class="fa-solid fa-users me-2"></i>Danh Sách Khách Hàng</h4>
                <div class="search-box shadow-sm">
                    <i class="fa-solid fa-magnifying-glass text-muted"></i>
                    <input type="text" id="searchCustomer" placeholder="Tìm kiếm khách hàng...">
                </div>
            </div>

            <div class="card card-custom mb-5">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" id="tableCustomer">
                        <thead class="table-light text-muted small text-uppercase fw-bold">
                        <tr>
                            <th class="ps-4">Tài Khoản</th>
                            <th>Tên Đầy Đủ</th>
                            <th>Vai Trò</th>
                            <th>Trạng Thái</th>
                            <th class="text-center pe-4">Thao tác</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach items="${users}" var="u">
                            <c:if test="${u.roleID == 3}">
                                <tr>
                                    <td class="ps-4 fw-bold text-secondary">@${u.username}</td>
                                    <td class="fw-semibold text-dark"><img src="https://ui-avatars.com/api/?name=${u.fullName}&background=random&color=fff&rounded=true" class="me-2" width="30" height="30">${u.fullName}</td>
                                    <td><span class="badge bg-secondary text-dark px-3 py-1 rounded-pill">Customer</span></td>
                                    <td><span class="badge ${u.active ? 'bg-success' : 'bg-danger'} rounded-pill">${u.active ? 'Hoạt động' : 'Bị Khóa'}</span></td>
                                    <td class="text-center pe-4">
                                        <div id="address_data_${u.userID}" class="d-none">
                                            <c:choose>
                                                <c:when test="${not empty u.addresses}">
                                                    <c:forEach items="${u.addresses}" var="addr">
                                                        <div class="border border-secondary-subtle p-2 mb-2 rounded bg-white text-start">
                                                            <strong class="text-dark">${addr.recipientName}</strong> - <span class="text-danger">${addr.phone}</span>
                                                            <c:if test="${addr.isDefault}">
                                                                <span class="badge bg-success ms-1" style="font-size: 0.65rem;">Mặc định</span>
                                                            </c:if>
                                                            <br>
                                                            <small class="text-muted">${addr.detailedAddress}</small>
                                                        </div>
                                                    </c:forEach>
                                                </c:when>
                                                <c:otherwise>
                                                    <div class="alert alert-secondary small py-2 mb-0 text-center">Khách hàng chưa thêm địa chỉ nào.</div>
                                                </c:otherwise>
                                            </c:choose>
                                        </div>
                                        <button class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" onclick="showUserModal('${u.fullName}', '${u.email}', '${u.phone}', 'address_data_${u.userID}')" title="Xem chi tiết"><i class="fa-solid fa-address-card"></i></button>
                                        <button class="btn btn-sm btn-light border text-warning rounded-circle shadow-sm ms-1" onclick="showRoleModal('${u.userID}', '${u.username}', '${u.roleID}')" title="Cấp quyền/Đổi Role"><i class="fa-solid fa-user-shield"></i></button>
                                        <a href="${pageContext.request.contextPath}/UserController?action=toggle&id=${u.userID}" class="btn btn-sm btn-light border text-${u.active ? 'danger' : 'success'} rounded-circle shadow-sm ms-1" title="Khóa/Mở Khóa"><i class="fa-solid ${u.active ? 'fa-lock' : 'fa-unlock'}"></i></a>
                                    </td>
                                </tr>
                            </c:if>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>
</div>

<div class="modal fade" id="createStaffModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-warning text-dark border-bottom border-warning border-3">
                <h5 class="modal-title fw-bold"><i class="fa-solid fa-user-plus me-2"></i>Tạo Tài Khoản Mới</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/UserController" method="POST">
                <input type="hidden" name="action" value="createStaff">
                <div class="modal-body p-4 bg-light">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Tên Đăng Nhập</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Mật Khẩu</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small text-muted">Họ và Tên Đầy Đủ</label>
                            <input type="text" name="fullName" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Email</label>
                            <input type="email" name="email" class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-muted">Số Điện Thoại</label>
                            <input type="text" name="phone" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold small text-muted">Cấp Quyền Hệ Thống</label>
                            <select name="roleID" class="form-select">
                                <option value="1">Owner (Chủ cửa hàng)</option>
                                <option value="2">Admin / Staff</option>
                                <option value="3">Khách Hàng (Customer)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light border-top-0 pt-0">
                    <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-warning fw-bold text-dark rounded-pill px-4">Tạo Tài Khoản</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="singleRoleModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-dark text-white border-bottom border-warning border-3">
                <h5 class="modal-title fw-bold">Cấp Quyền</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/UserController" method="POST">
                <input type="hidden" name="action" value="updateRole">
                <input type="hidden" name="userID" id="roleModalUserID">
                <div class="modal-body p-4 bg-light text-center">
                    <p class="mb-3 text-muted">Cấp lại quyền cho tài khoản<br><strong class="text-dark fs-5" id="roleModalUsername"></strong></p>
                    <select name="roleID" id="roleModalSelect" class="form-select form-select-lg mb-2">
                        <option value="1">Owner (Chủ cửa hàng)</option>
                        <option value="2">Admin / Staff</option>
                        <option value="3">Khách Hàng (Customer)</option>
                    </select>
                </div>
                <div class="modal-footer bg-light justify-content-center border-top-0 pt-0">
                    <button type="submit" class="btn btn-dark w-100 fw-bold rounded-pill">Xác nhận thay đổi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="singleUserModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-dark text-white border-bottom border-primary border-3">
                <h5 class="modal-title fw-bold">Thông Tin: <span id="modalName" class="text-warning"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 bg-light">
                <p class="mb-2"><strong>Email:</strong> <span id="modalEmail" class="text-primary"></span></p>
                <p class="mb-3"><strong>Điện thoại:</strong> <span id="modalPhone" class="text-danger fw-bold"></span></p>
                <hr>
                <h6 class="fw-bold text-secondary small text-uppercase mb-3"><i class="fa-solid fa-map-location-dot me-1"></i> Sổ Địa Chỉ Đã Đăng Ký</h6>
                <div id="modalAddressContainer" class="bg-light p-2 rounded border">
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Hàm lọc tìm kiếm chung cho các bảng
        function setupSearch(inputId, tableId) {
            const input = document.getElementById(inputId);
            if(input) {
                input.addEventListener("keyup", function() {
                    const filter = input.value.toLowerCase();
                    const rows = document.querySelectorAll("#" + tableId + " tbody tr");

                    rows.forEach(row => {
                        const text = row.textContent.toLowerCase();
                        if(text.includes(filter)) {
                            row.style.display = "";
                        } else {
                            row.style.display = "none";
                        }
                    });
                });
            }
        }
        setupSearch("searchCustomer", "tableCustomer");
        setupSearch("searchStaff", "tableStaff");
    });

    // Hàm gọi Modal Xem Chi Tiết, lấy thêm ID của chuỗi HTML Address
    function showUserModal(name, email, phone, addressDivId) {
        document.getElementById('modalName').innerText = name;
        document.getElementById('modalEmail').innerText = (email && email !== 'null' && email.trim() !== '') ? email : 'Chưa cập nhật';
        document.getElementById('modalPhone').innerText = (phone && phone !== 'null' && phone.trim() !== '') ? phone : 'Chưa cập nhật';

        // Lấy đoạn HTML địa chỉ từ div ẩn và nhét vào Modal Container
        const addressHtml = document.getElementById(addressDivId).innerHTML;
        document.getElementById('modalAddressContainer').innerHTML = addressHtml;

        var userModal = new bootstrap.Modal(document.getElementById('singleUserModal'));
        userModal.show();
    }

    // Hàm gọi Modal Đổi Quyền Role
    function showRoleModal(id, username, roleId) {
        document.getElementById('roleModalUserID').value = id;
        document.getElementById('roleModalUsername').innerText = '@' + username;
        document.getElementById('roleModalSelect').value = roleId;
        var roleModal = new bootstrap.Modal(document.getElementById('singleRoleModal'));
        roleModal.show();
    }
</script>
</body>
</html>