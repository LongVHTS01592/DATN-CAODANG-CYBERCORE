<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Lấy danh sách Categories để hiển thị tên danh mục trong bảng --%>
<%
  dao.CategoryDAO catDAO = new dao.CategoryDAO();
  request.setAttribute("dbCategories", catDAO.findAll());
%>

<%-- Phân quyền: Chỉ Admin mới được truy cập --%>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>CyberCore Admin - Sản Phẩm</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
    .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
    .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
    .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
    .w-20px { width: 20px; text-align: center; }
    .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
  </style>
</head>
<body>
<div class="container-fluid p-0">
  <div class="row g-0">
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
      <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
      <ul class="nav flex-column nav-menu">
        <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : 'active'}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Tài Khoản</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'banner' ? 'active' : ''}" href="${pageContext.request.contextPath}/BannerAdminController"><i class="fa-solid fa-rectangle-ad me-2 w-20px"></i> Quảng Cáo</a></li>
        <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
        <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
        <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
      </ul>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bolder text-dark tracking-wide">Quản Lý Kho Hàng</h2>
        <button id="btnAddNewProduct" class="btn btn-warning fw-bold text-dark rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#productModal">
          <i class="fa-solid fa-plus me-1"></i> Thêm Linh Kiện
        </button>
      </div>

      <div class="card card-custom">
        <div class="table-responsive">
          <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
            <tr>
              <th class="ps-4">Ảnh</th>
              <th>Tên Thiết Bị</th>
              <th>Danh Mục</th>
              <th>Giá Bán</th>
              <th>Số Lượng</th>
              <th>Bảo Hành</th>
              <th>Trạng Thái</th>
              <th class="text-center pe-4">Thao tác</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach items="${products}" var="p">
              <tr>
                <td class="ps-4">
                  <img src="${pageContext.request.contextPath}/images/${p.mainImageURL}" class="rounded-3 shadow-sm border bg-white p-1" style="width:60px;height:60px;object-fit:contain;" alt="Product">
                </td>
                <td class="fw-bold text-dark">${p.productName}</td>
                <td>
                  <c:set var="currentCatName" value="Chưa phân loại" />
                  <c:forEach items="${dbCategories}" var="cat">
                    <c:if test="${cat.categoryID == p.categoryID}">
                      <c:set var="currentCatName" value="${cat.categoryName}" />
                    </c:if>
                  </c:forEach>
                  <span class="badge bg-light text-dark border">${currentCatName}</span>
                </td>
                <td class="text-danger fw-bold">
                  <fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/>
                </td>
                <td class="fw-bold text-secondary">${p.stockQuantity}</td>
                <td class="text-muted small">${p.warrantyMonths} Tháng</td>
                <td>
                  <c:choose>
                    <c:when test="${p.status == 1}">
                      <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 rounded-pill">Đang bán</span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 rounded-pill">Ngừng bán</span>
                    </c:otherwise>
                  </c:choose>
                </td>
                <td class="text-center pe-4">
                  <a href="${pageContext.request.contextPath}/ProductAdminController?action=edit&id=${p.productID}" class="btn btn-sm btn-outline-primary rounded-circle p-2 mx-1">
                    <i class="fa-solid fa-pencil"></i>
                  </a>
                  <a href="${pageContext.request.contextPath}/ProductAdminController?action=delete&id=${p.productID}" class="btn btn-sm btn-outline-danger rounded-circle p-2 mx-1" onclick="return confirm('Bạn chắc chắn muốn xóa linh kiện này?')">
                    <i class="fa-solid fa-trash"></i>
                  </a>
                </td>
              </tr>
            </c:forEach>
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>

<div class="modal fade" id="productModal" data-bs-backdrop="static" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content card-custom border-0 shadow">
      <div class="modal-header bg-dark text-white">
        <h5 class="modal-title fw-bold" id="modalTitle">Thiết Lập Cấu Hình Linh Kiện</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close" onclick="window.location.href='ProductAdminController'"></button>
      </div>
      <form id="productForm" action="${pageContext.request.contextPath}/ProductAdminController" method="post">
        <div class="modal-body p-4">
          <input type="hidden" name="action" id="modalAction" value="insert">
          <input type="hidden" name="id" id="productIdInput" value="${productEdit.productID}">

          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold text-muted small">TÊN SẢN PHẨM</label>
              <input type="text" class="form-control rounded-3" name="productName" id="pName" required value="${productEdit.productName}">
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold text-muted small">DANH MỤC</label>
              <select class="form-select rounded-3" name="categoryID" id="pCategory" required>
                <option value="">-- Chọn danh mục --</option>
                <c:forEach items="${dbCategories}" var="cat">
                  <option value="${cat.categoryID}" ${productEdit.categoryID == cat.categoryID ? 'selected' : ''}>${cat.categoryName}</option>
                </c:forEach>
              </select>
            </div>

            <div class="col-md-3">
              <label class="form-label fw-semibold text-muted small">GIÁ GỐC (VNĐ)</label>
              <input type="number" class="form-control rounded-3" name="originalPrice" id="pOrigPrice" required value="${productEdit.originalPrice != null ? productEdit.originalPrice : '0'}">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold text-muted small">GIÁ BÁN (VNĐ)</label>
              <input type="number" class="form-control rounded-3" name="sellPrice" id="pSellPrice" required value="${productEdit.sellPrice != null ? productEdit.sellPrice : '0'}">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold text-muted small">SỐ LƯỢNG KHO</label>
              <input type="number" class="form-control rounded-3" name="stockQuantity" id="pStockQuantity" min="0" required value="${productEdit != null ? productEdit.stockQuantity : '0'}">
            </div>
            <div class="col-md-3">
              <label class="form-label fw-semibold text-muted small">BẢO HÀNH (THÁNG)</label>
              <input type="number" class="form-control rounded-3" name="warrantyMonths" id="pWarranty" value="${productEdit != null ? productEdit.warrantyMonths : '12'}">
            </div>

            <div class="col-md-8">
              <label class="form-label fw-semibold text-muted small">TÊN TỆP / LINK HÌNH ẢNH CHÍNH</label>
              <input type="text" class="form-control rounded-3" name="mainImageURL" id="pMainImg" required value="${productEdit.mainImageURL}">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold text-muted small">TRẠNG THÁI</label>
              <select class="form-select rounded-3 fw-bold text-dark" name="status" id="pStatus">
                <option value="1" ${productEdit.status == 1 ? 'selected' : ''}>Đang bán</option>
                <option value="0" ${productEdit != null && productEdit.status == 0 ? 'selected' : ''}>Ngừng bán</option>
              </select>
            </div>

            <div class="col-12">
              <label class="form-label fw-semibold text-muted small">DANH SÁCH LINK ẢNH PHỤ (CÁCH NHAU BẰNG DẤU PHẨY `,` )</label>
              <textarea class="form-control rounded-3 small" name="subImageURLs" id="pSubImgs" rows="2" placeholder="Ví dụ: https://link1.png, https://link2.png"><c:forEach items="${productEdit.images}" var="img" varStatus="st">${img.imageURL}${!st.last ? ',' : ''}</c:forEach></textarea>
            </div>

            <div class="col-12">
              <label class="form-label fw-semibold text-muted small">MÔ TẢ SẢN PHẨM</label>
              <textarea class="form-control rounded-3" name="description" id="pDesc" rows="3">${productEdit.descriptionText}</textarea>
            </div>
          </div>
        </div>
        <div class="modal-footer border-top-0 px-4 pb-4">
          <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal" onclick="window.location.href='ProductAdminController'">Đóng</button>
          <button type="submit" class="btn btn-warning fw-bold text-dark rounded-pill px-4">Lưu Dữ Liệu</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {

    // Xử lý mở Modal khi đang ở trạng thái Cập nhật (Edit)
    <c:if test="${not empty productEdit}">
    var targetModal = new bootstrap.Modal(document.getElementById('productModal'));
    document.getElementById('modalAction').value = 'update';
    document.getElementById('productIdInput').value = '${productEdit.productID}';
    document.getElementById('modalTitle').innerText = 'Chỉnh Sửa Cấu Hình Linh Kiện #' + '${productEdit.productID}';
    targetModal.show();
    </c:if>

    // Xử lý làm mới Modal khi bấm "Thêm Linh Kiện"
    document.getElementById('btnAddNewProduct').addEventListener('click', function() {
      document.getElementById('productForm').reset();
      document.getElementById('modalAction').value = 'insert';
      document.getElementById('productIdInput').value = '';
      document.getElementById('pStatus').value = '1';
      document.getElementById('pSubImgs').value = '';
      document.getElementById('pStockQuantity').value = '0';
      document.getElementById('pOrigPrice').value = '0';
      document.getElementById('pSellPrice').value = '0';
      document.getElementById('modalTitle').innerText = 'Thiết Lập Cấu Hình Linh Kiện';
    });
  });
</script>
</body>
</html>