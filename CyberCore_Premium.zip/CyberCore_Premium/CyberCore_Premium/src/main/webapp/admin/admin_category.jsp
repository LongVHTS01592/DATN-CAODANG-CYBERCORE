<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<%-- Phân quyền: Chỉ Admin mới được truy cập --%>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}">
    <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Cấu Hình Danh Mục</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .w-20px { width: 20px; text-align: center; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
        .table > :not(caption) > * > * { padding: 1rem 0.75rem; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'category' ? 'active' : ''}" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'voucher' ? 'active' : ''}" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'revenue' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'user' ? 'active' : ''}" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Tài Khoản</a></li>
                <li class="nav-item"><a class="nav-link ${activePage == 'console' ? 'active' : ''}" href="${pageContext.request.contextPath}/admin/admin_console.jsp"><i class="fa-solid fa-terminal me-2 w-20px"></i> Console Log</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <h2 class="fw-bolder text-dark tracking-wide mb-4">Cấu Hình Danh Mục Hệ Thống</h2>

            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card card-custom bg-white">
                        <div class="card-header bg-white border-bottom border-warning border-3 py-3">
                            <h5 class="mb-0 fw-bold text-dark">
                                <i class="fa-solid ${empty categoryEdit ? 'fa-folder-plus' : 'fa-pen-to-square'} text-warning me-2"></i>
                                ${empty categoryEdit ? 'Thêm Mới Danh Mục' : 'Cập Nhật Danh Mục'}
                            </h5>
                        </div>
                        <div class="card-body p-4 bg-light">
                            <form action="${pageContext.request.contextPath}/CategoryController" method="POST">
                                <input type="hidden" name="action" value="${empty categoryEdit ? 'insert' : 'update'}">
                                <input type="hidden" name="id" value="${categoryEdit.categoryID}">

                                <div class="mb-3">
                                    <label class="form-label fw-bold small text-uppercase text-secondary">Tên Danh Mục <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control rounded-3 py-2 border-secondary-subtle shadow-sm" value="${categoryEdit.categoryName}" required placeholder="VD: Card Màn Hình">
                                </div>

                                <div class="mb-3">
                                    <label class="form-label fw-bold small text-uppercase text-secondary">Danh Mục Cha</label>
                                    <select name="parentId" class="form-select rounded-3 py-2 border-secondary-subtle shadow-sm">
                                        <option value="" class="fw-bold text-success">-- Đặt Làm Danh Mục Gốc --</option>
                                        <c:forEach items="${listCategories}" var="cat">
                                            <c:if test="${empty categoryEdit || cat.categoryID != categoryEdit.categoryID}">
                                                <option value="${cat.categoryID}" ${cat.categoryID == categoryEdit.parentCategoryID ? 'selected' : ''}>
                                                        ${cat.categoryName}
                                                </option>
                                            </c:if>
                                        </c:forEach>
                                    </select>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label fw-bold small text-uppercase text-secondary">Mã SEO (Slug)</label>
                                    <input type="text" name="slug" class="form-control rounded-3 py-2 border-secondary-subtle shadow-sm bg-white" value="${categoryEdit.slug}" placeholder="Tuỳ chọn (vd: card-man-hinh)">
                                </div>

                                <button type="submit" class="btn btn-warning w-100 fw-bold text-dark rounded-pill py-2 shadow-sm text-uppercase">
                                    <i class="fa-solid fa-floppy-disk me-2"></i> Lưu Thông Tin
                                </button>

                                <c:if test="${not empty categoryEdit}">
                                    <a href="${pageContext.request.contextPath}/CategoryController" class="btn btn-outline-secondary w-100 fw-bold rounded-pill py-2 mt-2 text-uppercase">
                                        <i class="fa-solid fa-xmark me-1"></i> Hủy Cập Nhật
                                    </a>
                                </c:if>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-8">
                    <div class="card card-custom">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 bg-white">
                                <thead class="table-light text-muted small text-uppercase fw-bold">
                                <tr>
                                    <th class="ps-4" width="10%">ID</th>
                                    <th width="30%">Tên Danh Mục</th>
                                    <th width="20%">Trực Thuộc</th>
                                    <th width="25%">Đường Dẫn (Slug)</th>
                                    <th class="text-center pe-4" width="15%">Thao Tác</th>
                                </tr>
                                </thead>
                                <tbody>
                                <c:forEach items="${listCategories}" var="c">
                                    <tr>
                                        <td class="ps-4 text-secondary fw-bold">#${c.categoryID}</td>
                                        <td class="fw-bold text-dark">${c.categoryName}</td>
                                        <td>
                                            <c:choose>
                                                <c:when test="${c.parentCategoryID != null}">
                                                    <span class="badge bg-light text-secondary border fw-medium px-2 py-1"><i class="fa-solid fa-turn-up fa-rotate-90 me-1"></i> Danh mục con</span>
                                                </c:when>
                                                <c:otherwise>
                                                    <span class="badge bg-dark text-warning border border-dark fw-bold px-2 py-1"><i class="fa-solid fa-cube me-1"></i> Gốc</span>
                                                </c:otherwise>
                                            </c:choose>
                                        </td>
                                        <td>
                                            <c:if test="${not empty c.slug}">
                                                <code class="text-primary bg-primary bg-opacity-10 px-2 py-1 rounded small border border-primary-subtle">${c.slug}</code>
                                            </c:if>
                                            <c:if test="${empty c.slug}">
                                                <span class="text-muted small fst-italic">N/A</span>
                                            </c:if>
                                        </td>
                                        <td class="text-center pe-4">
                                            <div class="d-flex justify-content-center gap-1">
                                                <a href="${pageContext.request.contextPath}/CategoryController?action=edit&id=${c.categoryID}" class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" title="Chỉnh sửa">
                                                    <i class="fa-solid fa-pen"></i>
                                                </a>
                                                <a href="${pageContext.request.contextPath}/CategoryController?action=delete&id=${c.categoryID}" class="btn btn-sm btn-light border text-danger rounded-circle shadow-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa danh mục: ${c.categoryName}?')" title="Xóa">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty listCategories}">
                                    <tr>
                                        <td colspan="5" class="text-center py-4 text-muted">Hệ thống chưa có danh mục nào.</td>
                                    </tr>
                                </c:if>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>