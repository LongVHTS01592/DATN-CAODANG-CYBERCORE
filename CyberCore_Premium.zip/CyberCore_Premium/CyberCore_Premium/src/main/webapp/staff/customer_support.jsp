<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="support" />

<%-- Kiểm tra đăng nhập (Bảo mật cơ bản) --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberCore Staff - Hỗ Trợ & Đánh Giá</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    html, body { height: 100%; margin: 0; }
    body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
    .wrapper { display: flex; min-height: 100vh; }

    /* SIDEBAR TÔNG TÍM ĐỒNG BỘ */
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .w-20px { width: 20px; text-align: center; } /* Class để canh đều icon */

    .main-content { flex-grow: 1; padding: 2rem; }

    /* ĐỒNG BỘ TÔNG TÍM */
    .text-purple { color: #a855f7; }
    .btn-purple { background-color: #a855f7; color: white; }
    .btn-purple:hover { background-color: #9333ea; color: white; }

    .rating-stars { color: #ffc107; }
    .review-card { background: #fff; border-radius: 12px; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.03); transition: transform 0.2s; }
    .review-card:hover { transform: translateY(-2px); }
    .avatar-user-review { width: 45px; height: 45px; object-fit: cover; background-color: #e6e1f0; color: #4a376b; font-weight: bold; display: flex; align-items: center; justify-content: center; }
  </style>
</head>
<body>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0">
      <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
    </div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>

    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item">
        <a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a>
      </li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary">
        <a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a>
      </li>
      <li class="nav-item mt-auto border-top border-secondary">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a>
      </li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Phản hồi & Đánh giá</h1>
        <p class="text-secondary">Lắng nghe ý kiến khách hàng về sản phẩm linh kiện và dịch vụ.</p>
      </div>
    </div>

    <div class="card border-0 shadow-sm p-3 mb-4 rounded-3 bg-white">
      <div class="d-flex flex-wrap gap-2 align-items-center">
        <span class="fw-bold text-secondary me-2">Lọc theo:</span>
        <a href="${pageContext.request.contextPath}/CustomerSupportController" class="btn btn-sm btn-dark rounded-pill px-3">Tất cả</a>
        <a href="${pageContext.request.contextPath}/CustomerSupportController?rating=5" class="btn btn-sm btn-outline-secondary rounded-pill px-3"><i class="fa-solid fa-star text-warning me-1"></i>5 Sao</a>
        <a href="${pageContext.request.contextPath}/CustomerSupportController?rating=4" class="btn btn-sm btn-outline-secondary rounded-pill px-3"><i class="fa-solid fa-star text-warning me-1"></i>4 Sao</a>
        <a href="${pageContext.request.contextPath}/CustomerSupportController?rating=3" class="btn btn-sm btn-outline-secondary rounded-pill px-3"><i class="fa-solid fa-star text-warning me-1"></i>3 Sao</a>
        <a href="${pageContext.request.contextPath}/CustomerSupportController?rating=bad" class="btn btn-sm btn-outline-danger rounded-pill px-3"><i class="fa-solid fa-triangle-exclamation me-1"></i>Đánh giá xấu (1-2 sao)</a>
      </div>
    </div>

    <div class="d-flex flex-column gap-3">

      <%-- Vòng lặp JSTL đổ danh sách review từ database --%>
      <c:forEach items="${reviews}" var="rev">
        <div class="card review-card p-4">
          <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
            <div class="d-flex gap-3">
              <div class="avatar-user-review rounded-circle text-uppercase">
                  ${rev.avatarText}
              </div>
              <div>
                <h6 class="fw-bold mb-0 text-dark">Khách hàng: ${rev.user != null ? rev.user.username : 'Ẩn danh'}</h6>
                <p class="mb-1 text-muted small">
                  Đánh giá sản phẩm: <a href="#" class="text-purple fw-semibold text-decoration-none">#SP-${rev.productID}</a>
                </p>
                <div class="rating-stars small mb-2">
                    <%-- Thẻ lặp hiển thị số sao động dựa trên điểm số --%>
                  <c:forEach begin="1" end="${rev.rating}">
                    <i class="fa-solid fa-star"></i>
                  </c:forEach>
                  <c:forEach begin="${rev.rating + 1}" end="5">
                    <i class="fa-regular fa-star text-muted"></i>
                  </c:forEach>
                </div>
              </div>
            </div>
            <span class="text-muted small"><i class="fa-regular fa-clock me-1"></i><fmt:formatDate value="${rev.createdAt}" pattern="dd/MM/yyyy HH:mm"/></span>
          </div>

          <div class="bg-light p-3 rounded-3 my-2 text-dark border-start border-3 border-purple">
            "${rev.comment != null ? rev.comment : 'Khách hàng không để lại lời nhắn.'}"
          </div>

          <div class="d-flex justify-content-end gap-2 mt-2">
            <button class="btn btn-sm btn-outline-purple" data-bs-toggle="collapse" data-bs-target="#replyBox-${rev.reviewID}">
              <i class="fa-solid fa-reply me-1"></i>Phản hồi khách hàng
            </button>
          </div>

          <div class="collapse mt-3" id="replyBox-${rev.reviewID}">
            <form action="${pageContext.request.contextPath}/CustomerSupportController" method="POST">
              <input type="hidden" name="reviewID" value="${rev.reviewID}">
              <div class="input-group">
                <input type="text" name="replyComment" class="form-control" placeholder="Nhập lời nhắn gửi đến khách hàng..." required>
                <button class="btn btn-purple" type="submit">Gửi phản hồi</button>
              </div>
            </form>
          </div>
        </div>
      </c:forEach>

      <%-- Hiển thị khi danh sách trống --%>
      <c:if test="${empty reviews}">
        <div class="card border-0 shadow-sm p-5 text-center text-muted rounded-4 bg-white">
          <i class="fa-solid fa-comment-slash fs-1 text-secondary mb-3"></i>
          <h5>Chưa có đánh giá hoặc phản hồi nào từ khách hàng!</h5>
          <p class="small mb-0">Hệ thống sẽ tự động cập nhật khi khách hàng viết đánh giá mới.</p>
        </div>
      </c:if>

    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>