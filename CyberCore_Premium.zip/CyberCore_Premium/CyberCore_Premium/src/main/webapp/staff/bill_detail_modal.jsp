<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<div class="table-responsive">
  <table class="table table-hover align-middle mb-0">
    <thead class="table-light">
    <tr>
      <th class="text-secondary">Sản phẩm</th>
      <th class="text-center text-secondary">SL</th>
      <th class="text-end text-secondary">Đơn giá</th>
      <th class="text-end text-secondary">Thành tiền</th>
    </tr>
    </thead>
    <tbody>
    <c:choose>
      <c:when test="${not empty billDetails}">
        <c:forEach items="${billDetails}" var="d">
          <tr>
            <td class="fw-semibold text-dark">${d.productName != null ? d.productName : "Sản phẩm không xác định"}</td>
            <td class="text-center">
              <span class="badge bg-light text-dark border px-2 py-1">${d.quantity}</span>
            </td>
            <td class="text-end text-muted">
              <fmt:formatNumber value="${d.priceAtSale}" type="currency" currencySymbol="đ"/>
            </td>
            <td class="text-end fw-bold text-danger">
              <fmt:formatNumber value="${d.quantity * d.priceAtSale}" type="currency" currencySymbol="đ"/>
            </td>
          </tr>
        </c:forEach>
      </c:when>
      <c:otherwise>
        <tr>
          <td colspan="4" class="text-center text-danger py-4">
            <i class="fa-solid fa-triangle-exclamation mb-2 fs-4"></i><br>
            Danh sách chi tiết rỗng hoặc không tìm thấy dữ liệu!
          </td>
        </tr>
      </c:otherwise>
    </c:choose>
    </tbody>
  </table>
</div>
<div class="d-flex justify-content-end mt-3 border-top pt-2">
  <button type="button" class="btn btn-secondary px-4 shadow-sm" data-bs-dismiss="modal">Đóng</button>
</div>