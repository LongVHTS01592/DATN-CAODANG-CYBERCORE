<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<form action="${pageContext.request.contextPath}/StaffProductController?action=saveImport" method="POST" id="importForm">
    <div class="mb-3">
        <label class="form-label fw-bold">Nhà cung cấp:</label>
        <input type="text" name="supplierName" class="form-control" required placeholder="Nhập tên nhà cung cấp..." autofocus>
    </div>

    <div class="mb-3">
        <label class="form-label fw-bold">Linh kiện cần nhập:</label>
        <select name="productID" class="select2-custom form-select" style="width: 100%;" required>
            <option value="">-- Gõ tên linh kiện để tìm... --</option>
            <c:forEach items="${products}" var="p">
                <option value="${p.productID}">
                        ${p.productName} - (Tồn: ${p.stockQuantity})
                </option>
            </c:forEach>
        </select>
    </div>

    <div class="row">
        <div class="col-6 mb-4">
            <label class="form-label fw-bold">Số lượng nhập:</label>
            <input type="number" name="quantity" class="form-control" min="1" placeholder="Ví dụ: 50" required>
        </div>
        <div class="col-6 mb-4">
            <label class="form-label fw-bold">Giá nhập (VND/Cái):</label>
            <div class="input-group">
                <input type="number" name="importPrice" class="form-control" step="1000" placeholder="0" required>
                <span class="input-group-text bg-light fw-bold">đ</span>
            </div>
        </div>
    </div>

    <hr class="my-3 text-secondary">
    <div class="d-flex justify-content-end gap-2 mt-2">
        <button type="button" class="btn btn-light border px-4 fw-bold text-secondary" data-bs-dismiss="modal">Hủy bỏ</button>
        <button type="submit" class="btn btn-purple px-4 shadow-sm fw-bold">
            <i class="fa-solid fa-boxes-packing me-2"></i>Xác nhận nhập kho
        </button>
    </div>
</form>