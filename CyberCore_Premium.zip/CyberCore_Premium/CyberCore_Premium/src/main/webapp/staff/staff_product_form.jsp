<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<form action="${pageContext.request.contextPath}/StaffProductController" method="POST" id="productForm">
  <input type="hidden" name="action" value="${action}">
  <input type="hidden" name="id" value="${product.productID}">

  <input type="hidden" name="currentSearch" value="${filterSearch}">
  <input type="hidden" name="currentCat" value="${filterCat}">
  <input type="hidden" name="currentBrand" value="${filterBrand}">

  <c:choose>
    <%-- FORM CẬP NHẬT TỒN KHO --%>
    <c:when test="${action == 'updateStock'}">
      <div class="alert alert-info border-0 shadow-sm mb-4">
        <i class="fa-solid fa-circle-info me-2"></i> <strong>Sản phẩm:</strong> ${product.productName}
      </div>
      <div class="mb-3">
        <label class="form-label fw-bold text-secondary">Số lượng tồn kho hiện tại:</label>
        <input type="number" class="form-control form-control-lg bg-light text-center fw-bold" value="${product.stockQuantity}" disabled>
      </div>
      <div class="mb-4">
        <label class="form-label fw-bold">Số lượng điều chỉnh (Mới):</label>
        <input type="number" name="stockQuantity" class="form-control form-control-lg border-primary" placeholder="Nhập số lượng mới..." required autofocus>
        <small class="text-muted"><i class="fa-solid fa-arrow-turn-up me-1"></i> Nhập tổng số lượng tồn kho mới sau khi kiểm kê.</small>
      </div>
    </c:when>

    <%-- FORM THÊM / SỬA THÔNG TIN --%>
    <c:otherwise>
      <div class="row">
        <div class="col-12 mb-3">
          <label class="form-label fw-bold">Tên linh kiện:</label>
          <input type="text" name="productName" class="form-control" value="${product.productName}" placeholder="Nhập tên sản phẩm..." required autofocus>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">Giá bán lẻ (VNĐ):</label>
          <div class="input-group shadow-sm">
            <input type="number" name="sellPrice" class="form-control" value="${product.sellPrice}" placeholder="0" required>
            <span class="input-group-text bg-light fw-bold">đ</span>
          </div>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label fw-bold">Bảo hành (tháng):</label>
          <div class="input-group shadow-sm">
            <input type="number" name="warrantyMonths" class="form-control" value="${product.warrantyMonths}" placeholder="0" required>
            <span class="input-group-text bg-light fw-bold">Tháng</span>
          </div>
        </div>
      </div>
    </c:otherwise>
  </c:choose>

  <hr class="my-3 text-secondary">
  <div class="d-flex justify-content-end gap-2 mt-2">
    <button type="button" class="btn btn-light border px-4 fw-bold text-secondary" data-bs-dismiss="modal">Hủy bỏ</button>
    <button type="submit" class="btn btn-purple px-4 shadow-sm fw-bold">
      <i class="fa-solid fa-check me-2"></i>Lưu thay đổi
    </button>
  </div>
</form>

<script>
  // Tự động focus vào ô input đầu tiên có thể nhập liệu khi Modal mở lên
  document.getElementById('productModal').addEventListener('shown.bs.modal', function () {
    const firstInput = document.querySelector('#productForm input:not([disabled])');
    if (firstInput) {
      firstInput.focus();
    }
  });
</script>