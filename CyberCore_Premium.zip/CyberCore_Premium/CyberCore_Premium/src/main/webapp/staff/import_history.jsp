<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="import_history" />

<%-- Kiểm tra đăng nhập --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberCore Staff - Lịch Sử Nhập Kho</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    html, body { height: 100%; margin: 0; }
    body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
    .wrapper { display: flex; min-height: 100vh; }

    /* SIDEBAR */
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .w-20px { width: 20px; text-align: center; }

    .main-content { flex-grow: 1; padding: 2rem; }
    .text-purple { color: #a855f7 !important; }
    .btn-purple { background-color: #a855f7; color: white; border: none; }
    .btn-purple:hover { background-color: #9333ea; color: white; }
  </style>
</head>
<body>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0">
      <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
    </div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>

    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item">
        <a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a>
      </li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary">
        <a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a>
      </li>
      <li class="nav-item mt-auto border-top border-secondary">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a>
      </li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Lịch sử nhập kho</h1>
        <p class="text-secondary">Theo dõi danh sách các linh kiện đã nhập vào hệ thống.</p>
      </div>
      <button class="btn btn-outline-secondary fw-bold bg-white shadow-sm" onclick="window.print()">
        <i class="fa-solid fa-print me-2"></i>In báo cáo
      </button>
    </div>

    <div class="card border-0 shadow-sm p-4 mb-4 rounded-4 bg-white">
      <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-filter me-2 text-purple"></i>Bộ lọc tìm kiếm</h6>
      <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/StaffImportHistoryController">
        <div class="col-md-3">
          <label class="form-label small fw-bold text-secondary">Tên linh kiện</label>
          <input type="text" name="productName" value="${paramProductName}" class="form-control" placeholder="Nhập tên linh kiện...">
        </div>

        <div class="col-md-3">
          <label class="form-label small fw-bold text-secondary">Nhà cung cấp</label>
          <input type="text" name="supplier" value="${paramSupplier}" class="form-control" placeholder="Tên nhà cung cấp...">
        </div>

        <div class="col-md-2">
          <label class="form-label small fw-bold text-secondary">Từ ngày</label>
          <input type="date" name="fromDate" value="${paramFromDate}" class="form-control">
        </div>
        <div class="col-md-2">
          <label class="form-label small fw-bold text-secondary">Đến ngày</label>
          <input type="date" name="toDate" value="${paramToDate}" class="form-control">
        </div>

        <div class="col-md-2 d-flex align-items-end">
          <button type="submit" class="btn btn-purple w-100 fw-bold"><i class="fa-solid fa-magnifying-glass me-2"></i>Lọc</button>
        </div>
      </form>
    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white">
      <div class="table-responsive px-3 py-3">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
          <tr>
            <th>Ngày Nhập</th>
            <th>Linh Kiện</th>
            <th>Nhà Cung Cấp</th>
            <th class="text-center">Số Lượng</th>
            <th>Giá Nhập</th>
            <th>Tổng Tiền</th>
            <th>Người Nhập</th>
          </tr>
          </thead>
          <tbody>
          <c:forEach items="${importHistory}" var="h">
            <tr>
              <td class="text-secondary"><fmt:formatDate value="${h.importDate}" pattern="dd/MM/yyyy HH:mm" /></td>
              <td class="fw-bold text-dark">${h.productName}</td>
              <td>${h.supplierName}</td>
              <td class="text-center"><span class="badge bg-info-subtle text-info border border-info-subtle rounded-pill px-3 py-2">${h.quantity}</span></td>
              <td class="text-dark fw-medium"><fmt:formatNumber value="${h.importPrice}" type="currency" currencySymbol="đ"/></td>
              <td class="text-danger fw-bold"><fmt:formatNumber value="${h.quantity * h.importPrice}" type="currency" currencySymbol="đ"/></td>
              <td><i class="fa-solid fa-user-circle me-1 text-secondary"></i> ${h.staffName}</td>
            </tr>
          </c:forEach>
          <c:if test="${empty importHistory}">
            <tr>
              <td colspan="7" class="text-center py-5 text-muted">
                <i class="fa-solid fa-folder-open fs-2 d-block mb-2 text-secondary"></i>
                Chưa có lịch sử nhập kho nào được ghi nhận.
              </td>
            </tr>
          </c:if>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>