<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="bill" />

<%-- Kiểm tra đăng nhập --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chi Tiết Đơn Hàng - CyberCore Staff</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    html, body { height: 100%; margin: 0; }
    body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
    .wrapper { display: flex; min-height: 100vh; }

    /* SIDEBAR ĐỒNG BỘ */
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }
    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .w-20px { width: 20px; text-align: center; }

    .main-content { flex-grow: 1; padding: 2rem; }
    .text-purple { color: #a855f7 !important; }
    .bg-purple { background-color: #a855f7 !important; color: white; }
  </style>
</head>
<body>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0">
      <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
    </div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>

    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item"><a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a></li>
      <li class="nav-item"><a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a></li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a></li>
      <li class="nav-item mt-auto border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a></li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Chi Tiết Đơn: <span class="text-purple">#ORD-${bill.billID}</span></h1>
        <p class="text-secondary">Xem xét thông tin vận chuyển và danh sách linh kiện khách hàng đã đặt.</p>
      </div>
      <a href="${pageContext.request.contextPath}/StaffBillController" class="btn btn-outline-secondary bg-white fw-bold shadow-sm">
        <i class="fa-solid fa-arrow-left me-2"></i>Quay lại danh sách
      </a>
    </div>

    <div class="row g-4">
      <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 bg-white p-4 h-100">
          <h5 class="fw-bold border-bottom pb-3 mb-3"><i class="fa-solid fa-truck-fast text-purple me-2"></i> Thông Tin Vận Chuyển</h5>
          <div class="mb-3">
            <small class="text-muted d-block mb-1">Người nhận</small>
            <span class="fw-semibold text-dark fs-6">${bill.shippingRecipientName}</span>
          </div>
          <div class="mb-3">
            <small class="text-muted d-block mb-1">Số điện thoại</small>
            <span class="fw-semibold text-dark fs-6">${bill.shippingPhone}</span>
          </div>
          <div class="mb-3">
            <small class="text-muted d-block mb-1">Địa chỉ giao hàng</small>
            <span class="fw-semibold text-dark fs-6">${bill.shippingAddressText}</span>
          </div>
          <div class="mb-3">
            <small class="text-muted d-block mb-1">Ngày đặt hàng</small>
            <span class="fw-semibold text-dark fs-6"><fmt:formatDate value="${bill.orderDate}" pattern="dd/MM/yyyy HH:mm"/></span>
          </div>

          <hr class="text-secondary">

          <div class="mb-3">
            <span class="fw-bold me-2">Trạng thái đơn:</span>
            <c:choose>
              <c:when test="${bill.orderStatus == 'Pending'}">
                <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-3 py-2 fs-6">Đang Chờ Xử Lý</span>
              </c:when>
              <c:when test="${bill.orderStatus == 'Completed'}">
                <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2 fs-6">Đã Hoàn Thành</span>
              </c:when>
              <c:otherwise>
                <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2 fs-6">Đã Hủy</span>
              </c:otherwise>
            </c:choose>
          </div>

          <c:if test="${bill.orderStatus == 'Pending'}">
            <div class="d-flex flex-column gap-2 mt-4 pt-2">
              <a href="${pageContext.request.contextPath}/StaffBillController?action=approve&id=${bill.billID}" class="btn btn-success fw-bold py-2 shadow-sm">
                <i class="fa-solid fa-check-circle me-2"></i> Duyệt & Giao Đơn Này
              </a>
              <a href="${pageContext.request.contextPath}/StaffBillController?action=cancel&id=${bill.billID}" class="btn btn-outline-danger fw-bold py-2" onclick="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này không? Mọi thao tác không thể hoàn tác.')">
                <i class="fa-solid fa-xmark-circle me-2"></i> Hủy Đơn Hàng
              </a>
            </div>
          </c:if>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden h-100">
          <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
              <thead class="table-light text-uppercase small text-secondary">
              <tr>
                <th class="ps-4 py-3">Tên Thiết Bị / Linh Kiện</th>
                <th class="text-center py-3">Số Lượng</th>
                <th class="text-end pe-4 py-3">Đơn Giá</th>
              </tr>
              </thead>
              <tbody>
              <c:forEach items="${bill.details}" var="detail">
                <tr>
                  <td class="ps-4 py-3 fw-semibold text-dark">${detail.product.productName}</td>
                  <td class="text-center py-3">
                    <span class="badge bg-light text-dark border px-3 py-1 fs-6">${detail.quantity}</span>
                  </td>
                  <td class="text-danger fw-bold text-end pe-4 py-3">
                    <fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/>
                  </td>
                </tr>
              </c:forEach>
              </tbody>
              <tfoot class="bg-light">
              <tr>
                <td colspan="2" class="text-end fw-bold text-uppercase pt-4 pb-3">Tổng Cộng Thanh Toán:</td>
                <td class="text-danger fw-bolder text-end pe-4 pt-4 pb-3 fs-4">
                  <fmt:formatNumber value="${bill.totalAmount}" type="currency" currencySymbol="đ"/>
                </td>
              </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>