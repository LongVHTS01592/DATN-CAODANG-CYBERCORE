<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="history" />

<%-- Kiểm tra đăng nhập (Bảo mật cơ bản) --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberCore Staff - Lịch Sử Giao Dịch</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    html, body { height: 100%; margin: 0; }
    body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
    .wrapper { display: flex; min-height: 100vh; }

    /* SIDEBAR */
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .w-20px { width: 20px; text-align: center; }

    .main-content { flex-grow: 1; padding: 2rem; }

    /* ĐỒNG BỘ MÀU TÍM */
    .text-purple { color: #a855f7 !important; }
    .bg-purple-light { background-color: #faf5ff; }
    .btn-purple { background-color: #a855f7; color: white; border: none; }
    .btn-purple:hover { background-color: #9333ea; color: white; }

    /* THẺ THỐNG KÊ MINI */
    .mini-stat-card { background: #fff; border-radius: 12px; padding: 1.25rem; border: none; box-shadow: 0 4px 12px rgba(0,0,0,0.02); }
    .mini-stat-icon { width: 45px; height: 45px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; }

    /* MÃ CODE GIAO DỊCH */
    .code-tx { font-family: 'Courier New', Courier, monospace; font-weight: bold; color: #e83e8c; background: #f8f9fa; padding: 2px 6px; border-radius: 4px; border: 1px solid #dee2e6; }
  </style>
</head>
<body>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0">
      <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
    </div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>

    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item">
        <a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a>
      </li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary">
        <a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a>
      </li>
      <li class="nav-item mt-auto border-top border-secondary">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a>
      </li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Nhật ký lịch sử nâng cao</h1>
        <p class="text-secondary">Tra cứu toàn bộ dữ liệu giao dịch cũ, đối soát mã hóa đơn và phương thức thanh toán.</p>
      </div>
      <button class="btn btn-outline-secondary fw-bold" onclick="window.print()">
        <i class="fa-solid fa-file-excel me-2"></i>Xuất file Excel
      </button>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-md-4">
        <div class="mini-stat-card d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-bold text-uppercase">Đơn Hoàn Thành</span>
            <h4 class="fw-extrabold mb-0 mt-1 text-success">${completedOrdersCount != null ? completedOrdersCount : 0} Đơn</h4>
          </div>
          <div class="mini-stat-icon bg-success-subtle text-success"><i class="fa-solid fa-circle-check"></i></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="mini-stat-card d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-bold text-uppercase">Doanh Số Đối Soát</span>
            <h4 class="fw-extrabold mb-0 mt-1 text-dark">
              <fmt:formatNumber value="${totalSettledAmount != null ? totalSettledAmount : 0}" type="currency" currencySymbol="đ"/>
            </h4>
          </div>
          <div class="mini-stat-icon bg-purple-light text-purple"><i class="fa-solid fa-wallet"></i></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="mini-stat-card d-flex align-items-center justify-content-between">
          <div>
            <span class="text-muted small fw-bold text-uppercase">Đơn Thất Bại / Hủy</span>
            <h4 class="fw-extrabold mb-0 mt-1 text-danger">${cancelledOrdersCount != null ? cancelledOrdersCount : 0} Đơn</h4>
          </div>
          <div class="mini-stat-icon bg-danger-subtle text-danger"><i class="fa-solid fa-circle-xmark"></i></div>
        </div>
      </div>
    </div>

    <div class="card border-0 shadow-sm p-4 mb-4 rounded-3 bg-white">
      <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-filter me-2 text-purple"></i>Bộ lọc tìm kiếm thông minh</h6>
      <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/StaffHistoryController">
        <div class="col-md-3">
          <label class="form-label small fw-bold text-secondary">Từ ngày</label>
          <input type="date" name="fromDate" class="form-control" value="${param.fromDate}">
        </div>
        <div class="col-md-3">
          <label class="form-label small fw-bold text-secondary">Đến ngày</label>
          <input type="date" name="toDate" class="form-control" value="${param.toDate}">
        </div>
        <div class="col-md-3">
          <label class="form-label small fw-bold text-secondary">Thanh toán</label>
          <select name="payMethod" class="form-select">
            <option value="">-- Tất cả phương thức --</option>
            <option value="COD" ${param.payMethod == 'COD' ? 'selected' : ''}>Tiền mặt (COD)</option>
            <option value="VNPAY" ${param.payMethod == 'VNPAY' ? 'selected' : ''}>Chuyển khoản (VNPay)</option>
            <option value="MOMO" ${param.payMethod == 'MOMO' ? 'selected' : ''}>Ví điện tử MoMo</option>
          </select>
        </div>
        <div class="col-md-3 d-flex align-items-end">
          <button type="submit" class="btn btn-purple w-100 fw-bold py-2"><i class="fa-solid fa-magnifying-glass me-2"></i>Áp dụng lọc</button>
        </div>
      </form>
    </div>

    <div class="card border-0 shadow-sm rounded-4 bg-white">
      <div class="table-responsive px-3 py-3">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
          <tr>
            <th>Mã đơn</th>
            <th>Thời gian chốt</th>
            <th>Khách hàng</th>
            <th>Tổng tiền</th>
            <th>Cổng thanh toán</th>
            <th>Mã giao dịch (Banking)</th>
            <th>Kết quả</th>
          </tr>
          </thead>
          <tbody>
          <c:forEach items="${historyStatements}" var="stmt">
            <tr>
              <td class="fw-bold text-dark">#ORD-${stmt.billID}</td>
              <td><fmt:formatDate value="${stmt.orderDate}" pattern="dd/MM/yyyy HH:mm"/></td>
              <td><span class="fw-bold">${stmt.customerName}</span></td>
              <td class="fw-bold">
                <fmt:formatNumber value="${stmt.totalAmount}" type="currency" currencySymbol="đ"/>
              </td>
              <td>
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle">${stmt.paymentMethod}</span>
              </td>
              <td>
                <c:choose>
                  <c:when test="${not empty stmt.transactionCode}">
                    <span class="code-tx">${stmt.transactionCode}</span>
                  </c:when>
                  <c:otherwise>
                    <span class="text-muted small">N/A (Ship COD)</span>
                  </c:otherwise>
                </c:choose>
              </td>
              <td>
                <c:choose>
                  <c:when test="${stmt.orderStatus == 'Completed'}">
                    <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill">Thành công</span>
                  </c:when>
                  <c:otherwise>
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill">Đã Hủy</span>
                  </c:otherwise>
                </c:choose>
              </td>
            </tr>
          </c:forEach>

          <c:if test="${empty historyStatements}">
            <tr>
              <td colspan="7" class="text-center text-muted py-5">
                <i class="fa-solid fa-inbox fs-1 text-secondary mb-3 d-block"></i>
                <h5 class="fw-bold text-dark mb-1">Không tìm thấy nhật ký giao dịch</h5>
                <p class="small mb-0 text-secondary">Hãy thử thay đổi bộ lọc hoặc kiểm tra lại dữ liệu từ hệ thống.</p>
              </td>
            </tr>
          </c:if>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>