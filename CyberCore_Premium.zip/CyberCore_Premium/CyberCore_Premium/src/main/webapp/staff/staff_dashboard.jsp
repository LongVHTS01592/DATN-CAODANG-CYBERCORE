<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<jsp:useBean id="now" class="java.util.Date" />

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="dashboard" />

<%-- Kiểm tra đăng nhập (Bảo mật cơ bản) --%>
<c:if test="${empty sessionScope.userAccount}">
    <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberCore - Cổng Thông Tin Nhân Viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
        .wrapper { display: flex; min-height: 100vh; }

        /* SIDEBAR */
        .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
        .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

        .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
        .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
        .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
        .w-20px { width: 20px; text-align: center; }

        /* THẺ THỐNG KÊ */
        .task-card { background: #fff; padding: 1.5rem; border-radius: 10px; border: none; box-shadow: 0 5px 15px rgba(168, 85, 247, 0.05); transition: transform 0.2s; }
        .task-card:hover { transform: translateY(-3px); }
        .card-label { color: #7c728e; font-size: 0.9rem; font-weight: 600; text-transform: uppercase; }
        .card-value { color: #2e1f47; font-size: 2.2rem; font-weight: 800; margin: 0.5rem 0; }

        /* NÚT THAO TÁC NHANH */
        .quick-action-btn { background: #fff; padding: 1.5rem; border-radius: 10px; text-align: center; border: 2px solid #e6e1f0; color: #4a376b; text-decoration: none; display: block; transition: all 0.2s; }
        .quick-action-btn:hover { border-color: #a855f7; background-color: #faf5ff; color: #a855f7; }
        .quick-action-btn i { font-size: 2.5rem; display: block; margin-bottom: 0.5rem; color: #a855f7; }

        .main-content { flex-grow: 1; padding: 2rem; }

        .text-primary { color: #a855f7 !important; }
        .btn-outline-success { color: #a855f7; border-color: #a855f7; }
        .btn-outline-success:hover { background-color: #a855f7; border-color: #a855f7; color: #fff; }

        .btn-purple { background-color: #a855f7; color: white; border: none; }
        .btn-purple:hover { background-color: #7e3af2; color: white; }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar shadow-sm">
        <div class="sidebar-brand text-center mb-0">
            <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
        </div>
        <div class="sidebar-user mb-3">
            <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
            <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
            <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
        </div>

        <ul class="nav flex-column nav-menu px-0 gap-0">
            <li class="nav-item">
                <a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a>
            </li>
            <li class="nav-item">
                <a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a>
            </li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary">
                <a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a>
            </li>
            <li class="nav-item mt-auto border-top border-secondary">
                <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-5">
            <div>
                <h1 class="h1 fw-bolder text-dark mb-1">Cổng vận hành CyberCore</h1>
                <p class="text-secondary fs-5">Chào bạn trở lại! Chúc bạn một ngày làm việc hiệu quả.</p>
            </div>
            <div class="text-muted border p-3 rounded-pill bg-white shadow-sm">
                <i class="fa-regular fa-clock me-2 text-primary"></i>
                Giờ hiện tại: <fmt:formatDate value="${now}" pattern="HH:mm, dd/MM/yyyy" />
            </div>
        </div>

        <h4 class="mb-3 text-secondary fw-bold text-uppercase">Tác vụ hôm nay</h4>
        <div class="row g-4 mb-5">
            <div class="col-md-4">
                <div class="task-card text-center">
                    <div class="card-label">Đơn mới <span class="text-danger">(Chờ duyệt)</span></div>
                    <div class="card-value text-warning">${newOrdersCount != null ? newOrdersCount : 0}</div>
                    <p class="text-muted small mb-0">Cần đóng gói sớm nhất có thể</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="task-card text-center"
                     style="cursor: pointer; border: 2px solid transparent;"
                     onmouseover="this.style.borderColor='#a855f7'"
                     onmouseout="this.style.borderColor='transparent'"
                     data-bs-toggle="modal"
                     data-bs-target="#stockManagerModal">
                    <div class="card-label">Sản phẩm sắp <span class="text-danger">(Hết hàng)</span></div>
                    <div class="card-value text-danger">${lowStockCount != null ? lowStockCount : 0}</div>
                    <p class="text-muted small mb-0">Bấm để xem danh sách</p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="task-card text-center">
                    <div class="card-label">Hỗ trợ mới <span class="text-danger">(Chưa đọc)</span></div>
                    <div class="card-value text-info">3</div>
                    <p class="text-muted small mb-0">Cần phản hồi câu hỏi khách hàng</p>
                </div>
            </div>
        </div>

        <h4 class="mb-3 text-secondary fw-bold text-uppercase">Bảng thao tác nhanh</h4>
        <div class="row g-4 mb-5">
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffBillController?status=Pending" class="quick-action-btn"><i class="fa-solid fa-cash-register"></i> <div class="fw-bold">Xử lý<br>đơn hàng mới</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffProductController?action=add" class="quick-action-btn"><i class="fa-solid fa-plus-circle"></i> <div class="fw-bold">Thêm<br>linh kiện mới</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffProductController?action=import" class="quick-action-btn"><i class="fa-solid fa-warehouse"></i> <div class="fw-bold">Phiếu<br>nhập kho hàng</div></a></div>
            <div class="col-md-3 col-6"><a href="${pageContext.request.contextPath}/StaffBillController?action=history" class="quick-action-btn"><i class="fa-solid fa-list-ul"></i> <div class="fw-bold">Tìm kiếm<br>đơn hàng</div></a></div>
        </div>

        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white py-4 d-flex justify-content-between align-items-center border-0 rounded-4">
                <h5 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-list-check text-success me-2"></i>Danh sách đơn hàng cần xử lý</h5>
                <a href="${pageContext.request.contextPath}/StaffBillController" class="btn btn-sm btn-outline-success fw-bold">Xem toàn bộ</a>
            </div>
            <div class="table-responsive px-3 pb-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>Mã đơn</th>
                        <th>Khách hàng</th>
                        <th>Ngày đặt</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach items="${recentOrders}" var="bill">
                        <tr>
                            <td class="fw-bold">#ORD-${bill.billID}</td>
                            <td>${bill.shippingRecipientName}</td>
                            <td><fmt:formatDate value="${bill.orderDate}" pattern="dd/MM/yyyy"/></td>
                            <td class="fw-bold"><fmt:formatNumber value="${bill.totalAmount}" type="currency" currencySymbol="đ"/></td>
                            <td>
                                <span class="badge ${bill.orderStatus == 'Pending' ? 'bg-warning text-dark' : 'bg-success'}">${bill.orderStatus}</span>
                            </td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty recentOrders}">
                        <tr><td colspan="5" class="text-center text-muted py-5"><i class="fa-solid fa-inbox fs-2 d-block mb-2"></i>Chưa có đơn hàng nào cần xử lý.</td></tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<div class="modal fade" id="stockManagerModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Quản lý kho hàng</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-header border-bottom-0 pb-0">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#lowStockTab">Sản phẩm sắp hết</button>
                    </li>
                    <li class="nav-item">
                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#historyTab">Lịch sử yêu cầu</button>
                    </li>
                </ul>
            </div>
            <div class="modal-body tab-content pt-3">
                <div class="tab-pane fade show active" id="lowStockTab">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                        <tr><th>Sản phẩm</th><th>Tồn kho</th><th class="text-end">Thao tác</th></tr>
                        </thead>
                        <tbody>
                        <c:forEach items="${lowStockProducts}" var="prod">
                            <tr>
                                <td class="fw-bold text-dark">${prod.productName}</td>
                                <td><span class="text-danger fw-bold">${prod.stockQuantity}</span></td>
                                <td class="text-end">
                                    <button class="btn btn-sm btn-purple"
                                            onclick="openRequestModal(${prod.productID}, '${prod.productName}')"
                                            data-bs-toggle="modal"
                                            data-bs-target="#requestImportModal">
                                        Yêu cầu nhập
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty lowStockProducts}">
                            <tr><td colspan="3" class="text-center text-muted">Không có sản phẩm nào sắp hết hàng.</td></tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>

                <div class="tab-pane fade" id="historyTab">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                        <tr>
                            <th>Mã SP</th>
                            <th>Số lượng</th>
                            <th>Ghi chú</th>
                            <th>Trạng thái</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach items="${myRequests}" var="req">
                            <tr>
                                <td class="fw-bold text-dark">#${req.productID}</td>
                                <td>${req.quantity}</td>
                                <td class="text-muted small">${req.note}</td>
                                <td>
                                    <c:choose>
                                        <c:when test="${req.status == 0}"><span class="badge bg-warning text-dark px-2">Đang chờ duyệt</span></c:when>
                                        <c:when test="${req.status == 1}"><span class="badge bg-success px-2">Đã duyệt</span></c:when>
                                        <c:otherwise><span class="badge bg-danger px-2">Đã từ chối</span></c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty myRequests}">
                            <tr><td colspan="4" class="text-center text-muted">Chưa có lịch sử yêu cầu nào.</td></tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="requestImportModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="${pageContext.request.contextPath}/staff/dashboard" method="POST">
                <input type="hidden" name="action" value="sendRequest">
                <input type="hidden" name="productId" id="modalProductID">
                <div class="modal-header">
                    <h5 class="modal-title">Gửi yêu cầu nhập kho</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">Sản phẩm: <strong id="modalProductName" class="text-purple"></strong></p>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Số lượng cần nhập:</label>
                        <input type="number" name="quantity" class="form-control" value="10" min="1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Ghi chú cho Admin (Tùy chọn):</label>
                        <textarea name="note" class="form-control" rows="3" placeholder="Ví dụ: Hàng bán chạy, cần nhập gấp để trả đơn..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#stockManagerModal">Quay lại</button>
                    <button type="submit" class="btn btn-purple">Gửi yêu cầu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Logic mở form yêu cầu và truyền Data
    function openRequestModal(id, name) {
        document.getElementById('modalProductID').value = id;
        document.getElementById('modalProductName').innerText = name;

        // Tạm ẩn modal quản lý kho khi form yêu cầu mở
        const stockModal = bootstrap.Modal.getInstance(document.getElementById('stockManagerModal'));
        if (stockModal) {
            stockModal.hide();
        }
    }

    // Xử lý thông báo sau khi gửi yêu cầu thành công
    window.onload = function() {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('status') === 'success') {
            alert("Yêu cầu nhập kho đã được gửi tới Admin thành công!");
            // Xóa param trên URL để tránh alert lại khi F5
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    };
</script>

</body>
</html>