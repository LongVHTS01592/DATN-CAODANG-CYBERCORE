<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Đặt biến active để Sidebar nhận diện trang hiện tại --%>
<c:set var="activePage" value="product" />

<%-- Kiểm tra đăng nhập (Bảo mật cơ bản) --%>
<c:if test="${empty sessionScope.userAccount}">
  <c:redirect url="/login"/>
</c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CyberCore Staff - Quản Lý Kho Hàng</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <style>
    html, body { height: 100%; margin: 0; }
    body { font-family: 'Inter', sans-serif; background-color: #f4f3f8; }
    .wrapper { display: flex; min-height: 100vh; }

    /* SIDEBAR */
    .sidebar { width: 260px; background-color: #2e1f47; color: #f1eef6; flex-shrink: 0; }
    .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #a855f7; padding: 1.8rem 1rem; border-bottom: 1px solid #4a376b; }
    .sidebar-user { padding: 1rem; text-align: center; border-bottom: 1px solid #4a376b; }

    .nav-menu .nav-link { color: #c0b3d6; padding: 0.9rem 1.2rem; display: flex; align-items: center; gap: 12px; transition: all 0.2s; border-left: 4px solid transparent; }
    .nav-menu .nav-link:hover { color: #fff; background-color: #4a376b; }
    .nav-menu .nav-link.active { background-color: #1e1233; color: #a855f7; border-left-color: #a855f7; }
    .w-20px { width: 20px; text-align: center; }

    .main-content { flex-grow: 1; padding: 2rem; }

    /* MÀU SẮC CHỦ ĐẠO */
    .text-primary { color: #a855f7 !important; }
    .btn-purple { background-color: #a855f7; color: white; border: none; }
    .btn-purple:hover { background-color: #9333ea; color: white; }

    .product-img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; }

    /* Fix hiển thị Modal và Select2 */
    .modal-backdrop { z-index: 1040 !important; }
    .modal-content { z-index: 1100 !important; }
    .select2-container--open { z-index: 9999 !important; }
    #productModal .modal-body { overflow: visible !important; }
  </style>
</head>
<body>

<div class="wrapper">
  <nav class="sidebar shadow-sm">
    <div class="sidebar-brand text-center mb-0">
      <i class="fa-solid fa-microchip"></i> CYBERCORE STAFF
    </div>
    <div class="sidebar-user mb-3">
      <img src="${pageContext.request.contextPath}/images/avatar-staff.png" alt="staff-avt" class="rounded-circle mb-2" width="60" onerror="this.src='https://via.placeholder.com/60'">
      <div class="fw-bold text-white">${sessionScope.userAccount.fullName != null ? sessionScope.userAccount.fullName : 'Nhân Viên'}</div>
      <div class="small text-white-50"><i class="fa-solid fa-circle text-success me-1"></i> Nhân Viên Kho/Đơn</div>
    </div>

    <ul class="nav flex-column nav-menu px-0 gap-0">
      <li class="nav-item">
        <a class="nav-link ${activePage == 'dashboard' ? 'active' : ''}" href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-house w-20px"></i> Dashboard</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'product' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffProductController"><i class="fa-solid fa-boxes-packing w-20px"></i> Quản lý kho hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'bill' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffBillController"><i class="fa-solid fa-truck-fast w-20px"></i> Xử lý đơn hàng</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'support' ? 'active' : ''}" href="${pageContext.request.contextPath}/CustomerSupportController"><i class="fa-solid fa-comments w-20px"></i> Quản lý đánh giá</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffHistoryController"><i class="fa-solid fa-file-invoice w-20px"></i> Lịch sử giao dịch</a>
      </li>
      <li class="nav-item">
        <a class="nav-link ${activePage == 'import_history' ? 'active' : ''}" href="${pageContext.request.contextPath}/StaffImportHistoryController"><i class="fa-solid fa-file-arrow-down w-20px"></i> Lịch sử nhập kho</a>
      </li>
      <li class="nav-item mt-4 pt-3 border-top border-secondary">
        <a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left w-20px"></i> Về Cửa Hàng</a>
      </li>
      <li class="nav-item mt-auto border-top border-secondary">
        <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket w-20px"></i> Đăng xuất</a>
      </li>
    </ul>
  </nav>

  <main class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 class="h2 fw-bolder text-dark mb-1">Quản lý kho linh kiện</h1>
        <p class="text-secondary">Xem tình trạng tồn kho, cập nhật giá bán và trạng thái hàng hóa.</p>
      </div>
      <div>
        <button type="button" class="btn btn-purple fw-bold shadow-sm" onclick="openImportModal()">
          <i class="fa-solid fa-plus me-2"></i> Nhập kho mới
        </button>
      </div>
    </div>

    <div class="card border-0 shadow-sm p-3 mb-4 rounded-3">
      <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/StaffProductController">
        <div class="col-md-4">
          <input type="text" name="search" class="form-control" value="${selectedSearch}" placeholder="Tìm tên linh kiện...">
        </div>
        <div class="col-md-3">
          <select name="category" class="form-select">
            <option value="">-- Chọn danh mục --</option>
            <c:forEach items="${categories}" var="cat">
              <option value="${cat.categoryID}" ${cat.categoryID eq selectedCat ? 'selected' : ''}>
                  ${cat.categoryName}
              </option>
            </c:forEach>
          </select>
        </div>
        <div class="col-md-3">
          <select name="brand" class="form-select">
            <option value="">-- Chọn thương hiệu --</option>
            <c:forEach items="${brands}" var="b">
              <option value="${b.brandID}" ${b.brandID eq selectedBrand ? 'selected' : ''}>
                  ${b.brandName}
              </option>
            </c:forEach>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-dark w-100 fw-bold"><i class="fa-solid fa-magnifying-glass me-2"></i>Lọc hàng</button>
        </div>
      </form>
    </div>

    <div class="card border-0 shadow-sm rounded-4">
      <div class="table-responsive px-3 py-3">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
          <tr>
            <th>Mã SP</th>
            <th>Hình ảnh</th>
            <th>Tên linh kiện</th>
            <th>Số lượng tồn</th>
            <th>Giá bán lẻ</th>
            <th>Bảo hành</th>
            <th>Trạng thái</th>
            <th class="text-center">Thao tác</th>
          </tr>
          </thead>
          <tbody>
          <c:forEach items="${products}" var="prod">
            <tr>
              <td class="fw-bold text-secondary">#SP-${prod.productID}</td>
              <td>
                <img src="${pageContext.request.contextPath}/images/${prod.mainImageURL}"
                     alt="img" class="product-img border"
                     onerror="this.src='https://via.placeholder.com/50'">
              </td>
              <td>
                <div class="fw-bold text-dark">${prod.productName}</div>
                <small class="text-muted">Thương hiệu:
                  <c:forEach items="${brands}" var="br">
                    <c:if test="${br.brandID == prod.brandID}">${br.brandName}</c:if>
                  </c:forEach>
                </small>
              </td>
              <td>
                                <span class="badge ${prod.stockQuantity > 5 ? 'bg-success-subtle text-success' : 'bg-danger-subtle text-danger'} border">
                                    ${prod.stockQuantity}
                                </span>
              </td>
              <td class="fw-bold text-dark">
                <fmt:formatNumber value="${prod.sellPrice}" type="currency" currencySymbol="đ"/>
              </td>
              <td><span class="badge bg-light text-dark border">${prod.warrantyMonths} Tháng</span></td>
              <td>
                <c:choose>
                  <c:when test="${prod.status == 1}">
                    <span class="badge bg-success-subtle text-success border border-success-subtle">Đang bán</span>
                  </c:when>
                  <c:when test="${prod.status == 2}">
                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Hết hàng</span>
                  </c:when>
                  <c:otherwise>
                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Tạm ngưng</span>
                  </c:otherwise>
                </c:choose>
              </td>
              <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-secondary me-1"
                        onclick="openProductModal('edit', ${prod.productID})" title="Sửa thông tin">
                  <i class="fa-solid fa-pen-to-square"></i>
                </button>
                <button type="button" class="btn btn-sm btn-outline-primary"
                        onclick="openProductModal('updateStock', ${prod.productID})" title="Cập nhật số kho">
                  <i class="fa-solid fa-warehouse"></i>
                </button>
              </td>
            </tr>
          </c:forEach>

          <c:if test="${empty products}">
            <tr>
              <td colspan="8" class="text-center text-muted py-5">
                <i class="fa-solid fa-box-open fs-2 d-block mb-2 text-secondary"></i>
                Không tìm thấy linh kiện nào trong kho hàng.
              </td>
            </tr>
          </c:if>
          </tbody>
        </table>
      </div>
    </div>
  </main>
</div>

<div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold" id="productModalLabel">Cập nhật hệ thống</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modalContent">
        <div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div></div>
      </div>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
  // Hàm gọi Modal Edit/Update Stock
  function openProductModal(action, id) {
    const modalElement = document.getElementById('productModal');
    const myModal = new bootstrap.Modal(modalElement);
    const modalBody = document.getElementById('modalContent');
    const modalTitle = document.getElementById('productModalLabel');

    modalTitle.innerText = (action === 'edit') ? 'Sửa thông tin linh kiện' : 'Cập nhật tồn kho';
    modalBody.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div></div>';

    myModal.show();

    fetch('${pageContext.request.contextPath}/StaffProductController?action=' + action + '&id=' + id)
            .then(response => response.text())
            .then(html => {
              modalBody.innerHTML = html;
            })
            .catch(error => {
              console.error('Lỗi:', error);
              modalBody.innerHTML = '<div class="alert alert-danger">Không thể tải form. Vui lòng thử lại!</div>';
            });
  }

  // Hàm gọi Modal Import Kho với Select2
  function openImportModal() {
    const modalElement = document.getElementById('productModal');
    const modalBody = document.getElementById('modalContent');
    const modalTitle = document.getElementById('productModalLabel');

    modalTitle.innerText = 'Tạo Phiếu Nhập Kho Mới';
    modalBody.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div></div>';

    var myModal = new bootstrap.Modal(modalElement);
    myModal.show();

    fetch('${pageContext.request.contextPath}/StaffProductController?action=showImportForm')
            .then(response => response.text())
            .then(html => {
              modalBody.innerHTML = html;

              // Cài đặt Select2 sau khi Form đã render vào Modal
              $('#productModal').one('shown.bs.modal', function() {
                $('.select2-custom').select2({
                  dropdownParent: $('#productModal'),
                  placeholder: "Gõ tên linh kiện cần tìm...",
                  allowClear: true,
                  width: '100%'
                });
              });

              // Kích hoạt thủ công trigger nếu Modal đã mở sẵn
              if(modalElement.classList.contains('show')) {
                $('.select2-custom').select2({
                  dropdownParent: $('#productModal'),
                  placeholder: "Gõ tên linh kiện cần tìm...",
                  allowClear: true,
                  width: '100%'
                });
              }
            })
            .catch(error => {
              console.error('Lỗi tải form nhập kho:', error);
              modalBody.innerHTML = '<div class="alert alert-danger">Không thể tải form nhập kho. Vui lòng thử lại!</div>';
            });
  }
</script>

</body>
</html>