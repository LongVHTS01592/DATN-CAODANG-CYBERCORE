package dao;

import entity.ImportRequest;
import util.JdbcUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ImportRequestDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG (Đồng bộ kiến trúc Premium)
    // =========================================================================
    private ImportRequest map(ResultSet rs) throws SQLException {
        ImportRequest req = new ImportRequest();
        req.setRequestID(rs.getInt("RequestID"));
        req.setProductID(rs.getInt("ProductID"));
        req.setQuantity(rs.getInt("RequestedQuantity")); // Khớp với tên cột trong DB của Proj 3
        req.setStaffID(rs.getInt("StaffID"));
        req.setRequestDate(rs.getTimestamp("RequestDate"));
        req.setStatus(rs.getInt("Status"));
        req.setNote(rs.getString("Note"));

        // Kiểm tra an toàn tránh lỗi Unboxing khi Admin chưa duyệt (ProcessedBy đang NULL)
        req.setProcessedBy(rs.getObject("ProcessedBy") != null ? rs.getInt("ProcessedBy") : null);
        req.setProcessedDate(rs.getTimestamp("ProcessedDate"));
        return req;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC XỬ LÝ (Đã chuyển đổi sang sử dụng JdbcUtil)
    // =========================================================================

    /**
     * Nhân viên tạo yêu cầu nhập hàng mới (Mặc định cột Status tự nhận giá trị 0 - Pending trong DB)
     */
    public boolean insertRequest(int productId, int quantity, String note, int staffId) {
        String sql = "INSERT INTO ImportRequests (ProductID, RequestedQuantity, StaffID, Note) VALUES (?, ?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, productId, quantity, staffId, note) > 0;
    }

    /**
     * Lấy danh sách các yêu cầu nhập kho đang chờ xử lý để hiển thị lên trang của Admin duyệt
     */
    public List<ImportRequest> getPendingRequests() {
        List<ImportRequest> list = new ArrayList<>();
        String sql = "SELECT * FROM ImportRequests WHERE Status = 0 ORDER BY RequestDate DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}