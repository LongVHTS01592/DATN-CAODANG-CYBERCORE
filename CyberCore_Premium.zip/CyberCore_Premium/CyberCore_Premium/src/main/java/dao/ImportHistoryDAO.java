package dao;

import entity.ImportHistory;
import util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ImportHistoryDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG (Tái sử dụng mã nguồn, tránh lặp code)
    // =========================================================================
    private ImportHistory map(ResultSet rs) throws SQLException {
        ImportHistory dto = new ImportHistory();
        dto.setImportDate(rs.getTimestamp("ImportDate"));
        dto.setProductName(rs.getString("ProductName"));
        dto.setQuantity(rs.getInt("Quantity"));
        dto.setImportPrice(rs.getBigDecimal("ImportPrice"));
        dto.setSupplierName(rs.getString("SupplierName"));
        dto.setStaffName(rs.getString("StaffName"));
        return dto;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC TRUY VẤN BÁO CÁO
    // =========================================================================

    /**
     * Lấy toàn bộ lịch sử nhập kho (Đã tối ưu hóa bằng cách dùng JdbcUtil)
     */
    public List<ImportHistory> getAllImportHistory() {
        List<ImportHistory> list = new ArrayList<>();
        String sql = """
                SELECT ib.ImportDate, p.ProductName, ibd.Quantity, ibd.ImportPrice, ib.SupplierName, u.FullName AS StaffName 
                FROM ImportBills ib 
                JOIN ImportBillDetails ibd ON ib.ImportBillID = ibd.ImportBillID 
                JOIN Products p ON ibd.ProductID = p.ProductID 
                JOIN Users u ON ib.UserID = u.UserID 
                ORDER BY ib.ImportDate DESC
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Bộ lọc nâng cao: Tìm kiếm động theo tên sản phẩm, nhà cung cấp và khoảng thời gian
     */
    public List<ImportHistory> getFilteredImportHistory(String productName, String supplier, String fromDate, String toDate) {
        List<ImportHistory> list = new ArrayList<>();

        // Sử dụng StringBuilder để xây dựng câu lệnh SQL động
        StringBuilder sql = new StringBuilder("""
                SELECT ib.ImportDate, p.ProductName, ibd.Quantity, ibd.ImportPrice, ib.SupplierName, u.FullName AS StaffName 
                FROM ImportBills ib 
                JOIN ImportBillDetails ibd ON ib.ImportBillID = ibd.ImportBillID 
                JOIN Products p ON ibd.ProductID = p.ProductID 
                JOIN Users u ON ib.UserID = u.UserID 
                WHERE 1 = 1 
                """);

        // Gắn điều kiện động dựa trên dữ liệu đầu vào của bộ lọc giao diện
        if (productName != null && !productName.isEmpty()) sql.append(" AND UPPER(p.ProductName) LIKE UPPER(?)");
        if (supplier != null && !supplier.isEmpty()) sql.append(" AND UPPER(ib.SupplierName) LIKE UPPER(?)");
        if (fromDate != null && !fromDate.isEmpty()) sql.append(" AND ib.ImportDate >= ?");
        if (toDate != null && !toDate.isEmpty()) sql.append(" AND ib.ImportDate <= ?");

        sql.append(" ORDER BY ib.ImportDate DESC");

        System.out.println("DEBUG SQL DYNAMIC FILTER: " + sql.toString());

        // Sử dụng Connection gốc vì số lượng tham số truyền vào là động, không cố định
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            int index = 1;
            if (productName != null && !productName.isEmpty()) ps.setString(index++, "%" + productName + "%");
            if (supplier != null && !supplier.isEmpty()) ps.setString(index++, "%" + supplier + "%");

            // Xử lý chuỗi thời gian để quét trọn vẹn từ đầu ngày bắt đầu đến cuối ngày kết thúc
            if (fromDate != null && !fromDate.isEmpty()) ps.setString(index++, fromDate + " 00:00:00");
            if (toDate != null && !toDate.isEmpty()) ps.setString(index++, toDate + " 23:59:59");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}