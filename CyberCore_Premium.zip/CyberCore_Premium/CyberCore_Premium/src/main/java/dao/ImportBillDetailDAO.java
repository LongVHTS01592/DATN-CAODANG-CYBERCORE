package dao;

import entity.ImportBillDetail;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ImportBillDetailDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private ImportBillDetail map(ResultSet rs) throws SQLException {
        ImportBillDetail d = new ImportBillDetail();
        d.setDetailID(rs.getInt("DetailID"));
        d.setImportBillID(rs.getInt("ImportBillID"));
        d.setProductID(rs.getInt("ProductID"));
        d.setQuantity(rs.getInt("Quantity"));
        d.setImportPrice(rs.getBigDecimal("ImportPrice"));
        return d;
    }

    // =========================================================================
    // PHƯƠNG THỨC TRUY VẤN
    // =========================================================================

    /**
     * Lấy danh sách chi tiết của một phiếu nhập kho cụ thể
     * (Phục vụ cho nút "Xem chi tiết" trên giao diện Lịch sử nhập kho)
     */
    public List<ImportBillDetail> findByImportBillId(int importBillId) {
        List<ImportBillDetail> list = new ArrayList<>();
        String sql = "SELECT * FROM ImportBillDetails WHERE ImportBillID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, importBillId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}