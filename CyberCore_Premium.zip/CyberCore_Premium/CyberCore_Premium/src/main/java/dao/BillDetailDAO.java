package dao;

import entity.BillDetail;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BillDetailDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private BillDetail map(ResultSet rs) throws SQLException {
        BillDetail b = new BillDetail();
        b.setBillDetailID(rs.getInt("BillDetailID"));
        b.setBillID(rs.getInt("BillID"));
        b.setProductID(rs.getInt("ProductID"));
        b.setQuantity(rs.getInt("Quantity"));
        b.setPriceAtSale(rs.getBigDecimal("PriceAtSale"));
        return b;
    }

    // =========================================================================
    // CÁC XỬ LÝ TRUY VẤN
    // =========================================================================
    public List<BillDetail> findByBillId(int billId) {
        List<BillDetail> list = new ArrayList<>();
        String sql = "SELECT * FROM BillDetails WHERE BillID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, billId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public boolean insert(BillDetail b) {
        String sql = "INSERT INTO BillDetails (BillID, ProductID, Quantity, PriceAtSale) VALUES (?, ?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, b.getBillID(), b.getProductID(), b.getQuantity(), b.getPriceAtSale()) > 0;
    }

    public boolean deleteByBillId(int billId) {
        String sql = "DELETE FROM BillDetails WHERE BillID = ?";
        return JdbcUtil.executeUpdate(sql, billId) > 0;
    }

    /**
     * Tìm chi tiết hóa đơn kèm theo tên sản phẩm (Kết hợp logic nâng cao từ Project 3)
     */
    public List<BillDetail> findDetailsWithProductName(int billId) {
        List<BillDetail> list = new ArrayList<>();
        String sql = """
                SELECT bd.*, p.ProductName 
                FROM BillDetails bd 
                JOIN Products p ON bd.ProductID = p.ProductID 
                WHERE bd.BillID = ?
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, billId);
            while (rs.next()) {
                BillDetail b = map(rs);
                b.setProductName(rs.getString("ProductName"));
                list.add(b);
            }
            // Giữ lại dòng debug hữu ích của team bạn
            System.out.println("LOG [BillDetailDAO]: Tìm thấy " + list.size() + " chi tiết sản phẩm cho BillID: " + billId);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}