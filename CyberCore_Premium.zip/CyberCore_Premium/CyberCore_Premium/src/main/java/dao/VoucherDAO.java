package dao;

import entity.Voucher;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VoucherDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private Voucher map(ResultSet rs) throws SQLException {
        Voucher v = new Voucher();
        v.setVoucherID(rs.getInt("VoucherID"));
        v.setVoucherCode(rs.getString("VoucherCode"));
        v.setDescription(rs.getString("Description"));
        v.setDiscountType(rs.getString("DiscountType"));
        v.setDiscountValue(rs.getBigDecimal("DiscountValue"));
        v.setMaxDiscountAmount(rs.getBigDecimal("MaxDiscountAmount"));
        v.setMinOrderValue(rs.getBigDecimal("MinOrderValue"));
        v.setStartDate(rs.getTimestamp("StartDate"));
        v.setEndDate(rs.getTimestamp("EndDate"));
        v.setUsageLimit(rs.getInt("UsageLimit"));
        v.setUsedCount(rs.getInt("UsedCount"));
        v.setStatus(rs.getBoolean("Status"));
        return v;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC TRUY VẤN VOUCHER
    // =========================================================================
    public List<Voucher> findAll() {
        List<Voucher> list = new ArrayList<>();
        String sql = """
                SELECT * FROM Vouchers 
                ORDER BY VoucherID DESC
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Voucher findById(int id) {
        String sql = "SELECT * FROM Vouchers WHERE VoucherID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Tìm mã Voucher và kiểm tra trực tiếp điều kiện áp dụng ở Database
     */
    public Voucher findByCode(String code) {
        String sql = """
                SELECT * FROM Vouchers
                WHERE VoucherCode = ?
                  AND Status = 1
                  AND GETDATE() BETWEEN StartDate AND EndDate
                  AND UsedCount < UsageLimit
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, code);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Lấy danh sách tất cả các Voucher đang còn hiệu lực sử dụng
     */
    public List<Voucher> getActiveVouchers() {
        List<Voucher> list = new ArrayList<>();
        String sql = """
                SELECT * FROM Vouchers
                WHERE Status = 1
                  AND GETDATE() BETWEEN StartDate AND EndDate
                  AND UsedCount < UsageLimit
                ORDER BY VoucherID DESC
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Kiểm tra nhanh sự tồn tại và tính hợp lệ của mã Voucher (Trả về boolean)
     */
    public boolean isValidVoucher(String code) {
        String sql = """
                SELECT 1 FROM Vouchers
                WHERE VoucherCode = ?
                  AND Status = 1
                  AND GETDATE() BETWEEN StartDate AND EndDate
                  AND UsedCount < UsageLimit
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, code);
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // =========================================================================
    // CÁC THAO TÁC THÊM, SỬA, XÓA VÀ CẬP NHẬT TRẠNG THÁI SUẤT DÙNG
    // =========================================================================
    public boolean insert(Voucher v) {
        String sql = """
                INSERT INTO Vouchers
                (VoucherCode, Description, DiscountType, DiscountValue, MaxDiscountAmount, 
                 MinOrderValue, StartDate, EndDate, UsageLimit, UsedCount, Status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        return JdbcUtil.executeUpdate(sql,
                v.getVoucherCode(), v.getDescription(), v.getDiscountType(),
                v.getDiscountValue(), v.getMaxDiscountAmount(), v.getMinOrderValue(),
                v.getStartDate(), v.getEndDate(), v.getUsageLimit(),
                v.getUsedCount(), v.isStatus()
        ) > 0;
    }

    public boolean update(Voucher v) {
        String sql = """
                UPDATE Vouchers
                SET VoucherCode = ?, Description = ?, DiscountType = ?, DiscountValue = ?, 
                    MaxDiscountAmount = ?, MinOrderValue = ?, StartDate = ?, EndDate = ?, 
                    UsageLimit = ?, UsedCount = ?, Status = ?
                WHERE VoucherID = ?
                """;
        return JdbcUtil.executeUpdate(sql,
                v.getVoucherCode(), v.getDescription(), v.getDiscountType(),
                v.getDiscountValue(), v.getMaxDiscountAmount(), v.getMinOrderValue(),
                v.getStartDate(), v.getEndDate(), v.getUsageLimit(),
                v.getUsedCount(), v.isStatus(), v.getVoucherID()
        ) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Vouchers WHERE VoucherID = ?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }

    /**
     * Tự động cộng 1 vào số lượt đã dùng sau khi khách hàng áp mã thanh toán thành công
     */
    public boolean increaseUsedCount(int voucherID) {
        String sql = "UPDATE Vouchers SET UsedCount = UsedCount + 1 WHERE VoucherID = ?";
        return JdbcUtil.executeUpdate(sql, voucherID) > 0;
    }
}