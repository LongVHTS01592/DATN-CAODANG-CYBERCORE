package dao;

import entity.User;
import entity.UserAddress; // Nhớ import class này
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // =========================================================================
    // HÀM LẤY ĐỊA CHỈ (BỔ SUNG ĐỂ TRANG ADMIN KHÔNG BỊ LỖI)
    // =========================================================================
    private List<UserAddress> loadAddressesForUser(int userId) {
        List<UserAddress> list = new ArrayList<>();
        String sql = "SELECT * FROM UserAddresses WHERE UserID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            while (rs.next()) {
                UserAddress addr = new UserAddress();
                addr.setAddressID(rs.getInt("AddressID"));
                addr.setUserID(rs.getInt("UserID"));
                addr.setRecipientName(rs.getString("RecipientName"));
                addr.setPhone(rs.getString("Phone"));

                // Map đầy đủ các trường Tỉnh/Huyện/Xã
                addr.setProvinceName(rs.getString("ProvinceName"));
                addr.setDistrictName(rs.getString("DistrictName"));
                addr.setWardName(rs.getString("WardName"));

                // SỬA Ở ĐÂY: Hàm Java là setDetailedAddress, nhưng cột SQL phải là AddressText
                addr.setDetailedAddress(rs.getString("AddressText"));

                // Map thêm trạng thái mặc định
                addr.setIsDefault(rs.getBoolean("IsDefault"));

                list.add(addr);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi load địa chỉ cho userID: " + userId);
            e.printStackTrace();
        }
        return list;
    }

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserID(rs.getInt("UserID"));
        u.setUsername(rs.getString("Username"));
        u.setPasswordHash(rs.getString("PasswordHash"));
        u.setFullName(rs.getString("FullName"));
        u.setEmail(rs.getString("Email"));
        u.setPhone(rs.getString("Phone"));

        // Map thêm thuộc tính CoverUrl (Xử lý an toàn nếu NULL)
        u.setCoverUrl(rs.getString("CoverUrl"));

        u.setRoleID(rs.getInt("RoleID"));
        u.setActive(rs.getBoolean("IsActive"));
        u.setCreatedAt(rs.getTimestamp("CreatedAt"));
        u.setUpdatedAt(rs.getTimestamp("UpdatedAt"));

        // Tự động load danh sách địa chỉ đính kèm vào User
        u.setAddresses(loadAddressesForUser(u.getUserID()));

        return u;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC TRUY VẤN
    // =========================================================================
    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT TOP 50 * FROM Users ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public User findById(int id) {
        String sql = "SELECT * FROM Users WHERE UserID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public User findByUsername(String username) {
        String sql = "SELECT * FROM Users WHERE Username = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, username);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // =========================================================================
    // LOGIC ĐĂNG NHẬP
    // =========================================================================
    public User login(String loginIdentifier, String passwordHash) {
        System.out.println("=== DEBUG ĐĂNG NHẬP CYBERCORE ===");
        System.out.println("1. Tài khoản Client gửi lên: [" + loginIdentifier + "]");
        System.out.println("2. Mật khẩu Client gửi lên: [" + passwordHash + "]");

        String sql = "SELECT * FROM Users WHERE (Username = ? OR Email = ?) AND PasswordHash = ? AND IsActive = 1";

        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, loginIdentifier, loginIdentifier, passwordHash);

            if (rs.next()) {
                System.out.println("3. TRẠNG THÁI: Tìm thấy tài khoản trong Database! Đang map dữ liệu...");
                User u = map(rs);
                System.out.println("4. TRẠNG THÁI: Map dữ liệu thành công cho user: " + u.getFullName());
                return u;
            } else {
                System.out.println("3. LỖI LOGIC: Không tìm thấy tài khoản (Sai mật khẩu, sai tên hoặc tài khoản đã bị khóa)");
            }
        } catch (Exception e) {
            System.out.println("3. LỖI CRASH HỆ THỐNG: Kiểm tra lại tên cột hoặc kiểu dữ liệu bảng Users!");
            e.printStackTrace();
        }
        return null;
    }

    // =========================================================================
    // CÁC THAO TÁC THÊM, SỬA, XÓA
    // =========================================================================
    public boolean insert(User u) {
        String sql = """
                INSERT INTO Users (Username, PasswordHash, FullName, Email, Phone, CoverUrl, RoleID, IsActive) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;
        return JdbcUtil.executeUpdate(sql,
                u.getUsername(), u.getPasswordHash(), u.getFullName(),
                u.getEmail(), u.getPhone(), u.getCoverUrl(), u.getRoleID(), u.isActive()
        ) > 0;
    }

    public boolean update(User u) {
        String sql = """
                UPDATE Users 
                SET PasswordHash = ?, FullName = ?, Email = ?, Phone = ?, CoverUrl = ?, RoleID = ?, IsActive = ?, UpdatedAt = GETDATE() 
                WHERE UserID = ?
                """;
        return JdbcUtil.executeUpdate(sql,
                u.getPasswordHash(), u.getFullName(), u.getEmail(),
                u.getPhone(), u.getCoverUrl(), u.getRoleID(), u.isActive(), u.getUserID()
        ) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Users WHERE UserID = ?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }

    // =========================================================================
    // HÀM SET ĐỊA CHỈ MẶC ĐỊNH
    // =========================================================================
    public boolean setDefaultAddress(int userId, int addressId) {
        try {
            // 1. Reset tất cả địa chỉ của user này về false (0)
            String sqlReset = "UPDATE UserAddresses SET IsDefault = 0 WHERE UserID = ?";
            JdbcUtil.executeUpdate(sqlReset, userId);

            // 2. Set địa chỉ được chọn thành true (1)
            String sqlSetDefault = "UPDATE UserAddresses SET IsDefault = 1 WHERE AddressID = ?";
            return JdbcUtil.executeUpdate(sqlSetDefault, addressId) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}