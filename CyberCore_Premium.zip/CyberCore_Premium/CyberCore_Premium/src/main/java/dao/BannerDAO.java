package dao;

import entity.Banner;
import util.JdbcUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BannerDAO {

    // Hàm ánh xạ chung giúp code DRY (Don't Repeat Yourself)
    private Banner map(ResultSet rs) throws SQLException {
        Banner b = new Banner();
        b.setBannerID(rs.getInt("BannerID"));
        b.setTitle(rs.getString("Title"));
        b.setImageURL(rs.getString("ImageURL"));
        b.setPosition(rs.getString("Position"));
        b.setTargetLink(rs.getString("TargetLink"));
        b.setStartDate(rs.getTimestamp("StartDate"));
        b.setEndDate(rs.getTimestamp("EndDate"));
        b.setActive(rs.getBoolean("IsActive"));
        b.setCreatedAt(rs.getTimestamp("CreatedAt"));
        return b;
    }

    // 1. CLIENT: Chỉ lấy quảng cáo ĐANG BẬT & CÒN HIỆU LỰC
    public List<Banner> getActiveBanners() {
        List<Banner> list = new ArrayList<>();
        String sql = "SELECT * FROM Banners WHERE IsActive = 1 AND GETDATE() >= StartDate AND GETDATE() <= EndDate";
        try (ResultSet rs = JdbcUtil.executeQuery(sql)) {
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 2. ADMIN: Lấy TOÀN BỘ quảng cáo
    public List<Banner> findAll() {
        List<Banner> list = new ArrayList<>();
        String sql = "SELECT * FROM Banners ORDER BY CreatedAt DESC";
        try (ResultSet rs = JdbcUtil.executeQuery(sql)) {
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // 3. ADMIN: Lấy thông tin 1 Banner để chỉnh sửa
    public Banner findById(int id) {
        String sql = "SELECT * FROM Banners WHERE BannerID = ?";
        try (ResultSet rs = JdbcUtil.executeQuery(sql, id)) {
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // 4. ADMIN: Thêm, Sửa, Xóa
    public boolean insert(Banner b) {
        String sql = "INSERT INTO Banners (Title, ImageURL, Position, TargetLink, StartDate, EndDate, IsActive) VALUES (?, ?, ?, ?, ?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, b.getTitle(), b.getImageURL(), b.getPosition(), b.getTargetLink(), b.getStartDate(), b.getEndDate(), b.getIsActive()) > 0;
    }

    public boolean update(Banner b) {
        String sql = "UPDATE Banners SET Title=?, ImageURL=?, Position=?, TargetLink=?, StartDate=?, EndDate=?, IsActive=? WHERE BannerID=?";
        return JdbcUtil.executeUpdate(sql, b.getTitle(), b.getImageURL(), b.getPosition(), b.getTargetLink(), b.getStartDate(), b.getEndDate(), b.getIsActive(), b.getBannerID()) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Banners WHERE BannerID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }
}