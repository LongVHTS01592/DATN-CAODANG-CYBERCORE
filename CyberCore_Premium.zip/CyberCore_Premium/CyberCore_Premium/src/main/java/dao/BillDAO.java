package dao;

import entity.Bill;
import entity.BillDetail;
import entity.Product;
import entity.User;
import util.JdbcUtil;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private Bill map(ResultSet rs) throws SQLException {
        Bill b = new Bill();
        b.setBillID(rs.getInt("BillID"));
        b.setUserID(rs.getInt("UserID"));
        b.setOrderDate(rs.getTimestamp("OrderDate"));
        b.setShippingRecipientName(rs.getString("ShippingRecipientName"));
        b.setShippingPhone(rs.getString("ShippingPhone"));
        b.setShippingAddressText(rs.getString("ShippingAddressText"));
        b.setTotalAmount(rs.getBigDecimal("TotalAmount"));
        b.setVoucherCode(rs.getString("VoucherCode")); // Đã thêm VoucherCode
        b.setOrderStatus(rs.getString("OrderStatus"));
        b.setNotes(rs.getString("Notes"));
        return b;
    }

    // =========================================================================
    // 1. CÁC HÀM CRUD CƠ BẢN
    // =========================================================================
    public List<Bill> findAll() {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM Bills ORDER BY OrderDate DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Bill findById(int id) {
        String sql = "SELECT * FROM Bills WHERE BillID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public List<Bill> findByUserId(int userId) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM Bills WHERE UserID = ? ORDER BY OrderDate DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Bill> findByStatus(String status) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT * FROM Bills WHERE OrderStatus = ? ORDER BY OrderDate DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, status);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public int insert(Bill b) {
        String sql = """
                INSERT INTO Bills 
                (UserID, OrderDate, ShippingRecipientName, ShippingPhone, ShippingAddressText, TotalAmount, VoucherCode, OrderStatus, Notes) 
                VALUES (?, GETDATE(), ?, ?, ?, ?, ?, ?, ?)
                """;
        try (Connection con = JdbcUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, b.getUserID());
            ps.setString(2, b.getShippingRecipientName());
            ps.setString(3, b.getShippingPhone());
            ps.setString(4, b.getShippingAddressText());
            ps.setBigDecimal(5, b.getTotalAmount());
            ps.setString(6, b.getVoucherCode());
            ps.setString(7, b.getOrderStatus());
            ps.setString(8, b.getNotes());

            int row = ps.executeUpdate();
            if (row > 0) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) { return rs.getInt(1); }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return -1;
    }

    public boolean updateStatus(int billId, String status) {
        String sql = "UPDATE Bills SET OrderStatus = ? WHERE BillID = ?";
        return JdbcUtil.executeUpdate(sql, status, billId) > 0;
    }

    public boolean delete(int billId) {
        String sql = "DELETE FROM Bills WHERE BillID = ?";
        return JdbcUtil.executeUpdate(sql, billId) > 0;
    }

    // =========================================================================
    // 2. CÁC HÀM XỬ LÝ LOGIC ĐƠN HÀNG (CHECKOUT / PENDING)
    // =========================================================================
    public Bill getPendingBillByUserId(int userId) {
        String sql = "SELECT * FROM Bills WHERE UserID = ? AND OrderStatus = 'Pending'";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public void insertBillDetail(int billId, int productId, int quantity, BigDecimal price) {
        String sql = "INSERT INTO BillDetails (BillID, ProductID, Quantity, PriceAtSale) VALUES (?, ?, ?, ?)";
        JdbcUtil.executeUpdate(sql, billId, productId, quantity, price);
    }

    public void addOrUpdateProductToBill(int billId, int productId, int quantity, BigDecimal price) {
        String checkSql = "SELECT * FROM BillDetails WHERE BillID = ? AND ProductID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(checkSql, billId, productId);
            if (rs.next()) {
                String updateSql = "UPDATE BillDetails SET Quantity = Quantity + ? WHERE BillID = ? AND ProductID = ?";
                JdbcUtil.executeUpdate(updateSql, quantity, billId, productId);
            } else {
                insertBillDetail(billId, productId, quantity, price);
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void updateBillTotalAmount(int billId, BigDecimal newTotal) {
        String sql = "UPDATE Bills SET TotalAmount = ? WHERE BillID = ?";
        JdbcUtil.executeUpdate(sql, newTotal, billId);
    }

    // =========================================================================
    // 3. CÁC HÀM PHỤC VỤ ADMIN / TRUY VẤN NÂNG CAO
    // =========================================================================
    public List<Bill> getAllBillsWithDetails() {
        List<Bill> list = new ArrayList<>();
        String sql = """
                SELECT b.*, u.FullName, u.Username, 
                ISNULL((SELECT SUM(bd.Quantity) FROM BillDetails bd WHERE bd.BillID = b.BillID), 0) as RealTotalQuantity 
                FROM Bills b JOIN Users u ON b.UserID = u.UserID 
                ORDER BY b.OrderDate DESC
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                Bill b = map(rs);
                b.setQuantity(rs.getInt("RealTotalQuantity"));

                User u = new User();
                u.setFullName(rs.getString("FullName"));
                u.setUsername(rs.getString("Username"));
                b.setUser(u);

                b.setDetails(getDetailsByBillId(b.getBillID()));
                list.add(b);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<BillDetail> getDetailsByBillId(int billId) {
        List<BillDetail> details = new ArrayList<>();
        String sql = """
                SELECT bd.*, p.ProductName 
                FROM BillDetails bd JOIN Products p ON bd.ProductID = p.ProductID 
                WHERE bd.BillID = ?
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, billId);
            while (rs.next()) {
                BillDetail bd = new BillDetail();
                // Assumes you have standard getters/setters in BillDetail.java
                bd.setQuantity(rs.getInt("Quantity"));
                bd.setPriceAtSale(rs.getBigDecimal("PriceAtSale"));

                Product p = new Product();
                p.setProductName(rs.getString("ProductName"));
                bd.setProduct(p);

                details.add(bd);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return details;
    }

    public List<Bill> findHistoryAdvanced(String fromDate, String toDate, String payMethod) {
        List<Bill> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT b.* FROM Bills b LEFT JOIN Payments p ON b.BillID = p.BillID WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (fromDate != null && !fromDate.trim().isEmpty()) {
            sql.append("AND b.OrderDate >= ? ");
            params.add(fromDate + " 00:00:00");
        }
        if (toDate != null && !toDate.trim().isEmpty()) {
            sql.append("AND b.OrderDate <= ? ");
            params.add(toDate + " 23:59:59");
        }
        if (payMethod != null && !payMethod.trim().isEmpty() && !"All".equalsIgnoreCase(payMethod)) {
            if ("COD".equalsIgnoreCase(payMethod)) {
                sql.append("AND (p.PaymentMethod = ? OR p.PaymentMethod IS NULL) ");
            } else {
                sql.append("AND p.PaymentMethod = ? ");
            }
            params.add(payMethod);
        }
        sql.append("ORDER BY b.OrderDate DESC");

        try {
            ResultSet rs = JdbcUtil.executeQuery(sql.toString(), params.toArray());
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // =========================================================================
    // 4. CÁC HÀM THỐNG KÊ (DASHBOARD)
    // =========================================================================
    public int countPendingOrders() {
        String sql = "SELECT COUNT(*) FROM Bills WHERE OrderStatus = 'Pending'";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            if (rs.next()) { return rs.getInt(1); }
        } catch (Exception e) { e.printStackTrace(); }
        return 0;
    }

    public BigDecimal getTotalRevenue() {
        String sql = "SELECT ISNULL(SUM(TotalAmount), 0) FROM Bills WHERE OrderStatus = 'Completed'";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            if (rs.next()) { return rs.getBigDecimal(1); }
        } catch (Exception e) { e.printStackTrace(); }
        return BigDecimal.ZERO;
    }

    public List<Bill> getRecentOrders(int limit) {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT TOP (?) * FROM Bills ORDER BY OrderDate DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, limit);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}