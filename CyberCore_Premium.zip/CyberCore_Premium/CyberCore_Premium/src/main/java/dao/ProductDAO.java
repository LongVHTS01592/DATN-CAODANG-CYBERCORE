package dao;

import entity.Product;
import util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG (Thứ tự map chuẩn hóa theo DB)
    // =========================================================================
    private Product map(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setProductID(rs.getInt("ProductID"));
        p.setProductName(rs.getString("ProductName"));
        p.setCategoryID(rs.getInt("CategoryID"));
        p.setBrandID(rs.getInt("BrandID"));
        p.setOriginalPrice(rs.getBigDecimal("OriginalPrice"));
        p.setSellPrice(rs.getBigDecimal("SellPrice"));
        p.setDiscountPrice(rs.getBigDecimal("DiscountPrice"));
        p.setMainImageURL(rs.getString("MainImageURL"));
        p.setDescriptionText(rs.getString("DescriptionText"));
        p.setWarrantyMonths(rs.getInt("WarrantyMonths"));
        p.setStockQuantity(rs.getInt("StockQuantity"));
        p.setStatus(rs.getInt("Status"));
        p.setCreatedAt(rs.getTimestamp("CreatedAt"));
        return p;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC TRUY VẤN CƠ BẢN
    // =========================================================================
    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products ORDER BY ProductID DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Product findById(int id) {
        String sql = "SELECT * FROM Products WHERE ProductID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public List<Product> findByCategory(int categoryId) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE CategoryID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, categoryId);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> findByBrand(int brandId) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE BrandID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, brandId);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> searchByName(String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE ProductName LIKE ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, "%" + keyword + "%");
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> getNewestProducts(int top) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT TOP (?) * FROM Products ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, top);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    // =========================================================================
    // BỘ PHỘC ĐỘNG TÌM KIẾM NÂNG CAO (Gộp từ Project 3)
    // =========================================================================
    public List<Product> searchProducts(String search, Integer catId, Integer brandId) {
        List<Product> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM Products WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (search != null && !search.trim().isEmpty()) {
            sql.append(" AND ProductName LIKE ?");
            params.add("%" + search.trim() + "%");
        }
        if (catId != null && catId > 0) {
            sql.append(" AND CategoryID = ?");
            params.add(catId);
        }
        if (brandId != null && brandId > 0) {
            sql.append(" AND BrandID = ?");
            params.add(brandId);
        }

        sql.append(" ORDER BY ProductID DESC");

        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // =========================================================================
    // CÁC THAO TÁC THÊM, SỬA, XÓA, CẬP NHẬT KHO (Chuẩn hóa thứ tự cột)
    // =========================================================================
    public boolean insert(Product p) {
        String sql = """
                INSERT INTO Products 
                (ProductName, CategoryID, BrandID, OriginalPrice, SellPrice, DiscountPrice, MainImageURL, DescriptionText, WarrantyMonths, StockQuantity, Status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        return JdbcUtil.executeUpdate(sql,
                p.getProductName(), p.getCategoryID(), p.getBrandID(),
                p.getOriginalPrice(), p.getSellPrice(), p.getDiscountPrice(),
                p.getMainImageURL(), p.getDescriptionText(), p.getWarrantyMonths(),
                p.getStockQuantity(), p.getStatus()
        ) > 0;
    }

    public int insertAndGetId(Product p) {
        String sql = """
                INSERT INTO Products 
                (ProductName, CategoryID, BrandID, OriginalPrice, SellPrice, DiscountPrice, MainImageURL, DescriptionText, WarrantyMonths, StockQuantity, Status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
        boolean inserted = JdbcUtil.executeUpdate(sql,
                p.getProductName(), p.getCategoryID(), p.getBrandID(),
                p.getOriginalPrice(), p.getSellPrice(), p.getDiscountPrice(),
                p.getMainImageURL(), p.getDescriptionText(), p.getWarrantyMonths(),
                p.getStockQuantity(), p.getStatus()
        ) > 0;

        if (inserted) {
            String sqlGetId = "SELECT MAX(ProductID) AS MaxID FROM Products";
            try {
                ResultSet rs = JdbcUtil.executeQuery(sqlGetId);
                if (rs.next()) {
                    return rs.getInt("MaxID");
                }
            } catch (Exception e) { e.printStackTrace(); }
        }
        return -1;
    }

    public boolean update(Product p) {
        String sql = """
                UPDATE Products 
                SET ProductName = ?, CategoryID = ?, BrandID = ?, OriginalPrice = ?, SellPrice = ?, 
                    DiscountPrice = ?, MainImageURL = ?, DescriptionText = ?, WarrantyMonths = ?, 
                    StockQuantity = ?, Status = ? 
                WHERE ProductID = ?
                """;
        return JdbcUtil.executeUpdate(sql,
                p.getProductName(), p.getCategoryID(), p.getBrandID(),
                p.getOriginalPrice(), p.getSellPrice(), p.getDiscountPrice(),
                p.getMainImageURL(), p.getDescriptionText(), p.getWarrantyMonths(),
                p.getStockQuantity(), p.getStatus(), p.getProductID()
        ) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Products WHERE ProductID = ?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }

    /**
     * Tự động trừ số lượng hàng trong kho sau khi đặt hàng thành công (Có điều kiện phòng vệ chặn âm kho)
     */
    public boolean decreaseStock(int productId, int quantity) {
        String sql = "UPDATE Products SET StockQuantity = StockQuantity - ? WHERE ProductID = ? AND StockQuantity >= ?";
        boolean updated = JdbcUtil.executeUpdate(sql, quantity, productId, quantity) > 0;
        if (updated) {
            System.out.println("LOG [ProductDAO]: Đã trừ thành công " + quantity + " sản phẩm trong kho (ID: " + productId + ")");
        } else {
            System.err.println("LOG [ProductDAO]: Thất bại khi trừ kho ID " + productId + " (Có thể do vượt quá số lượng tồn kho)");
        }
        return updated;
    }
}