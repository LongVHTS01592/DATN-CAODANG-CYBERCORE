package dao;

import entity.RevenueReport;
import util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportDAO {

    /**
     * Lấy dữ liệu doanh thu và tổng số đơn hàng theo từng Tháng/Năm
     * (Đã tối ưu hóa bằng cách sử dụng JdbcUtil để quản lý ResultSet)
     */
    public List<RevenueReport> getMonthlyRevenue() {
        List<RevenueReport> list = new ArrayList<>();
        String sql = """
                SELECT YEAR(OrderDate) AS ReportYear, MONTH(OrderDate) AS ReportMonth, 
                       SUM(TotalAmount) AS TotalRevenue, COUNT(BillID) AS TotalOrders 
                FROM Bills 
                WHERE OrderStatus = N'Completed' 
                GROUP BY YEAR(OrderDate), MONTH(OrderDate) 
                ORDER BY ReportYear DESC, ReportMonth DESC
                """;
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                int year = rs.getInt("ReportYear");
                int month = rs.getInt("ReportMonth");
                double revenue = rs.getDouble("TotalRevenue");
                int orders = rs.getInt("TotalOrders");

                list.add(new RevenueReport(year, month, revenue, orders));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Lấy số liệu tổng hợp hiển thị lên 4 thẻ thông tin (Cards) trên Dashboard Admin
     */
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalRevenue", 0.0);
        stats.put("totalOrders", 0);
        stats.put("totalProducts", 0);
        stats.put("totalUsers", 0);

        String queryRevenue = "SELECT SUM(TotalAmount) FROM Bills WHERE OrderStatus = N'Completed'";
        String queryOrders = "SELECT COUNT(BillID) FROM Bills";
        String queryProducts = "SELECT COUNT(ProductID) FROM Products";
        // Giả định RoleID = 3 là phân quyền dành cho Khách hàng (Customer)
        String queryUsers = "SELECT COUNT(UserID) FROM Users WHERE RoleID = 3";

        // Sử dụng khối try-with-resources kết nối gốc ở đây là hợp lý vì cần thực hiện loạt nhiều query riêng biệt
        try (Connection conn = JdbcUtil.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(queryRevenue); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalRevenue", rs.getDouble(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryOrders); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalOrders", rs.getInt(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryProducts); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalProducts", rs.getInt(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryUsers); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalUsers", rs.getInt(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stats;
    }
}