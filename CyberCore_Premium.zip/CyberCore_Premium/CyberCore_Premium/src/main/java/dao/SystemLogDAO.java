package dao;

import entity.SystemLog;
import util.JdbcUtil;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SystemLogDAO {

    /**
     * Lấy 50 log mới nhất để hiển thị lên bảng điều khiển Console của Admin
     * (Sắp xếp ASC để dòng log cũ ở trên, log mới chạy ra sau cùng ở dưới theo đúng luồng thời gian)
     */
    public List<SystemLog> getRecentLogs() {
        List<SystemLog> list = new ArrayList<>();
        String sql = "SELECT TOP 50 * FROM SystemLogs ORDER BY CreatedAt ASC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                SystemLog log = new SystemLog();
                log.setLogID(rs.getInt("LogID"));

                // Kiểm tra an toàn tránh lỗi Unboxing từ DB khi UserID bị NULL
                log.setUserID(rs.getObject("UserID") != null ? rs.getInt("UserID") : null);

                log.setLogLevel(rs.getString("LogLevel"));
                log.setLogMessage(rs.getString("LogMessage"));
                log.setCreatedAt(rs.getTimestamp("CreatedAt"));
                list.add(log);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Hàm ghi nhận lịch sử hoạt động hệ thống (Thêm/Sửa/Xóa/Đăng nhập) từ các tầng Controller/Filter
     */
    public boolean insertLog(Integer userId, String level, String message) {
        String sql = "INSERT INTO SystemLogs (UserID, LogLevel, LogMessage) VALUES (?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, userId, level, message) > 0;
    }
}