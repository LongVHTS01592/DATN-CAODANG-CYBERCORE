package dao;

import entity.UserAddress;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserAddressDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private UserAddress map(ResultSet rs) throws SQLException {
        UserAddress a = new UserAddress();
        a.setAddressID(rs.getInt("AddressID"));
        a.setUserID(rs.getInt("UserID"));
        a.setRecipientName(rs.getString("RecipientName"));
        a.setPhone(rs.getString("Phone"));
        a.setProvinceName(rs.getString("ProvinceName"));
        a.setDistrictName(rs.getString("DistrictName"));
        a.setWardName(rs.getString("WardName"));

        // SỬA Ở ĐÂY: Lấy đúng tên cột AddressText trong SQL Server
        a.setDetailedAddress(rs.getString("AddressText"));

        a.setIsDefault(rs.getBoolean("IsDefault"));
        return a;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC TRUY VẤN
    // =========================================================================
    public List<UserAddress> findByUserId(int userId) {
        List<UserAddress> list = new ArrayList<>();
        String sql = "SELECT * FROM UserAddresses WHERE UserID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public UserAddress getDefaultAddress(int userId) {
        String sql = "SELECT * FROM UserAddresses WHERE UserID = ? AND IsDefault = 1";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // =========================================================================
    // CÁC THAO TÁC THÊM, XÓA
    // =========================================================================
    public boolean insert(UserAddress a) {
        // Lưu ý: Cột trong SQL tên là AddressText
        String sql = """
                INSERT INTO UserAddresses 
                (UserID, RecipientName, Phone, ProvinceName, DistrictName, WardName, AddressText, IsDefault) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """;
        return JdbcUtil.executeUpdate(sql,
                a.getUserID(),
                a.getRecipientName(),
                a.getPhone(),
                a.getProvinceName(),
                a.getDistrictName(),
                a.getWardName(),
                a.getDetailedAddress(), // Java thì lấy getDetailedAddress() bình thường
                a.getIsDefault()
        ) > 0;
    }

    public boolean delete(int addressId) {
        String sql = "DELETE FROM UserAddresses WHERE AddressID = ?";
        return JdbcUtil.executeUpdate(sql, addressId) > 0;
    }
}