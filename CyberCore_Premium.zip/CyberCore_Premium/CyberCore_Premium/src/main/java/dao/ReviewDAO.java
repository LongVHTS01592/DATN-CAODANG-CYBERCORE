package dao;

import entity.Review;
import util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ReviewDAO {

    // =========================================================================
    // HÀM MAP DỮ LIỆU CHUNG
    // =========================================================================
    private Review map(ResultSet rs) throws SQLException {
        Review r = new Review();
        r.setReviewID(rs.getInt("ReviewID"));
        r.setUserID(rs.getInt("UserID"));
        r.setProductID(rs.getInt("ProductID"));
        r.setRating(rs.getInt("Rating"));
        r.setComment(rs.getString("Comment"));
        r.setCreatedAt(rs.getTimestamp("CreatedAt"));
        return r;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC CRUD CƠ BẢN
    // =========================================================================
    public List<Review> findAll() {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM Reviews ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Review> findByProductId(int productId) {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM Reviews WHERE ProductID = ? ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, productId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insert(Review r) {
        String sql = "INSERT INTO Reviews (UserID, ProductID, Rating, Comment) VALUES (?, ?, ?, ?)";
        return JdbcUtil.executeUpdate(sql, r.getUserID(), r.getProductID(), r.getRating(), r.getComment()) > 0;
    }

    public boolean delete(int reviewId) {
        String sql = "DELETE FROM Reviews WHERE ReviewID = ?";
        return JdbcUtil.executeUpdate(sql, reviewId) > 0;
    }

    public double getAverageRating(int productId) {
        String sql = "SELECT AVG(CAST(Rating AS FLOAT)) FROM Reviews WHERE ProductID = ?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, productId);
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    // =========================================================================
    // CÁC PHƯƠNG THỨC BỘ LỌC ĐÁNH GIÁ (Hợp nhất từ Proj 2 & 3)
    // =========================================================================
    public List<Review> findByRating(int rating) {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM Reviews WHERE Rating = ? ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, rating);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Review> findBadReviews() {
        List<Review> list = new ArrayList<>();
        String sql = "SELECT * FROM Reviews WHERE Rating IN (1, 2) ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}