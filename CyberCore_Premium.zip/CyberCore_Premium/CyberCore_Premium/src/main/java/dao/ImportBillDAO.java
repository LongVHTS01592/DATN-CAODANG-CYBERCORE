package dao;

import entity.ImportBill;
import entity.ImportBillDetail;
import util.JdbcUtil;

import java.sql.*;
import java.util.List;

public class ImportBillDAO {

    /**
     * Lưu phiếu nhập kho và tự động cập nhật số lượng tồn kho của sản phẩm.
     * Sử dụng cấu trúc Transaction toàn vẹn dữ liệu chuẩn Premium.
     */
    public boolean addImportBill(ImportBill bill, List<ImportBillDetail> details) {
        String sqlBill = "INSERT INTO ImportBills (SupplierName, UserID, TotalImportAmount) VALUES (?, ?, ?)";
        String sqlDetail = "INSERT INTO ImportBillDetails (ImportBillID, ProductID, Quantity, ImportPrice) VALUES (?, ?, ?, ?)";
        String sqlUpdateStock = "UPDATE Products SET StockQuantity = StockQuantity + ? WHERE ProductID = ?";

        // Sử dụng try-with-resources cho Connection gốc để quản lý Transaction thủ công
        try (Connection con = JdbcUtil.getConnection()) {
            con.setAutoCommit(false); // Kích hoạt chế độ Transaction bọc an toàn

            int importBillID = 0;
            // 1. Thêm thông tin hóa đơn tổng và lấy ID tự sinh (Generated Keys)
            try (PreparedStatement psBill = con.prepareStatement(sqlBill, Statement.RETURN_GENERATED_KEYS)) {
                psBill.setString(1, bill.getSupplierName());
                psBill.setInt(2, bill.getUserID());
                psBill.setBigDecimal(3, bill.getTotalImportAmount());
                psBill.executeUpdate();

                try (ResultSet rs = psBill.getGeneratedKeys()) {
                    if (rs.next()) {
                        importBillID = rs.getInt(1);
                    }
                }
            }

            // Kiểm tra nếu không lấy được ID hóa đơn thì hủy bỏ luôn
            if (importBillID == 0) {
                con.rollback();
                return false;
            }

            // 2. Thêm chi tiết phiếu nhập và cập nhật tăng số lượng tồn kho tương ứng
            try (PreparedStatement psDetail = con.prepareStatement(sqlDetail);
                 PreparedStatement psUpdate = con.prepareStatement(sqlUpdateStock)) {

                for (ImportBillDetail d : details) {
                    // Thực thi Insert dữ liệu vào bảng chi tiết
                    psDetail.setInt(1, importBillID);
                    psDetail.setInt(2, d.getProductID());
                    psDetail.setInt(3, d.getQuantity());
                    psDetail.setBigDecimal(4, d.getImportPrice());
                    psDetail.executeUpdate();

                    // Thực thi Cập nhật tăng số lượng tồn kho (StockQuantity) cho sản phẩm
                    psUpdate.setInt(1, d.getQuantity());
                    psUpdate.setInt(2, d.getProductID());
                    psUpdate.executeUpdate();
                }
            }

            con.commit(); // Hoàn thành tất cả các bước không lỗi -> Lưu thay đổi vào DB
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            // Nếu có bất kỳ lỗi nào xảy ra trong chuỗi tiến trình, hệ thống tự động rollback để bảo toàn kho
            return false;
        }
    }
}