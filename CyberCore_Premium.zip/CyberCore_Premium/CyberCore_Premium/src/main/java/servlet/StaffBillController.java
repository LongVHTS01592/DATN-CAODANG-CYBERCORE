package servlet;

import dao.BillDAO;
import dao.BillDetailDAO;
import entity.Bill;
import entity.BillDetail;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/StaffBillController")
public class StaffBillController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final BillDetailDAO billDetailDAO = new BillDetailDAO();

    // HÀM HELPER BẢO MẬT
    private boolean isNotStaff(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT NHÂN VIÊN
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String idParam = request.getParameter("id");

        // 1. XỬ LÝ CÁC THAO TÁC NHANH TỪ NÚT BẤM CỦA BẢN 3 (WORKFLOW HOÀN CHỈNH)
        if (action != null && idParam != null) {
            int billId = Integer.parseInt(idParam);

            if ("approve".equals(action)) {
                billDAO.updateStatus(billId, "Confirmed");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Pending");
                return;
            } else if ("Processing".equals(action)) {
                billDAO.updateStatus(billId, "Processing");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Confirmed");
                return;
            } else if ("shipping".equals(action)) {
                billDAO.updateStatus(billId, "Shipping");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Processing");
                return;
            } else if ("complete".equals(action)) {
                billDAO.updateStatus(billId, "Completed");
                response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Shipping");
                return;
            } else if ("cancel".equals(action)) {
                Bill bill = billDAO.findById(billId);
                // Chỉ cho phép hủy nếu chưa bắt đầu giao hàng
                if (bill != null && (bill.getOrderStatus().equals("Pending") ||
                        bill.getOrderStatus().equals("Confirmed") ||
                        bill.getOrderStatus().equals("Processing"))) {
                    billDAO.updateStatus(billId, "Cancelled");
                    response.sendRedirect(request.getContextPath() + "/StaffBillController?status=" + bill.getOrderStatus());
                } else {
                    request.setAttribute("error", "Đơn hàng này không thể hủy vì đã được giao hoặc hoàn thành!");
                    response.sendRedirect(request.getContextPath() + "/StaffBillController?status=" + (bill != null ? bill.getOrderStatus() : "Pending"));
                }
                return;
            } else if ("detail".equals(action)) {
                Bill bill = billDAO.findById(billId);
                List<BillDetail> details = billDetailDAO.findDetailsWithProductName(billId);

                request.setAttribute("selectedBill", bill);
                request.setAttribute("billDetails", details);
                request.getRequestDispatcher("/staff/bill_detail_modal.jsp").forward(request, response);
                return;
            }
        }

        // 2. XỬ LÝ LỌC THEO TAB TRẠNG THÁI VÀ TÌM KIẾM
        String status = request.getParameter("status");
        if (status == null || status.trim().isEmpty()) {
            status = "Pending";
        }

        String searchBill = request.getParameter("searchBill");
        List<Bill> allBills = billDAO.findAll();
        List<Bill> filteredBills = new ArrayList<>();

        if (allBills != null) {
            final String finalStatus = status;
            final String keyword = (searchBill != null) ? searchBill.trim().toLowerCase() : "";

            filteredBills = allBills.stream()
                    .filter(b -> finalStatus.equalsIgnoreCase(b.getOrderStatus())) // Lọc trạng thái
                    .filter(b -> keyword.isEmpty() || // Lọc từ khóa
                            String.valueOf(b.getBillID()).contains(keyword) ||
                            (b.getShippingRecipientName() != null && b.getShippingRecipientName().toLowerCase().contains(keyword)))
                    .collect(Collectors.toList());
        }

        // 3. ĐẨY DỮ LIỆU SANG JSP
        request.setAttribute("bills", filteredBills);
        request.setAttribute("currentStatus", status);
        request.getRequestDispatcher("/staff/staff_bill.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}