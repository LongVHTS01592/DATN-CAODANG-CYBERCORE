package servlet;

import dao.ReviewDAO;
import dao.UserDAO;
import entity.Review;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/CustomerSupportController")
public class CustomerSupportController extends HttpServlet {

    private final ReviewDAO reviewDAO = new ReviewDAO();
    private final UserDAO userDAO = new UserDAO();

    // HÀM HELPER BẢO MẬT
    private boolean isNotStaff(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String ratingParam = request.getParameter("rating");
        List<Review> reviewList;

        if ("bad".equals(ratingParam)) {
            reviewList = reviewDAO.findBadReviews();
        } else if (ratingParam != null && !ratingParam.trim().isEmpty()) {
            try {
                int rating = Integer.parseInt(ratingParam);
                reviewList = reviewDAO.findByRating(rating);
            } catch (NumberFormatException e) {
                reviewList = reviewDAO.findAll();
            }
        } else {
            reviewList = reviewDAO.findAll();
        }

        // ĐỒNG BỘ ĐỐI TƯỢNG USER & TẠO AVATAR TEXT BẰNG JAVA
        if (reviewList != null) {
            for (Review rev : reviewList) {
                User u = userDAO.findById(rev.getUserID());
                if (u != null) {
                    rev.setUser(u);
                    String name = (u.getUsername() != null && !u.getUsername().isEmpty()) ? u.getUsername() : "KH";

                    if (name.length() >= 2) {
                        rev.setAvatarText(name.substring(0, 2).toUpperCase());
                    } else {
                        rev.setAvatarText(name.toUpperCase());
                    }
                } else {
                    rev.setAvatarText("KH");
                }
            }
        }

        request.setAttribute("reviews", reviewList);
        request.getRequestDispatcher("/staff/customer_support.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN BẢO MẬT (Chống mạo danh submit form)
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String reviewIdParam = request.getParameter("reviewID");
        String replyComment = request.getParameter("replyComment");

        if (reviewIdParam != null && replyComment != null) {
            int reviewId = Integer.parseInt(reviewIdParam);
            // TODO: Mở rộng tính năng gọi ReviewDAO.updateReply(...) lưu xuống DB trong tương lai
            System.out.println("Nhân viên phản hồi cho Review #" + reviewId + ": " + replyComment);
        }

        response.sendRedirect(request.getContextPath() + "/CustomerSupportController");
    }
}