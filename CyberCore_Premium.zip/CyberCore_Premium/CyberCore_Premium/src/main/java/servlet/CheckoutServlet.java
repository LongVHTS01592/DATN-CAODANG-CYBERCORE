package servlet;

import dao.BillDAO;
import dao.CartDAO;
import dao.CartDetailDAO;
import dao.ProductDAO;
import entity.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    private final CartDAO cartDAO = new CartDAO();
    private final CartDetailDAO cartDetailDAO = new CartDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final BillDAO billDAO = new BillDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart != null) {
            List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
            BigDecimal total = BigDecimal.ZERO;

            for (CartDetail cd : details) {
                Product p = productDAO.findById(cd.getProductID());
                cd.setProduct(p);
                if (p != null && p.getSellPrice() != null) {
                    BigDecimal subtotal = p.getSellPrice().multiply(new BigDecimal(cd.getQuantity()));
                    total = total.add(subtotal);
                }
            }
            request.setAttribute("cartDetails", details);
            request.setAttribute("totalAmount", total);

            // Đồng bộ mã Voucher giảm giá từ Session ra giao diện Checkout
            request.setAttribute("discountAmount", session.getAttribute("discountAmount"));
            request.setAttribute("voucherCode", session.getAttribute("voucherCode"));
        }

        request.getRequestDispatcher("/views/checkout.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) return;

        List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
        if (details == null || details.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }

        String recipientName = request.getParameter("recipientName");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String notes = request.getParameter("notes");
        String paymentMethod = request.getParameter("paymentMethod");

        // 1. Tính toán tổng số tiền giỏ hàng hiện tại bằng BigDecimal
        BigDecimal currentCartTotal = BigDecimal.ZERO;
        for (CartDetail cd : details) {
            Product p = productDAO.findById(cd.getProductID());
            if (p != null && p.getSellPrice() != null) {
                currentCartTotal = currentCartTotal.add(p.getSellPrice().multiply(new BigDecimal(cd.getQuantity())));
            }
        }

        // Khấu trừ số tiền Voucher nếu có áp dụng (Tối ưu: Chuyển đổi trực tiếp tránh lỗi lệch tiền)
        Object discountObj = session.getAttribute("discountAmount");
        if (discountObj != null) {
            BigDecimal discount = new BigDecimal(discountObj.toString());
            currentCartTotal = currentCartTotal.subtract(discount);
            if (currentCartTotal.compareTo(BigDecimal.ZERO) < 0) {
                currentCartTotal = BigDecimal.ZERO;
            }
        }

        // 2. Kiểm tra xem tài khoản này hiện có đơn hàng nào đang ở trạng thái chờ duyệt (Pending) không
        Bill pendingBill = billDAO.getPendingBillByUserId(user.getUserID());
        boolean isSuccess = false;
        Bill finalBillForReceipt = null;
        Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

        if (pendingBill != null) {
            // TRƯỜNG HỢP A: Người dùng đang có đơn chờ duyệt -> Thực hiện CỘNG DỒN mặt hàng vào đơn cũ
            int currentBillId = pendingBill.getBillID();

            for (CartDetail cd : details) {
                Product p = productDAO.findById(cd.getProductID());
                BigDecimal price = (p != null) ? p.getSellPrice() : BigDecimal.ZERO;

                billDAO.addOrUpdateProductToBill(currentBillId, cd.getProductID(), cd.getQuantity(), price);
                productDAO.decreaseStock(cd.getProductID(), cd.getQuantity()); // Trừ kho sản phẩm
            }

            BigDecimal newTotalAmount = pendingBill.getTotalAmount().add(currentCartTotal);
            billDAO.updateBillTotalAmount(currentBillId, newTotalAmount);

            // Cập nhật lại thông tin nhận hàng mới nhất của form vào đơn cũ để hiển thị hóa đơn
            pendingBill.setShippingRecipientName(recipientName);
            pendingBill.setShippingPhone(phone);
            pendingBill.setShippingAddressText(address);
            pendingBill.setTotalAmount(newTotalAmount);
            pendingBill.setOrderDate(currentTimestamp);

            finalBillForReceipt = pendingBill;
            isSuccess = true;

        } else {
            // TRƯỜNG HỢP B: Chưa có đơn chờ duyệt -> Khởi TẠO ĐƠN HÀNG MỚI hoàn toàn
            Bill bill = new Bill();
            bill.setUserID(user.getUserID());
            bill.setShippingRecipientName(recipientName);
            bill.setShippingPhone(phone);
            bill.setShippingAddressText(address);
            bill.setTotalAmount(currentCartTotal);
            bill.setOrderStatus("Pending");
            bill.setNotes(notes);
            bill.setOrderDate(currentTimestamp);

            int newBillId = billDAO.insert(bill);

            if (newBillId > 0) {
                bill.setBillID(newBillId);
                for (CartDetail cd : details) {
                    Product p = productDAO.findById(cd.getProductID());
                    BigDecimal price = (p != null) ? p.getSellPrice() : BigDecimal.ZERO;

                    billDAO.insertBillDetail(newBillId, cd.getProductID(), cd.getQuantity(), price);
                    productDAO.decreaseStock(cd.getProductID(), cd.getQuantity()); // Trừ kho sản phẩm
                }
                finalBillForReceipt = bill;
                isSuccess = true;
            }
        }

        // 3. Xử lý sau khi đặt hàng thành công (Dọn dẹp giỏ hàng & Điều hướng trang)
        if (isSuccess) {
            cartDetailDAO.clearCart(cart.getCartID());

            // Xóa sạch dấu vết voucher cũ trong session để tránh bug lặp lại giảm giá lần sau
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            // Lưu thông tin tạm thời phục vụ hiển thị biên lai thành công
            session.setAttribute("recentBill", finalBillForReceipt);
            session.setAttribute("recentPaymentMethod", paymentMethod);

            // Điều hướng thông minh dựa vào phương thức thanh toán
            if ("BANK".equals(paymentMethod)) {
                response.sendRedirect(request.getContextPath() + "/views/qr-payment.jsp");
            } else {
                response.sendRedirect(request.getContextPath() + "/views/success.jsp");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/checkout?error=true");
        }
    }
}