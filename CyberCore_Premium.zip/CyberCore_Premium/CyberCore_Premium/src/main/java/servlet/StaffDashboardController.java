package servlet;

import dao.BillDAO;
import dao.ImportRequestDAO;
import dao.ProductDAO;
import entity.Bill;
import entity.ImportRequest;
import entity.Product;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet("/staff/dashboard")
public class StaffDashboardController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final ImportRequestDAO importRequestDAO = new ImportRequestDAO();

    // HÀM HELPER BẢO MẬT: Chỉ cho phép Admin (RoleID = 1) và Staff (RoleID = 2)
    private boolean isNotStaff(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Ngăn chặn khách hàng tò mò vào xem Dashboard nội bộ
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            // 1. ĐẾM SỐ ĐƠN HÀNG MỚI (Trạng thái 'Pending')
            int newOrdersCount = billDAO.countPendingOrders();

            // 2. LỌC SẢN PHẨM SẮP HẾT HÀNG (Số lượng < 5 và đang được bán)
            List<Product> allProducts = productDAO.findAll();
            List<Product> lowStockProducts = allProducts.stream()
                    .filter(p -> p.getStockQuantity() < 5 && p.getStatus() == 1)
                    .collect(Collectors.toList());
            int lowStockCount = lowStockProducts.size();

            // 3. LẤY DANH SÁCH ĐƠN HÀNG MỚI NHẤT CẦN XỬ LÝ (Top 5 đơn)
            List<Bill> recentOrders = billDAO.getRecentOrders(5);

            // 4. LẤY CÁC YÊU CẦU NHẬP HÀNG ĐANG CHỜ DUYỆT
            List<ImportRequest> myRequests = importRequestDAO.getPendingRequests();

            // Đẩy tất cả dữ liệu thống kê sang trang JSP
            request.setAttribute("newOrdersCount", newOrdersCount);
            request.setAttribute("lowStockProducts", lowStockProducts);
            request.setAttribute("lowStockCount", lowStockCount);
            request.setAttribute("recentOrders", recentOrders);
            request.setAttribute("myRequests", myRequests);

            // Chuyển tiếp đến giao diện Dashboard của nhân viên
            request.getRequestDispatcher("/staff/staff_dashboard.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Lỗi hệ thống Dashboard: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN BẢO MẬT POST: Chặn đứng các hành vi hack Form/gửi request lậu
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        // XỬ LÝ GỬI YÊU CẦU NHẬP HÀNG TỪ BẢN 3
        if ("sendRequest".equals(action)) {
            String pIdStr = request.getParameter("productId");
            String qtyStr = request.getParameter("quantity");

            if (pIdStr != null && !pIdStr.isEmpty() && qtyStr != null && !qtyStr.isEmpty()) {
                try {
                    int productId = Integer.parseInt(pIdStr);
                    int quantity = Integer.parseInt(qtyStr);
                    String note = request.getParameter("note");

                    // Lấy thông tin Staff đang thao tác một cách an toàn
                    User user = (User) request.getSession().getAttribute("userAccount");
                    int staffId = user.getUserID();

                    // Lưu yêu cầu nhập kho vào CSDL
                    importRequestDAO.insertRequest(productId, quantity, note, staffId);
                    response.sendRedirect(request.getContextPath() + "/staff/dashboard?status=success");
                    return;
                } catch (NumberFormatException e) {
                    response.sendRedirect(request.getContextPath() + "/staff/dashboard?status=error_invalid_number");
                    return;
                }
            } else {
                response.sendRedirect(request.getContextPath() + "/staff/dashboard?status=error_missing_data");
                return;
            }
        }

        doGet(request, response);
    }
}