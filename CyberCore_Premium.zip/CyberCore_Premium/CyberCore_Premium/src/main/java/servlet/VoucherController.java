package servlet;

import dao.VoucherDAO;
import entity.User;
import entity.Voucher;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.List;

@WebServlet("/voucher")
public class VoucherController extends HttpServlet {

    private VoucherDAO voucherDAO;

    @Override
    public void init() {
        voucherDAO = new VoucherDAO();
    }

    // --- HÀM HELPER BẢO MẬT TÁI SỬ DỤNG ---
    private boolean isNotAdmin(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT VOUCHER
        if (isNotAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) {
            action = "list";
        }

        switch (action) {
            case "delete":
                deleteVoucher(request, response);
                break;
            case "edit":
                editVoucher(request, response);
                break;
            default:
                listVoucher(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN BẢO MẬT VOUCHER (Tránh submit form bằng postman)
        if (isNotAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            addVoucher(request, response);
        } else if ("update".equals(action)) {
            updateVoucher(request, response);
        }
    }

    private void listVoucher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Voucher> list = voucherDAO.findAll();
        request.setAttribute("voucherList", list);
        request.getRequestDispatcher("/admin/admin_voucher.jsp").forward(request, response);
    }

    private void addVoucher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Voucher voucher = getVoucherFromRequest(request);
            voucher.setUsedCount(0); // Mặc định số lượt đã dùng ban đầu là 0
            voucherDAO.insert(voucher);
            response.sendRedirect("voucher");
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.setAttribute("voucherList", voucherDAO.findAll());
            request.getRequestDispatcher("/admin/admin_voucher.jsp").forward(request, response);
        }
    }

    private void updateVoucher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            Voucher voucher = getVoucherFromRequest(request);
            voucher.setVoucherID(Integer.parseInt(request.getParameter("voucherID")));

            // Giữ nguyên lượt đã dùng cũ để không bị reset khi cập nhật
            Voucher oldVoucher = voucherDAO.findById(voucher.getVoucherID());
            if (oldVoucher != null) {
                voucher.setUsedCount(oldVoucher.getUsedCount());
            }

            voucherDAO.update(voucher);
            response.sendRedirect("voucher");
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
            request.setAttribute("voucherList", voucherDAO.findAll());
            request.getRequestDispatcher("/admin/admin_voucher.jsp").forward(request, response);
        }
    }

    private void deleteVoucher(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        voucherDAO.delete(id);
        response.sendRedirect("voucher");
    }

    private void editVoucher(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Voucher voucher = voucherDAO.findById(id);
        request.setAttribute("voucher", voucher);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");
        if (voucher != null) {
            if (voucher.getStartDate() != null) {
                request.setAttribute("startDateValue", voucher.getStartDate().toLocalDateTime().format(formatter));
            }
            if (voucher.getEndDate() != null) {
                request.setAttribute("endDateValue", voucher.getEndDate().toLocalDateTime().format(formatter));
            }
        }

        request.setAttribute("voucherList", voucherDAO.findAll());
        request.getRequestDispatcher("/admin/admin_voucher.jsp").forward(request, response);
    }

    // Hàm Validation và trích xuất dữ liệu đa năng
    private Voucher getVoucherFromRequest(HttpServletRequest request) {
        Voucher voucher = new Voucher();

        String voucherCode = request.getParameter("voucherCode");
        String description = request.getParameter("description");
        String discountType = request.getParameter("discountType");
        String discountValue = request.getParameter("discountValue");
        String minOrderValue = request.getParameter("minOrderValue");
        String usageLimit = request.getParameter("usageLimit");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        // Validation nghiêm ngặt
        if (voucherCode == null || voucherCode.trim().isEmpty()) {
            throw new IllegalArgumentException("Mã voucher không được để trống!");
        }
        if (discountValue == null || discountValue.trim().isEmpty()) {
            throw new IllegalArgumentException("Giá trị giảm không được để trống!");
        }
        if (minOrderValue == null || minOrderValue.trim().isEmpty()) {
            throw new IllegalArgumentException("Đơn tối thiểu không được để trống!");
        }
        if (usageLimit == null || usageLimit.trim().isEmpty()) {
            throw new IllegalArgumentException("Số lượt sử dụng không được để trống!");
        }
        if (startDate == null || startDate.trim().isEmpty()) {
            throw new IllegalArgumentException("Ngày bắt đầu không được để trống!");
        }
        if (endDate == null || endDate.trim().isEmpty()) {
            throw new IllegalArgumentException("Ngày kết thúc không được để trống!");
        }

        voucher.setVoucherCode(voucherCode);
        voucher.setDescription(description);
        voucher.setDiscountType(discountType);
        voucher.setDiscountValue(new BigDecimal(discountValue));

        String maxDiscount = request.getParameter("maxDiscountAmount");
        if (maxDiscount != null && !maxDiscount.trim().isEmpty()) {
            voucher.setMaxDiscountAmount(new BigDecimal(maxDiscount));
        }

        voucher.setMinOrderValue(new BigDecimal(minOrderValue));

        // Chuẩn hóa định dạng DateTime T của HTML5 sang Timestamp của SQL
        voucher.setStartDate(Timestamp.valueOf(startDate.replace("T", " ") + ":00"));
        voucher.setEndDate(Timestamp.valueOf(endDate.replace("T", " ") + ":00"));

        voucher.setUsageLimit(Integer.parseInt(usageLimit));
        voucher.setStatus(request.getParameter("status") != null);

        return voucher;
    }
}