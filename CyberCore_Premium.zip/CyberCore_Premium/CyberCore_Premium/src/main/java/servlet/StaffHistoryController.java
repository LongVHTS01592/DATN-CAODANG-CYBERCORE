package servlet;

import dao.BillDAO;
import dao.PaymentDAO;
import dao.UserDAO;
import entity.Bill;
import entity.Payment;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/StaffHistoryController")
public class StaffHistoryController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final PaymentDAO paymentDAO = new PaymentDAO();
    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Đảm bảo chỉ Nhân viên hoặc Admin mới có quyền tra cứu lịch sử nâng cao
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        if (currentUser == null || currentUser.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Lấy dữ liệu bộ lọc nâng cao từ giao diện gửi lên
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        String payMethod = request.getParameter("payMethod");

        // 1. LẤY DANH SÁCH HÓA ĐƠN ĐÃ LỌC
        List<Bill> billList = billDAO.findHistoryAdvanced(fromDate, toDate, payMethod);

        // Các biến tích hợp tính toán số liệu thống kê nhanh cho top-bar
        int completedCount = 0;
        int cancelledCount = 0;
        BigDecimal totalSettledAmount = BigDecimal.ZERO;

        List<HistoryStatementDTO> historyStatements = new ArrayList<>();

        if (billList != null) {
            for (Bill b : billList) {
                HistoryStatementDTO stmt = new HistoryStatementDTO();
                stmt.setBillID(b.getBillID());
                stmt.setOrderDate(b.getOrderDate());
                stmt.setTotalAmount(b.getTotalAmount());
                stmt.setOrderStatus(b.getOrderStatus());

                // Đồng bộ tên thật khách hàng thông qua UserID
                User u = userDAO.findById(b.getUserID());
                stmt.setCustomerName(u != null ? u.getFullName() : b.getShippingRecipientName());

                // Truy vết thông tin cổng thanh toán giao dịch từ PaymentDAO
                Payment p = paymentDAO.findByBillId(b.getBillID());
                if (p != null) {
                    stmt.setPaymentMethod(p.getPaymentMethod());
                    stmt.setTransactionCode(p.getTransactionCode());
                } else {
                    // Dự phòng nếu không có bản ghi ngân hàng (Mặc định COD)
                    stmt.setPaymentMethod(b.getNotes() != null && !b.getNotes().trim().isEmpty() ? b.getNotes() : "COD");
                    stmt.setTransactionCode(null);
                }

                // Thực hiện phân loại đếm đơn và tích lũy tổng tiền thực thu (Chỉ tính đơn Completed)
                if ("Completed".equalsIgnoreCase(b.getOrderStatus())) {
                    completedCount++;
                    if (b.getTotalAmount() != null) {
                        totalSettledAmount = totalSettledAmount.add(b.getTotalAmount());
                    }
                } else if ("Cancelled".equalsIgnoreCase(b.getOrderStatus())) {
                    cancelledCount++;
                }

                historyStatements.add(stmt);
            }
        }

        // 2. ĐẨY DỮ LIỆU THỐNG KÊ VÀ DANH SÁCH RA JSP
        request.setAttribute("historyStatements", historyStatements);
        request.setAttribute("completedOrdersCount", completedCount);
        request.setAttribute("cancelledOrdersCount", cancelledCount);
        request.setAttribute("totalSettledAmount", totalSettledAmount);

        request.getRequestDispatcher("/staff/staff_history.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    // =========================================================================
    // Lớp DTO trung gian (Inner Class) gom nhóm thông tin tương thích cho bảng JSP
    // =========================================================================
    public static class HistoryStatementDTO {
        private int billID;
        private java.util.Date orderDate;
        private String customerName;
        private BigDecimal totalAmount;
        private String paymentMethod;
        private String transactionCode;
        private String orderStatus;

        public int getBillID() { return billID; }
        public void setBillID(int billID) { this.billID = billID; }
        public java.util.Date getOrderDate() { return orderDate; }
        public void setOrderDate(java.util.Date orderDate) { this.orderDate = orderDate; }
        public String getCustomerName() { return customerName; }
        public void setCustomerName(String customerName) { this.customerName = customerName; }
        public BigDecimal getTotalAmount() { return totalAmount; }
        public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
        public String getPaymentMethod() { return paymentMethod; }
        public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
        public String getTransactionCode() { return transactionCode; }
        public void setTransactionCode(String transactionCode) { this.transactionCode = transactionCode; }
        public String getOrderStatus() { return orderStatus; }
        public void setOrderStatus(String orderStatus) { this.orderStatus = orderStatus; }
    }
}