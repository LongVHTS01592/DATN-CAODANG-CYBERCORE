package servlet;

import dao.UserAddressDAO;
import dao.UserDAO; // Nhớ import UserDAO
import entity.User;
import entity.UserAddress;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/UserAddressController")
public class UserAddressController extends HttpServlet {

    private final UserAddressDAO addressDAO = new UserAddressDAO();
    private final UserDAO userDAO = new UserDAO(); // Gọi UserDAO để lát nữa refresh session

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            session.setAttribute("error", "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại!");
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        if (action == null || action.isEmpty()) {
            action = "add";
        }

        try {
            if ("add".equals(action)) {
                String recipientName = request.getParameter("recipientName");
                String phone = request.getParameter("phone");
                String detailedAddress = request.getParameter("detailedAddress");

                // MẸO FIX LỖI: Cung cấp giá trị mặc định cho các cột NOT NULL trong DB
                String provinceName = request.getParameter("provinceName");
                if (provinceName == null) provinceName = "Chưa cập nhật";

                String districtName = request.getParameter("districtName");
                if (districtName == null) districtName = "Chưa cập nhật";

                String wardName = request.getParameter("wardName");
                if (wardName == null) wardName = "Chưa cập nhật";

                String isDefaultStr = request.getParameter("isDefault");
                boolean isDefault = "on".equals(isDefaultStr) || "true".equals(isDefaultStr);

                UserAddress address = new UserAddress();
                address.setUserID(user.getUserID());
                address.setRecipientName(recipientName);
                address.setPhone(phone);
                address.setProvinceName(provinceName);
                address.setDistrictName(districtName);
                address.setWardName(wardName);
                address.setDetailedAddress(detailedAddress);
                address.setIsDefault(isDefault);

                boolean isSuccess = addressDAO.insert(address);

                if (isSuccess) {
                    session.setAttribute("msg", "Thêm địa chỉ thành công!");

                    // QUAN TRỌNG NHẤT: Lấy lại thông tin User từ DB (đã bao gồm list địa chỉ mới)
                    // và nạp đè lại vào Session để màn hình Profile hiện ra ngay lập tức
                    User updatedUser = userDAO.findById(user.getUserID());
                    session.setAttribute("userAccount", updatedUser);
                } else {
                    session.setAttribute("error", "Có lỗi xảy ra khi thêm địa chỉ vào CSDL.");
                }
            }
            // =========================================================
            // TÍNH NĂNG MỚI: THIẾT LẬP ĐỊA CHỈ MẶC ĐỊNH
            // =========================================================
            else if ("setDefault".equals(action)) {
                int addressId = Integer.parseInt(request.getParameter("addressID"));

                // Gọi hàm từ UserDAO để set 1 cho địa chỉ này, và 0 cho các địa chỉ khác
                boolean isSuccess = userDAO.setDefaultAddress(user.getUserID(), addressId);

                if (isSuccess) {
                    session.setAttribute("msg", "Đã cập nhật địa chỉ mặc định thành công!");

                    // QUAN TRỌNG: Làm mới lại Session ngay lập tức để giao diện ẩn nút đi
                    User updatedUser = userDAO.findById(user.getUserID());
                    session.setAttribute("userAccount", updatedUser);
                } else {
                    session.setAttribute("error", "Có lỗi xảy ra khi cập nhật địa chỉ mặc định.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
        }

        // Tự động load lại trang Profile
        response.sendRedirect(request.getContextPath() + "/ProfileController");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}