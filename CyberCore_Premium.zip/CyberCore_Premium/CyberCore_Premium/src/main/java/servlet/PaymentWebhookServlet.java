package servlet;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "PaymentWebhookServlet", value = "/api/payment-webhook")
public class PaymentWebhookServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(PaymentWebhookServlet.class.getName());

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuilder buffer = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;

        // Đọc toàn bộ luồng dữ liệu thô (Raw JSON payload) gửi từ server PayOS
        while ((line = reader.readLine()) != null) {
            buffer.append(line);
        }
        String payload = buffer.toString();

        try {
            // Sử dụng ObjectMapper của Jackson để duyệt cây JSON hiệu năng cao
            ObjectMapper mapper = new ObjectMapper();
            JsonNode rootNode = mapper.readTree(payload);

            // Trích xuất mã số đơn hàng từ cấu trúc dữ liệu của PayOS: { "data": { "orderCode": ... } }
            long orderCode = rootNode.path("data").path("orderCode").asLong();

            if (payload.contains("\"success\":true") || payload.contains("isSuccess")) {
                LOGGER.info("=======================================================");
                LOGGER.info("▶ CYBERCORE PAYMENT WEBHOOK NOTIFICATION");
                LOGGER.info("▶ ĐƠN HÀNG MÃ SỐ: " + orderCode + " ĐÃ TỰ ĐỘNG GIAO DỊCH THÀNH CÔNG!");
                LOGGER.info("=======================================================");

                /*
                 * 🎯 GỢI Ý TÍCH HỢP PREMIUM:
                 * Bạn có thể khởi tạo BillDAO/OrderDAO tại đây để cập nhật trạng thái hóa đơn
                 * từ "Pending" sang "Completed" hoặc "Đã thanh toán" tự động trên hệ thống DB.
                 * * BillDAO billDAO = new BillDAO();
                 * billDAO.updateStatusByOrderCode(orderCode, "Completed");
                 */
            }

            // Trả về mã HTTP 200 OK để báo cho PayOS biết hệ thống của chúng ta đã nhận xử lý xong tin nhắn
            response.setStatus(HttpServletResponse.SC_OK);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("{\"status\": \"success\"}");

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Lỗi phân tích cú pháp dữ liệu Webhook truyền từ PayOS", e);
            // Trả về mã lỗi 500 để hệ thống PayOS biết và tự động thực hiện cơ chế gửi lại (Retry mechanism) sau đó
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
        response.getWriter().println("Phương thức GET không được hỗ trợ tại API này.");
    }
}