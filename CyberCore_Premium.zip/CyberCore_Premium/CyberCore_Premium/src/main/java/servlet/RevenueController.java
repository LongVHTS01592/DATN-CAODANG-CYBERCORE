package servlet;

import dao.ReportDAO;
import entity.RevenueReport;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/admin/revenue-report")
public class RevenueController extends HttpServlet {

    private final ReportDAO reportDAO = new ReportDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT DOANH THU: Chặn đứng các truy cập trái phép từ phía Client
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        // Nếu chưa đăng nhập hoặc không phải quyền Admin/Staff (RoleID > 2), tống xuất về trang login
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Lấy dữ liệu báo cáo doanh thu theo tháng từ ReportDAO
        List<RevenueReport> list = reportDAO.getMonthlyRevenue();

        request.setAttribute("revenueList", list);
        request.getRequestDispatcher("/admin/revenue-report.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Khóa đồng bộ lớp POST để bảo vệ tuyệt đối luồng dữ liệu quản trị
        doGet(request, response);
    }
}