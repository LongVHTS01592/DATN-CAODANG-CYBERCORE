package servlet;

import dao.UserDAO;
import dao.UserAddressDAO; // Đã thêm import
import entity.User;
import entity.UserAddress; // Đã thêm import
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.List; // Đã thêm import

// Khai báo WebServlet nhận cả 2 đường dẫn
@WebServlet({"/profile", "/ProfileController"})
// Cấu hình MultipartConfig BẮT BUỘC để cho phép upload file (ảnh)
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
        maxFileSize = 1024 * 1024 * 10,       // Tối đa 10MB mỗi file
        maxRequestSize = 1024 * 1024 * 50     // Tối đa 50MB mỗi request
)
public class ProfileController extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();
    private final UserAddressDAO addressDAO = new UserAddressDAO(); // Khai báo thêm DAO địa chỉ

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User sessionUser = (User) session.getAttribute("userAccount");

        if (sessionUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // 1. Lấy thông tin user mới nhất từ CSDL
        User freshUser = userDAO.findById(sessionUser.getUserID());

        // 2. CHỐT HẠ ĐỊA CHỈ: Lấy danh sách địa chỉ và nhét thẳng vào freshUser
        List<UserAddress> myAddresses = addressDAO.findByUserId(freshUser.getUserID());
        freshUser.setAddresses(myAddresses);

        // 3. Ghi đè lại session cũ (Lúc này freshUser đã có đủ cả ảnh bìa lẫn địa chỉ)
        session.setAttribute("userAccount", freshUser);

        request.getRequestDispatcher("/views/profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");

        if (currentUser == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("update".equals(action)) {
            try {
                // 1. Lấy thông tin text (Tên, SĐT)
                String fullName = request.getParameter("fullName");
                String phone = request.getParameter("phone");

                currentUser.setFullName(fullName);
                currentUser.setPhone(phone);

                // 2. Xử lý Upload File Ảnh Bìa (Cover)
                Part filePart = request.getPart("coverFile");
                if (filePart != null && filePart.getSize() > 0) {
                    // Lấy tên file gốc
                    String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

                    // Tạo đường dẫn lưu vào thư mục 'images' của project
                    String uploadPath = getServletContext().getRealPath("") + File.separator + "images";
                    File uploadDir = new File(uploadPath);
                    if (!uploadDir.exists()) {
                        uploadDir.mkdir(); // Nếu chưa có thư mục images thì tự tạo
                    }

                    // Lưu file ảnh vào server
                    filePart.write(uploadPath + File.separator + fileName);

                    // Cập nhật đường dẫn vào Database (Lưu ý: URL dùng dấu /)
                    currentUser.setCoverUrl(request.getContextPath() + "/images/" + fileName);
                }

                // 3. Gọi DAO cập nhật CSDL
                boolean isUpdated = userDAO.update(currentUser);
                if (isUpdated) {
                    session.setAttribute("msg", "Cập nhật thông tin cá nhân và ảnh bìa thành công!");
                } else {
                    session.setAttribute("error", "Lỗi CSDL: Không thể cập nhật thông tin.");
                }

            } catch (Exception e) {
                e.printStackTrace();
                session.setAttribute("error", "Lỗi tải ảnh: " + e.getMessage());
            }

            // Chuyển hướng lại trang profile (nó sẽ gọi doGet và load lại ảnh/địa chỉ mới nhất)
            response.sendRedirect(request.getContextPath() + "/profile");
        }
    }
}