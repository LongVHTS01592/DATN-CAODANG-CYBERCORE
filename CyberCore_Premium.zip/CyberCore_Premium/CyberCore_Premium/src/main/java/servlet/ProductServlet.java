package servlet;

import dao.CategoryDAO;
import dao.ProductDAO;
import entity.Category;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/product")
public class ProductServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Đảm bảo xử lý trọn vẹn ký tự Tiếng Việt truyền lên từ thanh công cụ tìm kiếm
        request.setCharacterEncoding("UTF-8");

        // Đổ toàn bộ danh mục sản phẩm vào thanh Menu bên trái (Side-filter)
        List<Category> categories = categoryDAO.findAll();
        request.setAttribute("categories", categories);

        String keyword = request.getParameter("keyword");
        String categoryIdStr = request.getParameter("categoryId");

        List<Product> products;

        // XỬ LÝ CHIẾN LƯỢC TÌM KIẾM VÀ PHÂN LOẠI LINH HOẠT
        if (keyword != null && !keyword.trim().isEmpty()) {
            // Trường hợp 1: Người dùng tìm kiếm từ khóa theo tên linh kiện
            products = productDAO.searchByName(keyword.trim());
        } else if (categoryIdStr != null && !categoryIdStr.trim().isEmpty()) {
            // Trường hợp 2: Người dùng click chọn phân loại theo danh mục
            try {
                int categoryId = Integer.parseInt(categoryIdStr);
                products = productDAO.findByCategory(categoryId);
            } catch (NumberFormatException e) {
                // Đề phòng hacker cố tình gõ chuỗi chữ lên URL phá hoại ép kiểu -> Trả về toàn bộ kho hàng
                products = productDAO.findAll();
            }
        } else {
            // Trường hợp mặc định: Hiển thị toàn bộ hệ sinh thái linh kiện
            products = productDAO.findAll();
        }

        request.setAttribute("products", products);
        request.getRequestDispatcher("/views/product_list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // Chuyển dịch đồng bộ luồng POST về luồng GET để tái sử dụng toàn bộ bộ lọc tìm kiếm
        doGet(request, response);
    }
}