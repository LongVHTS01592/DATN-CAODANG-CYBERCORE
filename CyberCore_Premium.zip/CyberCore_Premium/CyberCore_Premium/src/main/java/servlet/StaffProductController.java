package servlet;

import dao.BrandDAO;
import dao.CategoryDAO;
import dao.ImportBillDAO;
import dao.ProductDAO;
import entity.ImportBill;
import entity.ImportBillDetail;
import entity.Product;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/StaffProductController")
public class StaffProductController extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BrandDAO brandDAO = new BrandDAO();

    // HÀM HELPER BẢO MẬT
    private boolean isNotStaff(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT GET
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        // Nhánh 1: Hiển thị danh sách tổng kèm Bộ Lọc
        if (action == null || action.isEmpty()) {
            String search = request.getParameter("search");
            String catStr = request.getParameter("category");
            String brandStr = request.getParameter("brand");

            // Chuyển đổi an toàn
            Integer catId = (catStr != null && catStr.matches("\\d+")) ? Integer.parseInt(catStr) : null;
            Integer brandId = (brandStr != null && brandStr.matches("\\d+")) ? Integer.parseInt(brandStr) : null;

            request.setAttribute("products", productDAO.searchProducts(search, catId, brandId));
            request.setAttribute("categories", categoryDAO.findAll());
            request.setAttribute("brands", brandDAO.findAll());

            // Đẩy ngược lại JSP để giữ giá trị trong ô input/select
            request.setAttribute("selectedSearch", search);
            request.setAttribute("selectedCat", catId);
            request.setAttribute("selectedBrand", brandId);

            request.getRequestDispatcher("/staff/staff_product.jsp").forward(request, response);
        }
        // Nhánh 2: Xử lý các action phụ (Thêm, Sửa, Import)
        else {
            int id = (request.getParameter("id") != null && request.getParameter("id").matches("\\d+"))
                    ? Integer.parseInt(request.getParameter("id")) : 0;

            if ("add".equals(action)) {
                request.getRequestDispatcher("/staff/staff_product_form.jsp").forward(request, response);
            }
            else if ("edit".equals(action) || "updateStock".equals(action)) {
                request.setAttribute("product", productDAO.findById(id));
                request.setAttribute("action", action);

                // TRUYỀN THÊM CÁC THAM SỐ LỌC NÀY VÀO FORM ĐỂ GIỮ TRẠNG THÁI
                request.setAttribute("filterSearch", request.getParameter("search"));
                request.setAttribute("filterCat", request.getParameter("category"));
                request.setAttribute("filterBrand", request.getParameter("brand"));

                request.getRequestDispatcher("/staff/staff_product_form.jsp").forward(request, response);
            }
            else if ("showImportForm".equals(action)) {
                request.setAttribute("products", productDAO.findAll());
                request.getRequestDispatcher("/staff/product_import.jsp").forward(request, response);
            }
            else if ("import".equals(action)) {
                request.setAttribute("products", productDAO.findAll());
                String highlightId = request.getParameter("highlightId");
                request.setAttribute("highlightId", highlightId);
                request.getRequestDispatcher("/staff/staff_product.jsp").forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN BẢO MẬT POST: Khóa hoàn toàn các truy cập trái phép cố tình gửi Data cập nhật
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        int id = (idStr != null && idStr.matches("\\d+")) ? Integer.parseInt(idStr) : 0;

        // Lấy lại các giá trị lọc cũ để "nhớ" trạng thái UI
        String search = request.getParameter("currentSearch");
        String cat = request.getParameter("currentCat");
        String brand = request.getParameter("currentBrand");

        String filterQuery = String.format("?search=%s&category=%s&brand=%s",
                (search != null ? search : ""),
                (cat != null ? cat : ""),
                (brand != null ? brand : ""));

        // Xử lý Cập nhật Thông tin
        if ("edit".equals(action)) {
            Product p = productDAO.findById(id);
            if(p != null) {
                p.setProductName(request.getParameter("productName"));
                p.setSellPrice(new BigDecimal(request.getParameter("sellPrice")));
                p.setWarrantyMonths(Integer.parseInt(request.getParameter("warrantyMonths")));
                productDAO.update(p);
            }
        }
        // Xử lý Cập nhật nhanh Tồn kho
        else if ("updateStock".equals(action)) {
            Product p = productDAO.findById(id);
            if(p != null) {
                int newStock = Integer.parseInt(request.getParameter("stockQuantity"));
                p.setStockQuantity(newStock);
                p.setStatus(newStock > 0 ? 1 : 2); // Tự động đổi trạng thái: Hết hàng/Còn hàng
                productDAO.update(p);
            }
        }
        // Xử lý Lập phiếu Nhập hàng mới
        else if ("saveImport".equals(action)) {
            String supplier = request.getParameter("supplierName");
            int productId = Integer.parseInt(request.getParameter("productID"));
            int qty = Integer.parseInt(request.getParameter("quantity"));
            BigDecimal price = new BigDecimal(request.getParameter("importPrice"));

            // Đã kiểm tra isNotStaff ở trên, user chắc chắn tồn tại
            User user = (User) request.getSession().getAttribute("userAccount");
            int userId = user.getUserID();

            ImportBill bill = new ImportBill();
            bill.setSupplierName(supplier);
            bill.setUserID(userId);
            bill.setTotalImportAmount(price.multiply(new BigDecimal(qty)));

            ImportBillDetail detail = new ImportBillDetail();
            detail.setProductID(productId);
            detail.setQuantity(qty);
            detail.setImportPrice(price);
            List<ImportBillDetail> details = List.of(detail);

            ImportBillDAO importBillDAO = new ImportBillDAO();
            boolean success = importBillDAO.addImportBill(bill, details);

            if (success) {
                response.sendRedirect(request.getContextPath() + "/StaffProductController?msg=success");
            } else {
                response.sendRedirect(request.getContextPath() + "/StaffProductController?msg=error");
            }
            return;
        }

        // Redirect về trang danh sách kèm bộ lọc trước đó
        response.sendRedirect(request.getContextPath() + "/StaffProductController" + filterQuery);
    }
}