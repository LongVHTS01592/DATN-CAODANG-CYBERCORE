package servlet;

import dao.ProductDAO;
import dao.CategoryDAO;
import dao.ProductImageDAO;
import dao.SystemLogDAO;
import entity.Product;
import entity.Category;
import entity.ProductImage;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/ProductAdminController")
public class ProductAdminController extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final ProductImageDAO productImageDAO = new ProductImageDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT GET: Chỉ cho phép Admin/Staff truy cập giao diện quản trị
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                int pId = Integer.parseInt(idStr);

                // Triệt tiêu lỗi Foreign Key bằng cách giải phóng loạt ảnh phụ trước
                productImageDAO.deleteByProductId(pId);
                productDAO.delete(pId);

                // Ghi nhận nhật ký xóa dữ liệu nghiêm trọng
                SystemLogDAO logDAO = new SystemLogDAO();
                logDAO.insertLog(user.getUserID(), "ERROR", "CẢNH BÁO: Admin đã xóa vĩnh viễn linh kiện ID #" + idStr);
            }
            response.sendRedirect(request.getContextPath() + "/ProductAdminController");
            return;
        } else if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                int pId = Integer.parseInt(idStr);
                Product p = productDAO.findById(pId);
                if (p != null) {
                    // Nạp bộ sưu tập ảnh phụ để hiển thị lên Form chỉnh sửa
                    p.setImages(productImageDAO.findByProductId(pId));
                }
                request.setAttribute("productEdit", p);
            }
        }

        // Nạp danh sách toàn bộ sản phẩm kèm bộ ảnh phụ tương ứng ra bảng quản trị
        List<Product> products = productDAO.findAll();
        for (Product p : products) {
            p.setImages(productImageDAO.findByProductId(p.getProductID()));
        }
        request.setAttribute("products", products);

        List<Category> categories = categoryDAO.findAll();
        request.setAttribute("categories", categories);

        request.getRequestDispatcher("/admin/admin_product.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // VÁ LỖ HỔNG BẢO MẬT: Khóa xích tầng POST, chặn đứng các cuộc tấn công giả mạo gói tin sửa đổi kho hàng
        HttpSession session = request.getSession();
        User admin = (User) session.getAttribute("userAccount");
        if (admin == null || admin.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String idStr = request.getParameter("id");
        String name = request.getParameter("productName");
        String categoryIdStr = request.getParameter("categoryID");
        String brandIdStr = request.getParameter("brandID");
        String originalPriceStr = request.getParameter("originalPrice");
        String sellPriceStr = request.getParameter("sellPrice");
        String imgUrl = request.getParameter("mainImageURL");
        String warrantyStr = request.getParameter("warrantyMonths");
        String statusStr = request.getParameter("status");
        String desc = request.getParameter("description");
        String subImageURLs = request.getParameter("subImageURLs");
        String stockQuantityStr = request.getParameter("stockQuantity");

        Integer adminId = admin.getUserID();
        SystemLogDAO logDAO = new SystemLogDAO();

        // Cấu hình đường dẫn lưu trữ (Vui lòng điều chỉnh pathVoiGoc phù hợp với môi trường deployment của bạn)
        String pathVoiGoc = "C:\\Users\\mbui2\\Downloads\\CyberCore\\CyberCore\\src\\main\\webapp\\images";
        String pathTomcat = getServletContext().getRealPath("/images");

        // 1. Tải và xử lý làm sạch ảnh đại diện chính
        String finalMainImage = downloadAndCleanImage(imgUrl, pathVoiGoc, pathTomcat);

        // 2. Bóc tách và xử lý tải hàng loạt ảnh phụ dạng danh sách cách nhau bởi dấu phẩy
        List<String> finalSubImages = new ArrayList<>();
        if (subImageURLs != null && !subImageURLs.trim().isEmpty()) {
            String[] urls = subImageURLs.split(",");
            for (String urlItem : urls) {
                String cleanUrlItem = urlItem.trim();
                if (!cleanUrlItem.isEmpty()) {
                    finalSubImages.add(downloadAndCleanImage(cleanUrlItem, pathVoiGoc, pathTomcat));
                }
            }
        }

        // Đóng gói dữ liệu vào thực thể Product
        Product p = new Product();
        p.setProductName(name);
        p.setCategoryID(Integer.parseInt(categoryIdStr != null && !categoryIdStr.isEmpty() ? categoryIdStr : "1"));
        p.setBrandID(Integer.parseInt(brandIdStr != null && !brandIdStr.isEmpty() ? brandIdStr : "1"));
        p.setOriginalPrice(new BigDecimal(originalPriceStr != null && !originalPriceStr.isEmpty() ? originalPriceStr : "0"));
        p.setSellPrice(new BigDecimal(sellPriceStr != null && !sellPriceStr.isEmpty() ? sellPriceStr : "0"));
        p.setMainImageURL(finalMainImage);
        p.setWarrantyMonths(Integer.parseInt(warrantyStr != null && !warrantyStr.isEmpty() ? warrantyStr : "12"));
        p.setDescriptionText(desc);
        p.setStatus(Integer.parseInt(statusStr != null && !statusStr.isEmpty() ? statusStr : "1"));
        p.setStockQuantity(Integer.parseInt(stockQuantityStr != null && !stockQuantityStr.isEmpty() ? stockQuantityStr : "0"));

        if ("insert".equals(action)) {
            // Thêm mới linh kiện và bắt lấy ID tự tăng vừa sinh ra trong cơ sở dữ liệu
            int newProductId = productDAO.insertAndGetId(p);
            if (newProductId > 0) {
                int order = 1;
                for (String subImgName : finalSubImages) {
                    productImageDAO.insert(new ProductImage(0, newProductId, subImgName, order++));
                }
            }
            logDAO.insertLog(adminId, "INFO", "Admin đã thêm linh kiện mới: " + name + " (Số lượng kho: " + stockQuantityStr + ")");

        } else if ("update".equals(action)) {
            if (idStr != null) {
                int pId = Integer.parseInt(idStr);
                p.setProductID(pId);
                productDAO.update(p);

                // Đồng bộ hóa bộ sưu tập ảnh phụ: Xóa toàn bộ ảnh phụ cũ và nạp lại loạt ảnh mới tinh
                productImageDAO.deleteByProductId(pId);
                int order = 1;
                for (String subImgName : finalSubImages) {
                    productImageDAO.insert(new ProductImage(0, pId, subImgName, order++));
                }

                logDAO.insertLog(adminId, "WARN", "Admin đã cập nhật ID #" + idStr + ": " + name + " (Giá mới: " + sellPriceStr + " VNĐ - Kho: " + stockQuantityStr + ")");
            }
        }

        response.sendRedirect(request.getContextPath() + "/ProductAdminController");
    }

    /**
     * HELPER METHOD: Tải ảnh từ URL từ xa, bypass rào cản chống crawl (403), dọn sạch ký tự Windows lỗi.
     */
    private String downloadAndCleanImage(String imgUrl, String pathVoiGoc, String pathTomcat) {
        if (imgUrl == null || (!imgUrl.startsWith("http://") && !imgUrl.startsWith("https://"))) {
            return imgUrl;
        }
        InputStream in = null;
        try {
            String cleanUrl = imgUrl;
            if (cleanUrl.contains("?")) {
                cleanUrl = cleanUrl.substring(0, cleanUrl.indexOf("?"));
            }
            String fileNameFromUrl = cleanUrl.substring(cleanUrl.lastIndexOf("/") + 1);
            // Chuẩn hóa tên file, thay thế các ký tự cấm của Windows thành dấu gạch dưới
            fileNameFromUrl = fileNameFromUrl.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (fileNameFromUrl.trim().isEmpty() || !fileNameFromUrl.contains(".")) {
                fileNameFromUrl = "downloaded_image.jpg";
            }
            String finalImageName = System.currentTimeMillis() + "_" + fileNameFromUrl;

            java.net.HttpURLConnection connection = (java.net.HttpURLConnection) new URL(imgUrl).openConnection();
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            connection.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8");
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(6000);

            if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300) {
                in = connection.getInputStream();
                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = in.read(buffer)) != -1) {
                    baos.write(buffer, 0, bytesRead);
                }
                byte[] imageBytes = baos.toByteArray();

                // Lưu ảnh xuống thư mục mã nguồn gốc
                File dirGoc = new File(pathVoiGoc);
                if (!dirGoc.exists()) dirGoc.mkdirs();
                try (java.io.FileOutputStream fosGoc = new java.io.FileOutputStream(new File(dirGoc, finalImageName))) {
                    fosGoc.write(imageBytes);
                }

                // Lưu ảnh song song xuống thư mục tạm của Server Tomcat phục vụ hiển thị realtime
                File dirTomcat = new File(pathTomcat);
                if (!dirTomcat.exists()) dirTomcat.mkdirs();
                try (java.io.FileOutputStream fosTomcat = new java.io.FileOutputStream(new File(dirTomcat, finalImageName))) {
                    fosTomcat.write(imageBytes);
                }
                return finalImageName;
            }
        } catch (Exception e) {
            System.err.println("==> Lỗi trong quá trình tải và xử lý ảnh từ luồng mạng: " + e.getMessage());
        } finally {
            if (in != null) {
                try { in.close(); } catch (Exception ignored) {}
            }
        }
        return imgUrl;
    }
}