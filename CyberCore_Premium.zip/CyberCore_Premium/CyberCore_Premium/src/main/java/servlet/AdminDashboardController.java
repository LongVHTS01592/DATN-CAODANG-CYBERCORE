package servlet;

import dao.BillDAO;
import dao.ReportDAO;
import entity.Bill;
import entity.User;
import entity.RevenueReport;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@WebServlet("/admin/dashboard")
public class AdminDashboardController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final ReportDAO reportDAO = new ReportDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Chỉ Admin/Owner (1) hoặc Staff (2) mới được phép truy cập trang này
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // --- LẤY CÁC CHỈ SỐ THỐNG KÊ KINH DOANH ---
        BigDecimal totalRevenue = billDAO.getTotalRevenue();
        int pendingOrders = billDAO.countPendingOrders();
        List<Bill> recentOrders = billDAO.getRecentOrders(5);

        // --- LẤY CÁC CHỈ SỐ THỐNG KÊ NÂNG CAO (PROJECT 3) ---
        Map<String, Object> stats = reportDAO.getDashboardStats(); // 4 thẻ: Tổng SP, Tổng User...
        List<RevenueReport> revenueList = reportDAO.getMonthlyRevenue(); // Doanh thu theo tháng làm biểu đồ Chart.js

        // --- ĐẨY DỮ LIỆU SANG GIAO DIỆN JSP ---
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("newOrdersCount", pendingOrders);
        request.setAttribute("recentOrders", recentOrders);
        request.setAttribute("stats", stats);
        request.setAttribute("revenueList", revenueList);

        // Forward dữ liệu đến trang giao diện admin tổng thể
        request.getRequestDispatcher("/admin/admin_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}