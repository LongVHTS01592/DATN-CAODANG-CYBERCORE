package servlet;

import dao.BillDAO;
import dao.BillDetailDAO;
import dao.ProductDAO;
import entity.BillDetail;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/update-order-status")
public class UpdateOrderStatusServlet extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final BillDetailDAO billDetailDAO = new BillDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();

    // HÀM HELPER BẢO MẬT
    private boolean isNotStaff(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() > 2;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Ngăn khách hàng hoặc kẻ gian tự ý hoàn thành đơn
        if (isNotStaff(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            int billId = Integer.parseInt(request.getParameter("billId"));
            String newStatus = request.getParameter("status");

            if ("Completed".equals(newStatus)) {
                // 1. Cập nhật trạng thái đơn hàng (ĐỒNG BỘ: Dùng "Completed" thay vì "Đã hoàn thành" để không gãy bộ lọc)
                billDAO.updateStatus(billId, "Completed");

                // 2. TRỪ TỒN KHO THỰC TẾ TRONG HỆ THỐNG
                List<BillDetail> details = billDetailDAO.findByBillId(billId);
                if (details != null) {
                    for (BillDetail bd : details) {
                        productDAO.decreaseStock(bd.getProductID(), bd.getQuantity());
                    }
                }
            }

            // Redirect về đúng tab trên màn hình quản lý
            response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Shipping");

        } catch (NumberFormatException e) {
            // Xử lý an toàn nếu billId bị truyền sai định dạng trên URL
            System.err.println("Lỗi parse billId: " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/StaffBillController?status=Shipping&error=InvalidBillId");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}