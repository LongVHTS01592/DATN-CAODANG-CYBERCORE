package servlet;

import dao.ProductDAO;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet({"/home", "/index"})
public class HomeServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // Lấy danh sách 4 sản phẩm công nghệ mới nhất để hiển thị tại banner trang chủ
        List<Product> newProducts = productDAO.getNewestProducts(4);
        request.setAttribute("newProducts", newProducts);

        // Đẩy toàn bộ dữ liệu ra trang chủ index.jsp
        request.getRequestDispatcher("/views/index.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // Chuyển tiếp luồng POST về luồng GET để xử lý đồng bộ dữ liệu, tránh trang trống
        doGet(request, response);
    }
}