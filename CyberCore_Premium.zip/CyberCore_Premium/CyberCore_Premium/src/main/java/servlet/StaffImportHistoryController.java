package servlet;

import dao.ImportHistoryDAO;
import entity.ImportHistory;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/StaffImportHistoryController")
public class StaffImportHistoryController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Phân quyền truy cập nội bộ
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        if (currentUser == null || currentUser.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // 1. Lấy tham số từ form tìm kiếm
        String productName = request.getParameter("productName");
        String supplier = request.getParameter("supplier");
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");

        ImportHistoryDAO dao = new ImportHistoryDAO();
        List<ImportHistory> list;

        // 2. Kiểm tra nếu có bất kỳ tham số lọc nào thì gọi hàm filter, không thì lấy tất cả
        if ((productName != null && !productName.isEmpty()) ||
                (supplier != null && !supplier.isEmpty()) ||
                (fromDate != null && !fromDate.isEmpty()) ||
                (toDate != null && !toDate.isEmpty())) {
            list = dao.getFilteredImportHistory(productName, supplier, fromDate, toDate);
        } else {
            list = dao.getAllImportHistory();
        }

        // 3. Gửi danh sách đã lọc (hoặc toàn bộ) sang JSP
        request.setAttribute("importHistory", list);

        // 4. Giữ lại các giá trị đã lọc trên thanh tìm kiếm để người dùng thấy họ đang lọc gì
        request.setAttribute("paramProductName", productName);
        request.setAttribute("paramSupplier", supplier);
        request.setAttribute("paramFromDate", fromDate);
        request.setAttribute("paramToDate", toDate);

        request.getRequestDispatcher("/staff/import_history.jsp").forward(request, response);
    }
}