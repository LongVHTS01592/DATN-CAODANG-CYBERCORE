package servlet;

import dao.CartDAO;
import dao.CartDetailDAO;
import dao.ProductDAO;
import dao.VoucherDAO;
import entity.Cart;
import entity.CartDetail;
import entity.Product;
import entity.User;
import entity.Voucher;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    private final CartDAO cartDAO = new CartDAO();
    private final CartDetailDAO cartDetailDAO = new CartDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final VoucherDAO voucherDAO = new VoucherDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Đảm bảo người dùng luôn có giỏ hàng trong cơ sở dữ liệu
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }

        List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
        double totalPrice = 0;

        // Điền thông tin thực tế của sản phẩm vào chi tiết giỏ hàng và tính tổng tiền tạm tính
        for (CartDetail cd : details) {
            Product p = productDAO.findById(cd.getProductID());
            cd.setProduct(p);
            if (p != null && p.getSellPrice() != null) {
                totalPrice += p.getSellPrice().doubleValue() * cd.getQuantity();
            }
        }

        // BẢO VỆ CHỐNG EXPLOIT VOUCHER: Tự động tính toán hoặc hủy mã nếu người dùng cố tình thay đổi giỏ hàng ở tab khác
        String currentVoucherCode = (String) session.getAttribute("voucherCode");
        if (currentVoucherCode != null) {
            Voucher voucher = voucherDAO.findByCode(currentVoucherCode);

            if (voucher == null || BigDecimal.valueOf(totalPrice).compareTo(voucher.getMinOrderValue()) < 0) {
                session.removeAttribute("discountAmount");
                session.removeAttribute("voucherCode");
            } else {
                double discount = 0;
                if ("PERCENT".equals(voucher.getDiscountType())) {
                    discount = totalPrice * voucher.getDiscountValue().doubleValue() / 100;
                    if (voucher.getMaxDiscountAmount() != null) {
                        discount = Math.min(discount, voucher.getMaxDiscountAmount().doubleValue());
                    }
                } else {
                    discount = voucher.getDiscountValue().doubleValue();
                }

                if (discount > totalPrice) {
                    discount = totalPrice;
                }
                session.setAttribute("discountAmount", discount);
            }
        }

        // Đồng bộ dữ liệu hiển thị sang Request Attributes để đẩy ra trang JSP
        request.setAttribute("discountAmount", session.getAttribute("discountAmount"));
        request.setAttribute("voucherCode", session.getAttribute("voucherCode"));
        request.setAttribute("voucherMessage", session.getAttribute("voucherMessage"));

        // Cơ chế Flash Scope thủ công: Xóa thông báo ngay sau khi nạp để tránh hiện tượng F5 bị lặp lại thông báo cũ
        session.removeAttribute("voucherMessage");

        request.setAttribute("totalPrice", totalPrice);
        request.setAttribute("cartDetails", details);
        request.getRequestDispatcher("/views/cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }

        // Xử lý các hành động tác động đến kết cấu giỏ hàng
        if ("add".equals(action)) {
            // Reset voucher vì giá trị tổng đơn hàng đã thay đổi
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            CartDetail existing = cartDetailDAO.findProductInCart(cart.getCartID(), productId);
            if (existing != null) {
                cartDetailDAO.updateQuantity(existing.getCartDetailID(), existing.getQuantity() + quantity);
            } else {
                cartDetailDAO.addToCart(cart.getCartID(), productId, quantity);
            }
            session.setAttribute("voucherMessage", "Đã thêm sản phẩm vào giỏ hàng!");

        } else if ("update".equals(action)) {
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            cartDetailDAO.updateQuantity(cartDetailId, quantity);
            session.setAttribute("voucherMessage", "Đã cập nhật số lượng thành công!");

        } else if ("remove".equals(action)) {
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            cartDetailDAO.removeItem(cartDetailId);
            session.setAttribute("voucherMessage", "Đã xóa sản phẩm khỏi giỏ hàng!");

        } else if ("applyVoucher".equals(action)) {
            String code = request.getParameter("voucherCode");
            Voucher voucher = voucherDAO.findByCode(code);

            if (voucher == null) {
                session.removeAttribute("discountAmount");
                session.removeAttribute("voucherCode");
                session.setAttribute("voucherMessage", "Mã giảm giá không tồn tại hoặc đã hết hạn!");
            } else {
                double totalAmount = 0;
                List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());

                for (CartDetail item : details) {
                    Product p = productDAO.findById(item.getProductID());
                    if (p != null && p.getSellPrice() != null) {
                        totalAmount += p.getSellPrice().doubleValue() * item.getQuantity();
                    }
                }

                // Kiểm tra điều kiện áp dụng tối thiểu của mã giảm giá
                if (BigDecimal.valueOf(totalAmount).compareTo(voucher.getMinOrderValue()) < 0) {
                    session.removeAttribute("discountAmount");
                    session.removeAttribute("voucherCode");
                    session.setAttribute("voucherMessage", "Đơn hàng của bạn chưa đạt giá trị tối thiểu để áp dụng mã này!");
                } else {
                    double discount = 0;

                    if ("PERCENT".equals(voucher.getDiscountType())) {
                        discount = totalAmount * voucher.getDiscountValue().doubleValue() / 100;
                        if (voucher.getMaxDiscountAmount() != null) {
                            discount = Math.min(discount, voucher.getMaxDiscountAmount().doubleValue());
                        }
                    } else {
                        discount = voucher.getDiscountValue().doubleValue();
                    }

                    if (discount > totalAmount) {
                        discount = totalAmount;
                    }

                    session.setAttribute("discountAmount", discount);
                    session.setAttribute("voucherCode", voucher.getVoucherCode());
                    session.setAttribute("voucherMessage", "Áp dụng mã giảm giá thành công!");
                }
            }
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }
}