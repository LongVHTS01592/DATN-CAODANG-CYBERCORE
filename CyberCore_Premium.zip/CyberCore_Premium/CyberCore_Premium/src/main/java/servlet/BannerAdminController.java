package servlet;

import dao.BannerDAO;
import entity.Banner;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

@WebServlet("/BannerAdminController")
public class BannerAdminController extends HttpServlet {

    private final BannerDAO bannerDAO = new BannerDAO();

    // HÀM HELPER BẢO MẬT: Đã là Admin Controller thì chỉ Admin (RoleID = 1) mới được can thiệp
    private boolean isUnauthorized(HttpServletRequest request) {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        return currentUser == null || currentUser.getRoleID() != 1;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN GET
        if (isUnauthorized(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null && idStr.matches("\\d+")) {
                bannerDAO.delete(Integer.parseInt(idStr));
            }
            response.sendRedirect(request.getContextPath() + "/BannerAdminController");
            return;

        } else if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null && idStr.matches("\\d+")) {
                Banner b = bannerDAO.findById(Integer.parseInt(idStr));
                if (b != null) {
                    request.setAttribute("bannerEdit", b);
                    // Chuyển đổi định dạng ngày cho thẻ <input type="datetime-local">
                    if (b.getStartDate() != null) {
                        request.setAttribute("startDateStr", b.getStartDate().toString().replace(" ", "T").substring(0, 16));
                    }
                    if (b.getEndDate() != null) {
                        request.setAttribute("endDateStr", b.getEndDate().toString().replace(" ", "T").substring(0, 16));
                    }
                }
            }
        }

        List<Banner> listBanners = bannerDAO.findAll();
        request.setAttribute("listBanners", listBanners);
        request.getRequestDispatcher("/admin/admin_banner.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN POST CỰC KỲ QUAN TRỌNG: Chống chèn banner giả mạo
        if (isUnauthorized(request)) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String title = request.getParameter("title");
        String imageURL = request.getParameter("imageURL");
        String position = request.getParameter("position");
        String targetLink = request.getParameter("targetLink");
        String startDateStr = request.getParameter("startDate");
        String endDateStr = request.getParameter("endDate");
        String isActiveStr = request.getParameter("isActive");

        Banner b = new Banner();
        b.setTitle(title);
        // Thiết lập ảnh mặc định an toàn nếu Admin bỏ trống
        b.setImageURL(imageURL != null && !imageURL.trim().isEmpty() ? imageURL : "default_banner.jpg");
        b.setPosition(position);
        b.setTargetLink(targetLink);

        // Xử lý an toàn Timestamp
        try {
            if (startDateStr != null && !startDateStr.isEmpty()) {
                b.setStartDate(Timestamp.valueOf(startDateStr.replace("T", " ") + ":00"));
            }
            if (endDateStr != null && !endDateStr.isEmpty()) {
                b.setEndDate(Timestamp.valueOf(endDateStr.replace("T", " ") + ":00"));
            }
        } catch (IllegalArgumentException e) {
            System.err.println("Lỗi định dạng ngày giờ Banner: " + e.getMessage());
        }

        b.setActive("1".equals(isActiveStr));

        if ("insert".equals(action)) {
            bannerDAO.insert(b);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null && idStr.matches("\\d+")) {
                b.setBannerID(Integer.parseInt(idStr));
                bannerDAO.update(b);
            }
        }

        response.sendRedirect(request.getContextPath() + "/BannerAdminController");
    }
}