package servlet;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/UserController")
public class UserController extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN GET: Kiểm tra quyền Admin/Staff
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        if (currentUser == null || currentUser.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        // Bật/Tắt trạng thái hoạt động của tài khoản (Khóa mõm/Mở khóa)
        if ("toggle".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                User u = userDAO.findById(Integer.parseInt(idStr));
                // Chống tự sát: Không cho phép Admin tự khóa chính tài khoản của mình
                if (u != null && u.getUserID() != currentUser.getUserID()) {
                    u.setActive(!u.isActive());
                    userDAO.update(u);
                }
            }
            response.sendRedirect(request.getContextPath() + "/UserController");
            return;
        }

        List<User> users = userDAO.findAll();
        request.setAttribute("users", users);
        request.getRequestDispatcher("/admin/admin_user.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8"); // Xử lý font tiếng Việt

        // CHỐT CHẶN POST: Khóa luồng gửi Form trái phép
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        if (currentUser == null || currentUser.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        // KHÔI PHỤC TỪ BẢN 1: TẠO TÀI KHOẢN MỚI
        if ("createStaff".equals(action)) {
            int requestedRoleID = Integer.parseInt(request.getParameter("roleID"));

            // BẢO MẬT: Nếu muốn tạo Owner (1), thì người đang thao tác phải là Owner (1).
            // Nhân viên (2) không được phép tạo Owner.
            if (requestedRoleID == 1 && currentUser.getRoleID() != 1) {
                requestedRoleID = 2; // Cưỡng ép về Role Staff nếu cố tình vượt rào
            }

            User u = new User();
            u.setUsername(request.getParameter("username"));
            u.setPasswordHash(request.getParameter("password")); // Tương lai có thể cấy thêm mã hóa BCrypt/MD5 tại đây
            u.setFullName(request.getParameter("fullName"));
            u.setEmail(request.getParameter("email"));
            u.setPhone(request.getParameter("phone"));
            u.setRoleID(requestedRoleID);
            u.setActive(true); // Tài khoản nội bộ mới tạo mặc định kích hoạt sẵn

            userDAO.insert(u);
            response.sendRedirect(request.getContextPath() + "/UserController");
            return;
        }

        // KHÔI PHỤC TỪ BẢN 1: CẤP QUYỀN LẠI CHO USER ĐÃ CÓ (Phân quyền động)
        if ("updateRole".equals(action)) {
            int userId = Integer.parseInt(request.getParameter("userID"));
            int roleId = Integer.parseInt(request.getParameter("roleID"));

            // BẢO MẬT: Chỉ Owner mới được quyền phong tước Owner cho người khác
            if (roleId == 1 && currentUser.getRoleID() != 1) {
                response.sendRedirect(request.getContextPath() + "/UserController?error=nopermission");
                return;
            }

            User u = userDAO.findById(userId);
            if (u != null) {
                u.setRoleID(roleId);
                userDAO.update(u);
            }
            response.sendRedirect(request.getContextPath() + "/UserController");
            return;
        }

        doGet(request, response);
    }
}