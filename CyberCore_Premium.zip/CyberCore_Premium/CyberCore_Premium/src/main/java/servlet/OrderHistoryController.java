package servlet;

import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/order-history")
public class OrderHistoryController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT PREMIUM: Kiểm tra trạng thái đăng nhập của khách hàng
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        // Nếu chưa đăng nhập thì đá về trang login để bảo vệ thông tin cá nhân
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Đã đăng nhập hợp lệ -> Cho phép xem danh sách lịch sử đơn hàng
        request.getRequestDispatcher("/views/order_history.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}