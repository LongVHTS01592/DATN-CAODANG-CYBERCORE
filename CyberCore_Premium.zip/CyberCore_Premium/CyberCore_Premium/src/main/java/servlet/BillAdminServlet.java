package servlet;

import dao.BillDAO;
import entity.Bill;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/BillAdminController")
public class BillAdminServlet extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT TẦNG GET: Chỉ cho phép Chủ cửa hàng (1) hoặc Nhân viên (2) vào xem
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // TỐI ƯU HIỆU NĂNG: Lấy toàn bộ danh sách đơn hàng kèm chi tiết sản phẩm qua 1 câu JOIN duy nhất
        List<Bill> listBills = billDAO.getAllBillsWithDetails();

        request.setAttribute("bills", listBills);
        request.getRequestDispatcher("/admin/admin_bill.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // CHỐT CHẶN BẢO MẬT TẦNG POST: Chống tấn công giả mạo gói tin để thay đổi trạng thái đơn hàng trái phép
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            int billId = Integer.parseInt(request.getParameter("billId"));
            String orderStatus = request.getParameter("orderStatus");

            // Cập nhật trạng thái chu kỳ đơn hàng (Pending -> Processing -> Completed -> Cancelled)
            billDAO.updateStatus(billId, orderStatus);

            // Chuyển hướng kèm theo token thông báo thành công để giao diện hiển thị Toast/Alert thông minh
            response.sendRedirect(request.getContextPath() + "/BillAdminController?msg=update_success");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/BillAdminController?error=true");
        }
    }
}