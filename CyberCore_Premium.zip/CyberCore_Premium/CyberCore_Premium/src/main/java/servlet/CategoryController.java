package servlet;

import dao.CategoryDAO;
import entity.Category;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/CategoryController")
public class CategoryController extends HttpServlet {

    private final CategoryDAO categoryDAO = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Chỉ có Admin/Owner (1) hoặc Staff (2) mới có quyền thao tác danh mục
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                Category cat = categoryDAO.findById(Integer.parseInt(idStr));
                request.setAttribute("categoryEdit", cat);
            }
        } else if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                categoryDAO.delete(Integer.parseInt(idStr));
                response.sendRedirect(request.getContextPath() + "/CategoryController");
                return;
            }
        }

        // Luôn làm tươi danh sách hiển thị trên giao diện quản trị
        List<Category> listCategories = categoryDAO.findAll();
        request.setAttribute("listCategories", listCategories);
        request.getRequestDispatcher("/admin/admin_category.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // VÁ LỖ HỔNG BẢO MẬT: Bắt buộc kiểm tra quyền ở cả tầng POST để chống tấn công giả mạo gói tin
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        String name = request.getParameter("name");
        String parentIdStr = request.getParameter("parentId");
        String slug = request.getParameter("slug");

        Category c = new Category();
        c.setCategoryName(name);
        c.setSlug(slug);

        if (parentIdStr != null && !parentIdStr.trim().isEmpty()) {
            c.setParentCategoryID(Integer.parseInt(parentIdStr));
        }

        if ("insert".equals(action)) {
            categoryDAO.insert(c);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.trim().isEmpty()) {
                c.setCategoryID(Integer.parseInt(idStr));
                categoryDAO.update(c);
            }
        }

        response.sendRedirect(request.getContextPath() + "/CategoryController");
    }
}