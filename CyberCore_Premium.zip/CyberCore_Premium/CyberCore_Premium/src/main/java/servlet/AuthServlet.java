package servlet;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet({"/login", "/register", "/LogoutController"})
public class AuthServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/login".equals(path)) {
            String action = request.getParameter("action");
            if ("logout".equals(action)) {
                request.getSession().invalidate();
                response.sendRedirect(request.getContextPath() + "/home");
            } else {
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }
        } else if ("/register".equals(path)) {
            request.getRequestDispatcher("/views/register.jsp").forward(request, response);
        } else if ("/LogoutController".equals(path)) {
            request.getSession().invalidate();
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ép kiểu bảng mã UTF-8 để không bị lỗi tiếng Việt khi đăng ký FullName
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        if ("/login".equals(path)) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            User user = userDAO.login(username, password);

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("userAccount", user);

                // PHÂN CHIA ĐƯỜNG ĐI CHUẨN XÁC THEO VAI TRÒ (ROLE)
                if (user.getRoleID() == 1) {
                    // Nếu là Owner (1) -> Vào dashboard tối cao của Admin hệ thống
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                } else if (user.getRoleID() == 2) {
                    // Nếu là Staff (2) -> Vào thẳng trang Dashboard quản lý của nhân viên
                    response.sendRedirect(request.getContextPath() + "/staff/dashboard");
                } else {
                    // Còn lại là Khách hàng (3) -> Về trang chủ mua sắm công nghệ
                    response.sendRedirect(request.getContextPath() + "/home");
                }
            } else {
                // SỬA BUG: Trả về thông báo lỗi trực quan cho người dùng nếu sai tài khoản/mật khẩu
                request.setAttribute("error", "Sai Email/Username hoặc mật khẩu!");
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }

        } else if ("/register".equals(path)) {
            String username = request.getParameter("username");
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");

            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPasswordHash(password); // Ở tầng Service/DAO sẽ tự mã hóa nếu cần
            newUser.setFullName(fullname);
            newUser.setEmail(email);
            newUser.setPhone(phone);
            newUser.setRoleID(3); // Mặc định tự đăng ký luôn là Khách hàng
            newUser.setActive(true);

            if (userDAO.insert(newUser)) {
                response.sendRedirect(request.getContextPath() + "/login");
            } else {
                request.setAttribute("error", "Đăng ký thất bại! Tài khoản, Email hoặc SĐT đã tồn tại trên hệ thống.");
                request.getRequestDispatcher("/views/register.jsp").forward(request, response);
            }
        }
    }
}