package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import util.MailUtil;

import java.io.IOException;

@WebServlet("/ContactServlet")
public class ContactServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // CỰC KỲ QUAN TRỌNG: Tránh lỗi font tiếng Việt khi nhận dữ liệu từ Form
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        // Kiểm tra dữ liệu đầu vào cơ bản
        if (name == null || email == null || message == null || name.trim().isEmpty() || email.trim().isEmpty()) {
            request.setAttribute("msg", "Vui lòng điền đầy đủ thông tin!");
            request.getRequestDispatcher("/views/lienhe.jsp").forward(request, response);
            return;
        }

        String subject = "Liên hệ từ website - Khách hàng: " + name;
        String content = "Họ tên: " + name + "\n\n"
                + "Email: " + email + "\n\n"
                + "Nội dung:\n" + message;

        try {
            // Thay bằng email thật của bạn hoặc cấu hình linh hoạt
            MailUtil.sendMail("cybercore.support@gmail.com", subject, content);
            request.setAttribute("msg", "Gửi thành công! Chúng tôi sẽ phản hồi bạn sớm nhất.");
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("msg", "Gửi thất bại! Hệ thống mail đang bảo trì.");
        }

        request.getRequestDispatcher("/views/lienhe.jsp").forward(request, response);
    }
}