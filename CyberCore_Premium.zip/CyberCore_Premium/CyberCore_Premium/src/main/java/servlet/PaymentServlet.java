package servlet;

import dao.ProductDAO;
import entity.CartDetail;
import entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet(name = "PaymentServlet", value = "/checkout-payment")
public class PaymentServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(PaymentServlet.class.getName());
    private final ProductDAO productDAO = new ProductDAO();

    // Thông tin định danh cấu hình PayOS Merchant
    private final String CLIENT_ID = "abaf8b27-e255-4ac7-be13-83724cd7eed8";
    private final String API_KEY = "ac71291d-5d9c-4393-948f-b71a2312f0da";
    private final String CHECKSUM_KEY = "2d3bdfd022ca4a301d7867a76bb8ea288bb3c78efbe4e40a0c405063399a466a";

    // Hàm tiện ích chuẩn hóa chuỗi tiền tệ và ép kiểu an toàn
    private int parseAmountString(String amountStr) {
        try {
            String cleanStr = amountStr.replaceAll("[^\\d.]", "");
            if (cleanStr.contains(".")) {
                cleanStr = cleanStr.substring(0, cleanStr.indexOf("."));
            }
            return Integer.parseInt(cleanStr);
        } catch (NumberFormatException e) {
            return 2000; // Số tiền demo tối thiểu mặc định của PayOS
        }
    }

    // Cơ chế mã hóa chữ ký số HMAC-SHA256 bảo mật dòng dữ liệu truyền lên PayOS
    private String hmacSha256(String data, String key) throws NoSuchAlgorithmException, InvalidKeyException {
        byte[] byteKey = key.getBytes(StandardCharsets.UTF_8);
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secret_key = new SecretKeySpec(byteKey, "HmacSHA256");
        sha256_HMAC.init(secret_key);
        byte[] mac_data = sha256_HMAC.doFinal(data.getBytes(StandardCharsets.UTF_8));
        StringBuilder result = new StringBuilder();
        for (byte b : mac_data) {
            result.append(String.format("%02x", b));
        }
        return result.toString();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        // CHỐT CHẶN BẢO VỆ KHO REALTIME: Chống đặt đè đơn hàng khi số lượng tồn kho chạm đáy
        Object cartDetailsObj = session.getAttribute("cartDetails");
        if (cartDetailsObj instanceof List) {
            List<?> list = (List<?>) cartDetailsObj;
            for (Object obj : list) {
                if (obj instanceof CartDetail) {
                    CartDetail cd = (CartDetail) obj;
                    Product p = cd.getProduct();
                    int reqQty = cd.getQuantity();

                    if (p != null) {
                        // Thọc trực tiếp xuống DB lấy số lượng mới nhất ngay tại mili-giây này
                        Product dbProduct = productDAO.findById(p.getProductID());
                        if (dbProduct != null) {
                            if (dbProduct.getStockQuantity() <= 0) {
                                session.setAttribute("errorMessage", "Thiết bị [" + dbProduct.getProductName() + "] vừa mới hết hàng! Vui lòng điều chỉnh lại giỏ hàng.");
                                response.sendRedirect(request.getContextPath() + "/cart");
                                return;
                            }
                            if (reqQty > dbProduct.getStockQuantity()) {
                                session.setAttribute("errorMessage", "Sản phẩm [" + dbProduct.getProductName() + "] hiện chỉ còn tối đa " + dbProduct.getStockQuantity() + " chiếc trong kho!");
                                response.sendRedirect(request.getContextPath() + "/cart");
                                return;
                            }
                        }
                    }
                }
            }
        }

        try {
            int totalAmount = 2000;
            boolean foundPrice = false;

            // CHIẾN LƯỢC LẤY GIÁ LINH HOẠT: Ưu tiên tham số URL trước
            String amountParam = request.getParameter("amount");
            if (amountParam != null && !amountParam.trim().isEmpty()) {
                totalAmount = parseAmountString(amountParam);
                foundPrice = true;
            }

            // Nếu không tìm thấy, tự động quét các thuộc tính Session có khả năng lưu trữ tổng tiền
            if (!foundPrice) {
                String[] sessionAttributes = {"totalPrice", "tongTien", "total", "cartTotal", "grandTotal"};
                for (String attr : sessionAttributes) {
                    Object priceObj = session.getAttribute(attr);
                    if (priceObj != null) {
                        totalAmount = parseAmountString(priceObj.toString());
                        break;
                    }
                }
            }

            if (totalAmount < 1000) {
                totalAmount = 2000;
            }

            // Tạo mã đơn hàng độc bản theo dấu thời gian hệ thống
            long orderId = System.currentTimeMillis();
            String description = "CyberCore" + orderId;

            // Định nghĩa các URL điều hướng phản hồi từ phía cổng thanh toán
            String returnUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/views/success.jsp";
            String cancelUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath() + "/views/cart.jsp";

            // Xây dựng chuỗi ký tự chuẩn hóa (Sorted alphabetically) để tạo chữ ký
            String signatureData = "amount=" + totalAmount + "&cancelUrl=" + cancelUrl + "&description=" + description + "&orderCode=" + orderId + "&returnUrl=" + returnUrl;
            String signature = hmacSha256(signatureData, CHECKSUM_KEY);

            // Đóng gói JSON Payload
            String jsonPayload = String.format(
                    "{\"orderCode\":%d,\"amount\":%d,\"description\":\"%s\",\"returnUrl\":\"%s\",\"cancelUrl\":\"%s\",\"signature\":\"%s\"}",
                    orderId, totalAmount, description, returnUrl, cancelUrl, signature
            );

            // Gửi Request POST đến API Gateway của PayOS
            URL url = new URL("https://api-merchant.payos.vn/v2/payment-requests");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("x-client-id", CLIENT_ID);
            conn.setRequestProperty("x-api-key", API_KEY);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                String respStr = new String(conn.getInputStream().readAllBytes(), StandardCharsets.UTF_8);

                String qrCodeUrl = "";
                if (respStr.contains("\"checkoutUrl\":\"")) {
                    int start = respStr.indexOf("\"checkoutUrl\":\"") + 15;
                    int end = respStr.indexOf("\"", start);
                    qrCodeUrl = respStr.substring(start, end).replace("\\/", "/");
                }

                // Thực hiện Redirect khách hàng sang cổng thanh toán độc lập PayOS
                if (qrCodeUrl != null && !qrCodeUrl.isEmpty()) {
                    response.sendRedirect(qrCodeUrl);
                } else {
                    throw new Exception("Không thể bóc tách checkoutUrl từ JSON phản hồi của PayOS.");
                }
            } else {
                throw new Exception("PayOS API trả về mã lỗi HTTP: " + responseCode);
            }

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Lỗi nghiêm trọng khi kết nối cổng thanh toán", e);
            response.getWriter().println("Lỗi kết nối PayOS Gateway: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}