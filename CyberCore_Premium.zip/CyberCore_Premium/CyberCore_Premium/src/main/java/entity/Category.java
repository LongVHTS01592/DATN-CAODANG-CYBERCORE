package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Category {
    private int categoryID;
    private String categoryName;
    private Integer parentCategoryID; // Dùng Integer thay vì int để có thể nhận giá trị null
    private String description;
    private String slug;
}