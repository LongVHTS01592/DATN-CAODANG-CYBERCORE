package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    private int productID;
    private String productName;
    private int categoryID;
    private int brandID;
    private BigDecimal originalPrice;
    private BigDecimal sellPrice;
    private BigDecimal discountPrice;
    private String mainImageURL;
    private String descriptionText;
    private int warrantyMonths;
    private int stockQuantity; // Đã đồng bộ tích hợp quản lý kho
    private int status;
    private Timestamp createdAt;

    // Các đối tượng liên kết hướng đối tượng & danh sách hình ảnh phụ
    private Category category;
    private Brand brand;
    private List<ProductImage> images;
}