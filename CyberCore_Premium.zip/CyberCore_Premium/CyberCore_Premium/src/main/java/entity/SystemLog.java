package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SystemLog {
    private int logID;
    private Integer userID; // Dùng Integer thay vì int để chấp nhận giá trị NULL khi khách chưa đăng nhập
    private String logLevel;
    private String logMessage;
    private Timestamp createdAt;
}