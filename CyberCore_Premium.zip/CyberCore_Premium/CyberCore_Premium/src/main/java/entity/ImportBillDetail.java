package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImportBillDetail {
    private int detailID;
    private int importBillID;
    private int productID;
    private int quantity;
    private BigDecimal importPrice;
}