package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payment {
    private int paymentID;
    private int billID;
    private String paymentMethod;
    private String paymentStatus;
    private BigDecimal amount;
    private String transactionCode;
    private Timestamp paymentDate;
    private Timestamp createdAt;

    // Đối tượng liên kết để lấy thông tin hóa đơn khi cần thiết
    private Bill bill;
}