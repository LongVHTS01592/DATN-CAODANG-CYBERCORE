package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillDetail {
    private int billDetailID;
    private int billID;
    private int productID;
    private int quantity;
    private BigDecimal priceAtSale;

    // Các thuộc tính mở rộng hỗ trợ hiển thị dữ liệu liên kết
    private Product product;
    private String productName;
}