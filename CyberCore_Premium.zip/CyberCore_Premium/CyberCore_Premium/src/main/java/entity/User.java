package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private int userID;
    private String username;
    private String passwordHash;
    private String fullName;
    private String email;
    private String phone;
    private String coverUrl; // Đã thêm: Lưu link ảnh bìa
    private int roleID;
    private boolean isActive;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Đối tượng liên kết để trực tiếp kiểm tra quyền hạn (Role Name, Description)
    private Role role;

    // Đã thêm: Danh sách địa chỉ của User (Khởi tạo sẵn ArrayList để tránh lỗi NullPointerException)
    private List<UserAddress> addresses = new ArrayList<>();
}