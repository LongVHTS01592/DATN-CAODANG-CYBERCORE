package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartDetail {
    private int cartDetailID;
    private int cartID;
    private int productID;
    private int quantity;

    // Đối tượng liên kết để lấy thông tin chi tiết (tên, giá, hình ảnh...) của sản phẩm
    private Product product;
}