package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImportRequest {
    private int requestID;
    private int productID;
    private int quantity;
    private int staffID;
    private Timestamp requestDate;
    private int status; // 0: Pending, 1: Approved, 2: Rejected
    private String note;
    private Integer processedBy;   // ID của Admin xử lý (Có thể NULL khi đang chờ duyệt)
    private Timestamp processedDate; // Ngày Admin xử lý duyệt/từ chối

    /**
     * Hỗ trợ hiển thị trạng thái bằng văn bản trực quan trên giao diện JSP/HTML thông qua EL expression
     */
    public String getStatusName() {
        return switch (this.status) {
            case 0 -> "Pending";
            case 1 -> "Approved";
            case 2 -> "Rejected";
            default -> "Unknown";
        };
    }
}