package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RevenueReport {
    private int reportYear;
    private int reportMonth;
    private double totalRevenue;
    private int totalOrders;
}