package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAddress {
    private int addressID;
    private int userID;
    private String recipientName;
    private String phone;
    private String provinceName;
    private String districtName;
    private String wardName;
    private String detailedAddress;
    private boolean isDefault;

    // =========================================================================
    // CÁC HÀM OVERRIDE ĐỂ PHÒNG NGỪA LỖI ĐẶC THÙ CỦA LOMBOK + JSP EL
    // =========================================================================

    // 1. Dành cho giao diện JSP EL (gọi ${addr.isDefault} không bị lỗi sập trang 500)
    public boolean getIsDefault() {
        return isDefault;
    }

    // 2. Dành cho DAO (khớp chính xác với lệnh a.setIsDefault trong map dữ liệu)
    public void setIsDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    // 3. Hàm backup chuẩn theo quy ước JavaBeans phòng hờ cho các thư viện khác
    public boolean isDefault() {
        return isDefault;
    }
}