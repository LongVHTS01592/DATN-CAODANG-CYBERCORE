package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Review {
    private int reviewID;
    private int userID;
    private int productID;
    private int rating;
    private String comment;
    private Timestamp createdAt;

    // Các đối tượng liên kết
    private User user;
    private Product product;

    // Các thuộc tính bổ sung hỗ trợ hiển thị giao diện UI/UX (Hợp nhất từ Proj 2 & 3)
    private String username;
    private String avatarText;
}