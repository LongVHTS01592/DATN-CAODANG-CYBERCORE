package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImportBill {
    private int importBillID;
    private String supplierName;
    private Timestamp importDate; // Đã đồng bộ sang java.sql.Timestamp chuẩn hệ thống
    private BigDecimal totalImportAmount;
    private int userID;
}