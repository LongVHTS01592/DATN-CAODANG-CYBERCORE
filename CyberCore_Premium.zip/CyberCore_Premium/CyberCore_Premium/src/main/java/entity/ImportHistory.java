package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImportHistory {
    private Timestamp importDate;
    private String productName;
    private String supplierName;
    private int quantity;
    private BigDecimal importPrice;
    private String staffName;

    // Đã xóa phần comment boilerplate code (Getter và Setter...) vì @Data của Lombok đã lo hết
}