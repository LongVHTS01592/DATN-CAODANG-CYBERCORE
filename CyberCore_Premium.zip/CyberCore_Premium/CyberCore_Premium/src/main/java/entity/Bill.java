package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bill {
    private int billID;
    private int userID;
    private Timestamp orderDate;
    private String shippingRecipientName;
    private String shippingPhone;
    private String shippingAddressText;
    private BigDecimal totalAmount;
    private String voucherCode; // Cập nhật theo chuẩn Database mới
    private String orderStatus;
    private String notes;

    // Các thuộc tính mở rộng phục vụ Join bảng hiển thị trên UI
    private int quantity;
    private User user;
    private List<BillDetail> details;
}