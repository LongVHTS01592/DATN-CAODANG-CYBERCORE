package util;

import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.*;

public class MailUtil {

    // Tài khoản Email và Mật khẩu ứng dụng (App Password) của hệ thống CyberCore
    private static final String USER = "cybercoresupport@gmail.com";
    private static final String PASS = "gxjr ohaw ptxa zgnz";

    /**
     * Hàm gửi Email hỗ trợ định dạng HTML và hiển thị tiếng Việt có dấu chuẩn mã hóa UTF-8
     * * @param to       Địa chỉ email người nhận
     * @param subject  Tiêu đề email
     * @param content  Nội dung email (Có thể truyền chuỗi văn bản hoặc mã HTML)
     * @throws Exception
     */
    public static void sendMail(String to, String subject, String content) throws Exception {

        // 1. Thiết lập cấu hình kết nối tới Server SMTP của Gmail
        Properties prop = new Properties();
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); // Kích hoạt giao thức bảo mật TLS
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");            // Cổng kết nối chuẩn TLS

        // 2. Tạo phiên làm việc (Session) và xác thực tài khoản hệ thống
        Session session = Session.getInstance(prop, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USER, PASS);
            }
        });

        // 3. Khởi tạo và cấu hình nội dung thư thư điện tử
        Message message = new MimeMessage(session);

        // Thiết lập người gửi
        message.setFrom(new InternetAddress(USER));

        // Thiết lập người nhận
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));

        // Thiết lập tiêu đề (Hỗ trợ tiếng Việt có dấu không bị lỗi font)
        message.setSubject(MimeUtility.encodeText(subject, "UTF-8", "B"));

        // CẢI TIẾN PREMIUM: Chuyển sang định dạng text/html kết hợp UTF-8
        // Giúp gửi được email dạng bảng, hóa đơn, nút bấm (Button) và không bao giờ bị lỗi dấu tiếng Việt.
        message.setContent(content, "text/html; charset=utf-8");

        // 4. Kích hoạt tiến trình gửi thư đi
        Transport.send(message);
    }
}