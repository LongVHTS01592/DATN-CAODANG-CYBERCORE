package util;

import java.sql.*;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

public class JdbcUtil {

    // Cấu hình kết nối CSDL ComputerStoreEnterpriseDB
    private static final String url = "jdbc:sqlserver://localhost:1433;databaseName=ComputerStoreEnterpriseDB;encrypt=true;trustServerCertificate=true;";
    private static final String user = "sa";
    private static final String pass = "1234";

    // BẮT BUỘC TRONG MÔI TRƯỜNG WEB (TOMCAT):
    // Phải gọi Class.forName để đăng ký Driver vì Tomcat đôi khi không tự động kích hoạt SPI của JDBC
    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println(">>> TRẠNG THÁI: Tải SQLServerDriver thành công!");
        } catch (ClassNotFoundException e) {
            System.out.println(">>> LỖI CẤU HÌNH: Không tìm thấy thư viện mssql-jdbc Driver! Kiểm tra lại file pom.xml hoặc thư mục lib.");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }

    /**
     * Dùng cho các lệnh INSERT, UPDATE, DELETE
     */
    public static int executeUpdate(String sql, Object... args) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (int i = 0; i < args.length; i++) {
                pstmt.setObject(i + 1, args[i]);
            }
            return pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Dùng cho các lệnh SELECT. 
     * Đã áp dụng CachedRowSet để tự động đóng Connection & PreparedStatement chống sập Server.
     */
    public static ResultSet executeQuery(String sql, Object... args) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (int i = 0; i < args.length; i++) {
                pstmt.setObject(i + 1, args[i]);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                // Tạo một bản sao ngoại tuyến (offline) của ResultSet
                CachedRowSet crs = RowSetProvider.newFactory().createCachedRowSet();
                crs.populate(rs);
                return crs; // Trả về dữ liệu an toàn, kết nối gốc với DB sẽ tự động bị đóng ngay sau dòng này
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}