<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Đơn Hàng</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <h2 class="fw-bolder text-dark tracking-wide mb-4">Quản Lý Hóa Đơn</h2>
            <div class="card card-custom">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light text-muted small text-uppercase fw-bold"><tr><th class="ps-4">Mã Hóa Đơn</th><th>Người nhận</th><th>Ngày Đặt</th><th>Tổng Tiền</th><th>Trạng Thái</th><th class="text-center pe-4">Chi Tiết</th></tr></thead>
                        <tbody>
                        <c:forEach items="${bills}" var="b">
                            <tr>
                                <td class="ps-4 fw-bold text-secondary">#ORD-${b.billID}</td><td class="fw-semibold text-dark">${b.shippingRecipientName}</td>
                                <td class="text-muted"><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                                <td class="fw-bold text-danger"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                                <td><span class="badge rounded-pill ${b.orderStatus == 'Pending' ? 'bg-warning text-dark' : (b.orderStatus == 'Completed' ? 'bg-success' : 'bg-info')}">${b.orderStatus}</span></td>
                                <td class="text-center pe-4"><button class="btn btn-sm btn-light border text-primary rounded-circle shadow-sm" data-bs-toggle="modal" data-bs-target="#orderDetailModal${b.billID}"><i class="fa-solid fa-expand"></i></button></td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<c:forEach items="${bills}" var="b">
    <div class="modal fade" id="orderDetailModal${b.billID}" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="modal-header bg-dark text-white border-bottom border-warning border-3">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-receipt text-warning me-2"></i> Chi Tiết #ORD-${b.billID}</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4 bg-light">
                    <div class="bg-white p-3 rounded-3 shadow-sm border mb-4">
                        <p class="mb-1"><i class="fa-solid fa-user text-primary me-2"></i> <strong>${b.shippingRecipientName}</strong> - ${b.shippingPhone}</p>
                        <p class="mb-0"><i class="fa-solid fa-location-dot text-danger me-2"></i> ${b.shippingAddressText}</p>
                    </div>
                    <table class="table table-bordered bg-white shadow-sm">
                        <thead class="table-light text-muted small text-uppercase"><tr><th class="ps-3">Thiết Bị Linh Kiện</th><th class="text-center">SL</th><th class="text-end pe-3">Giá Chốt</th></tr></thead>
                        <tbody>
                        <c:forEach items="${b.details}" var="detail">
                            <tr><td class="ps-3 fw-semibold">${detail.product.productName}</td><td class="text-center">${detail.quantity}</td><td class="text-danger fw-bold text-end pe-3"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td></tr>
                        </c:forEach>
                        </tbody>
                    </table>
                    <form action="${pageContext.request.contextPath}/BillAdminController" method="post" class="mt-4 bg-white p-3 rounded-3 shadow-sm border">
                        <input type="hidden" name="billId" value="${b.billID}">
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light fw-bold text-secondary fs-6">Trạng Thái Giao Hàng</span>
                            <select name="orderStatus" class="form-select fw-semibold text-dark fs-6">
                                <option value="Pending" ${b.orderStatus == 'Pending' ? 'selected' : ''}>Chờ duyệt</option>
                                <option value="Processing" ${b.orderStatus == 'Processing' ? 'selected' : ''}>Đang đóng gói</option>
                                <option value="Completed" ${b.orderStatus == 'Completed' ? 'selected' : ''}>Hoàn thành thành công</option>
                                <option value="Cancelled" ${b.orderStatus == 'Cancelled' ? 'selected' : ''}>Đã hủy đơn</option>
                            </select>
                            <button type="submit" class="btn btn-warning fw-bold text-dark px-4 fs-6">Cập nhật</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</c:forEach>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>