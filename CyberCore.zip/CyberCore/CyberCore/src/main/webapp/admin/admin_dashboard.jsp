<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<jsp:useBean id="now" class="java.util.Date" />
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Bảng Điều Khiển</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background-color: #121212; color: #fff; }
        .sidebar-brand { font-size: 1.4rem; font-weight: 800; color: #ffc107; padding: 1.5rem 1rem; text-transform: uppercase; letter-spacing: 1px; border-bottom: 1px solid #333; }
        .nav-menu .nav-link { color: #a1a1aa; padding: 0.8rem 1.5rem; font-weight: 500; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { color: #ffc107; background-color: rgba(255,255,255,0.05); border-left: 4px solid #ffc107; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }
    </style>
</head>
<body>
<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-0 position-fixed" style="z-index: 100;">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip me-2"></i>CyberCore</div>
            <ul class="nav flex-column nav-menu">
                <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-gauge-high me-2 w-20px"></i> Tổng Quan</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive me-2 w-20px"></i> Sản Phẩm</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-layer-group me-2 w-20px"></i> Danh Mục</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar me-2 w-20px"></i> Đơn Hàng</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket me-2 w-20px"></i> Khuyến Mãi</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/revenue-report"><i class="fa-solid fa-chart-line me-2 w-20px"></i> Báo Cáo</a></li>
                <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users me-2 w-20px"></i> Khách Hàng</a></li>
                <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-success fw-bold" href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-arrow-left me-2 w-20px"></i> Về Cửa Hàng</a></li>
                <li class="nav-item pt-2"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-power-off me-2 w-20px"></i> Đăng Xuất</a></li>
            </ul>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4" style="margin-left: 16.666667%;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="fw-bolder text-dark tracking-wide">Bảng Điều Khiển</h2>
                <div class="text-muted fw-semibold bg-white px-3 py-2 rounded-pill shadow-sm"><i class="fa-regular fa-calendar-check text-warning me-2"></i> Hôm nay: <fmt:formatDate value="${now}" pattern="dd/MM/yyyy" /></div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-lg-3 col-sm-6">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-muted fw-bold text-uppercase mb-2">Doanh Thu</h6><h3 class="fw-bolder mb-0 text-dark"><fmt:formatNumber value="${totalRevenue != null ? totalRevenue : 0}" type="currency" currencySymbol="đ"/></h3></div>
                            <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="fa-solid fa-wallet"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-muted fw-bold text-uppercase mb-2">Đơn Mới</h6><h3 class="fw-bolder mb-0 text-dark">${newOrdersCount != null ? newOrdersCount : 0}</h3></div>
                            <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="fa-solid fa-cart-shopping"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-muted fw-bold text-uppercase mb-2">Sắp Hết Hàng</h6><h3 class="fw-bolder mb-0 text-danger">${lowStockCount != null ? lowStockCount : 0}</h3></div>
                            <div class="stat-icon bg-danger bg-opacity-10 text-danger"><i class="fa-solid fa-triangle-exclamation"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <div class="card card-custom p-4">
                        <div class="d-flex justify-content-between align-items-center">
                            <div><h6 class="text-muted fw-bold text-uppercase mb-2">Thành Viên</h6><h3 class="fw-bolder mb-0 text-dark">${newUsersCount != null ? newUsersCount : 0}</h3></div>
                            <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="fa-solid fa-users"></i></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card card-custom mb-4">
                <div class="card-header bg-white py-3 border-0"><h5 class="mb-0 fw-bold"><i class="fa-solid fa-chart-column text-primary me-2"></i>Thống Kê Doanh Thu Quý</h5></div>
                <div class="card-body"><canvas id="revenueChart" height="90"></canvas></div>
            </div>
        </main>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const chartLabels = []; const chartData = [];
        <c:if test="${not empty revenueList}"><c:forEach var="item" items="${revenueList}">chartLabels.unshift('${item.reportMonth}/${item.reportYear}'); chartData.unshift(${item.totalRevenue});</c:forEach></c:if>
        const ctx = document.getElementById('revenueChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: { labels: chartLabels, datasets: [{ data: chartData, backgroundColor: '#ffc107', borderRadius: 4 }] },
            options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });
    });
</script>
</body>
</html>