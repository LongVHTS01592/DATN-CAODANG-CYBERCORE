package servlet;

import dao.UserDAO;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet({"/login", "/register", "/LogoutController"})
public class AuthServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();

        if ("/login".equals(path)) {
            String action = request.getParameter("action");
            if ("logout".equals(action)) {
                request.getSession().invalidate();
                response.sendRedirect(request.getContextPath() + "/home");
            } else {
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }
        } else if ("/register".equals(path)) {
            request.getRequestDispatcher("/views/register.jsp").forward(request, response);
        } else if ("/LogoutController".equals(path)) {
            request.getSession().invalidate();
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String path = request.getServletPath();

        if ("/login".equals(path)) {
            String username = request.getParameter("username"); // ĐÃ ĐỒNG BỘ PARAMETER
            String password = request.getParameter("password");

            User user = userDAO.login(username, password);

            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("userAccount", user);

                if (user.getRoleID() == 1 || user.getRoleID() == 2) {
                    response.sendRedirect(request.getContextPath() + "/admin/dashboard");
                } else {
                    response.sendRedirect(request.getContextPath() + "/home");
                }
            } else {
                request.setAttribute("error", "Sai Email/Username hoặc mật khẩu!");
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }

        } else if ("/register".equals(path)) {
            String username = request.getParameter("username"); // ĐÃ ĐỒNG BỘ PARAMETER
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");

            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPasswordHash(password);
            newUser.setFullName(fullname);
            newUser.setEmail(email);
            newUser.setPhone(phone);
            newUser.setRoleID(3);
            newUser.setActive(true);

            if (userDAO.insert(newUser)) {
                response.sendRedirect(request.getContextPath() + "/login");
            } else {
                request.setAttribute("error", "Đăng ký thất bại! Tài khoản, Email hoặc SĐT đã tồn tại.");
                request.getRequestDispatcher("/views/register.jsp").forward(request, response);
            }
        }
    }
}