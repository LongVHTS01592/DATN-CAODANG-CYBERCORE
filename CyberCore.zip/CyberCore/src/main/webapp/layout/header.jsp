<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CyberCore - Hệ Thống Linh Kiện</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <style>
    /* CSS cho khối Banner giống dự án cũ */
    .hero-banner {
      background-color: #343a40; /* Màu nền tối công nghệ */
      color: white;
      padding: 100px 0;
      border-bottom: 5px solid #ffc107;
    }
    body { background-color: #fcfcfc; }
  </style>
</head>
<body>