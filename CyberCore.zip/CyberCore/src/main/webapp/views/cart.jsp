<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
    <h2 class="text-uppercase fw-bold mb-4"><i class="fa-solid fa-cart-shopping text-warning"></i> Giỏ Hàng Của Bạn</h2>

    <c:choose>
        <%-- Xử lý khi giỏ hàng trống --%>
        <c:when test="${empty cartDetails}">
            <div class="alert alert-info text-center py-5 shadow-sm rounded-4 bg-white border-0">
                <i class="fa-solid fa-cart-arrow-down fa-4x mb-3 text-secondary"></i>
                <h4 class="fw-bold">Giỏ hàng đang trống!</h4>
                <p class="text-muted">Hãy khám phá thêm các linh kiện đỉnh cao tại cửa hàng nhé.</p>
                <a href="${pageContext.request.contextPath}/product" class="btn btn-warning fw-bold rounded-pill px-4 mt-2">ĐẾN CỬA HÀNG NGAY</a>
            </div>
        </c:when>

        <%-- Xử lý khi có sản phẩm --%>
        <c:otherwise>
            <div class="row">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Sản phẩm</th>
                                        <th>Đơn giá</th>
                                        <th style="width: 120px;">Số lượng</th>
                                        <th>Thành tiền</th>
                                        <th class="text-center">Xóa</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <c:set var="totalAmount" value="0" />

                                    <c:forEach items="${cartDetails}" var="item">
                                        <%-- Tính thành tiền từng món và cộng dồn vào tổng --%>
                                        <c:set var="subtotal" value="${item.product.sellPrice * item.quantity}" />
                                        <c:set var="totalAmount" value="${totalAmount + subtotal}" />

                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center">
                                                    <img src="${not empty item.product.mainImageURL ? item.product.mainImageURL : 'https://via.placeholder.com/50'}" class="rounded me-3" style="width: 50px; height: 50px; object-fit: cover;">
                                                    <span class="fw-bold text-dark">${item.product.productName}</span>
                                                </div>
                                            </td>
                                            <td class="text-danger fw-bold"><fmt:formatNumber value="${item.product.sellPrice}" type="currency" currencySymbol="đ"/></td>
                                            <td>
                                                <form action="${pageContext.request.contextPath}/cart" method="post" class="d-flex m-0">
                                                    <input type="hidden" name="action" value="update">
                                                    <input type="hidden" name="cartDetailId" value="${item.cartDetailID}">
                                                    <input type="number" name="quantity" class="form-control form-control-sm text-center" value="${item.quantity}" min="1" onchange="this.form.submit()">
                                                </form>
                                            </td>
                                            <td class="text-danger fw-bold"><fmt:formatNumber value="${subtotal}" type="currency" currencySymbol="đ"/></td>
                                            <td class="text-center">
                                                <form action="${pageContext.request.contextPath}/cart" method="post" class="m-0">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="cartDetailId" value="${item.cartDetailID}">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger rounded-circle"><i class="fa-solid fa-trash"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    </c:forEach>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-4"><i class="fa-solid fa-receipt text-secondary"></i> Tóm tắt đơn hàng</h5>
                            <div class="d-flex justify-content-between mb-3">
                                <span class="text-muted">Tổng phụ:</span>
                                <span class="fw-bold"><fmt:formatNumber value="${totalAmount}" type="currency" currencySymbol="đ"/></span>
                            </div>
                            <div class="d-flex justify-content-between mb-3">
                                <span class="text-muted">Phí giao hàng:</span>
                                <span class="text-success fw-bold">Miễn phí</span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-4">
                                <span class="fw-bold fs-5">Tổng cộng:</span>
                                <span class="fw-bold fs-5 text-danger"><fmt:formatNumber value="${totalAmount}" type="currency" currencySymbol="đ"/></span>
                            </div>
                            <a href="${pageContext.request.contextPath}/checkout" class="btn btn-warning w-100 fw-bold rounded-pill py-3">XÁC NHẬN ĐẶT HÀNG</a>
                        </div>
                    </div>
                </div>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<jsp:include page="/layout/footer.jsp" />