<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="container mt-5 mb-5" style="min-height: 70vh;">
  <h2 class="text-center text-uppercase fw-bold mb-4">Danh Sách Linh Kiện</h2>

  <form action="${pageContext.request.contextPath}/product" method="get">
    <div class="row mb-4 justify-content-center bg-white p-3 rounded-4 shadow-sm border mx-0">
      <div class="col-md-5 mb-2 mb-md-0">
        <div class="input-group">
          <span class="input-group-text bg-transparent border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
          <input type="text" class="form-control border-start-0" name="keyword" placeholder="Tìm tên linh kiện..." value="${param.keyword}">
        </div>
      </div>
      <div class="col-md-3 mb-2 mb-md-0">
        <select class="form-select" name="categoryId">
          <option value="">Tất cả loại</option>
          <c:forEach items="${categories}" var="c">
            <option value="${c.categoryID}" ${param.categoryId == c.categoryID ? 'selected' : ''}>${c.categoryName}</option>
          </c:forEach>
        </select>
      </div>
      <div class="col-md-2 mb-2 mb-md-0">
        <select class="form-select" name="status">
          <option value="">Tất cả trạng thái</option>
          <option value="1">Còn hàng</option>
          <option value="0">Hết hàng</option>
        </select>
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-dark w-100 fw-bold">LỌC NGAY</button>
      </div>
    </div>
  </form>

  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4" id="productGrid">
    <c:forEach items="${products}" var="p">
      <div class="col">
        <div class="card h-100 shadow-sm rounded-4 border-0">
          <div class="card-body text-center text-muted py-4 bg-white rounded-4 d-flex flex-column">
            <img src="${not empty p.mainImageURL ? p.mainImageURL : 'https://via.placeholder.com/150'}" alt="${p.productName}" class="img-fluid mb-3 rounded" style="height: 150px; object-fit: cover;">
            <p class="mb-1 fw-bold text-dark text-truncate" title="${p.productName}">${p.productName}</p>
            <p class="small text-secondary mb-2 text-truncate" title="${p.descriptionText}">${not empty p.descriptionText ? p.descriptionText : 'Đang cập nhật'}</p>
            <p class="text-danger fw-bold fs-5 mt-auto">
              <fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/>
            </p>

            <form action="${pageContext.request.contextPath}/cart" method="post" class="mt-2">
              <input type="hidden" name="action" value="add">
              <input type="hidden" name="productId" value="${p.productID}">
              <input type="hidden" name="quantity" value="1">
              <button type="submit" class="btn btn-dark btn-sm rounded-circle"><i class="fa-solid fa-cart-shopping"></i></button>
            </form>
          </div>
        </div>
      </div>
    </c:forEach>

    <c:if test="${empty products}">
      <div class="col-12 text-center text-muted py-5">
        <p>Không tìm thấy sản phẩm nào.</p>
      </div>
    </c:if>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />