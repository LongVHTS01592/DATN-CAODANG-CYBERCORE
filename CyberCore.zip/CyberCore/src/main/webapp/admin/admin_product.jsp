<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <title>CyberCore Admin - Quản Lý Sản Phẩm</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    .sidebar { min-height: 100vh; background-color: #1e293b; color: #f8fafc; }
    .sidebar-brand { font-size: 1.3rem; font-weight: 700; color: #38bdf8; padding: 1.5rem 1rem; border-bottom: 1px solid #334155; }
    .nav-menu .nav-link { color: #94a3b8; padding: 0.8rem 1rem; display: flex; align-items: center; gap: 10px; transition: all 0.3s; }
    .nav-menu .nav-link:hover, .nav-menu .nav-link.active { background-color: #334155; color: #fff; border-radius: 0.25rem; }
  </style>
</head>
<body>

<div class="container-fluid p-0">
  <div class="row g-0">
    <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-3">
      <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip"></i> CYBERCORE ADMIN</div>
      <div class="position-sticky">
        <ul class="nav flex-column nav-menu gap-1">
          <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
          <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive"></i> Sản phẩm</a></li>
          <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-list-ul"></i> Danh mục</a></li>
          <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar"></i> Đơn hàng</a></li>
          <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users"></i> Khách hàng</a></li>
          <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
      </div>
    </nav>

    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Quản lý Sản phẩm</h2>
        <a href="${pageContext.request.contextPath}/ProductAdminController" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
          <i class="fa-solid fa-plus"></i> Thêm sản phẩm
        </a>
      </div>

      <div class="card shadow-sm border-0">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-dark"><tr><th>Ảnh</th><th>Tên sản phẩm</th><th>Giá bán</th><th>Bảo hành</th><th>Trạng thái</th><th class="text-center">Thao tác</th></tr></thead>
          <tbody>
          <c:forEach items="${products}" var="p">
            <tr>
              <td><img src="${not empty p.mainImageURL ? p.mainImageURL : 'https://via.placeholder.com/50'}" class="rounded" style="width: 50px; height: 50px; object-fit: cover;"></td>
              <td class="fw-bold">${p.productName}</td>
              <td class="text-danger fw-bold"><fmt:formatNumber value="${p.sellPrice}" type="currency" currencySymbol="đ"/></td>
              <td>${p.warrantyMonths} tháng</td>
              <td><span class="badge ${p.status == 1 ? 'bg-success' : 'bg-secondary'}">${p.status == 1 ? 'Đang bán' : 'Ngưng bán'}</span></td>
              <td class="text-center">
                <a href="${pageContext.request.contextPath}/ProductAdminController?action=edit&id=${p.productID}" class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-pen"></i></a>
                <a href="${pageContext.request.contextPath}/ProductAdminController?action=delete&id=${p.productID}" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa sản phẩm này?');"><i class="fa-solid fa-trash"></i></a>
              </td>
            </tr>
          </c:forEach>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<div class="modal fade" id="productModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="fa-solid fa-box-open"></i> ${not empty productEdit ? 'Cập nhật' : 'Thêm mới'} Sản phẩm</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form action="${pageContext.request.contextPath}/ProductAdminController" method="POST">
        <input type="hidden" name="action" value="${not empty productEdit ? 'update' : 'insert'}">
        <input type="hidden" name="id" value="${productEdit.productID}">
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label fw-bold">Tên sản phẩm</label><input type="text" class="form-control" name="productName" value="${productEdit.productName}" required></div>
            <div class="col-md-6"><label class="form-label fw-bold">Giá bán</label><input type="number" class="form-control" name="sellPrice" value="${productEdit.sellPrice}" required></div>
            <div class="col-md-6"><label class="form-label fw-bold">Link Ảnh (URL)</label><input type="text" class="form-control" name="mainImageURL" value="${productEdit.mainImageURL}"></div>
            <div class="col-md-6"><label class="form-label fw-bold">Bảo hành (tháng)</label><input type="number" class="form-control" name="warrantyMonths" value="${not empty productEdit ? productEdit.warrantyMonths : 12}"></div>
            <div class="col-12"><label class="form-label fw-bold">Mô tả chi tiết</label><textarea class="form-control" name="description" rows="3">${productEdit.descriptionText}</textarea></div>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <c:if test="${not empty productEdit}"><a href="${pageContext.request.contextPath}/ProductAdminController" class="btn btn-secondary">Hủy cập nhật</a></c:if>
          <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i> Lưu dữ liệu</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<%-- Tự động mở Modal nếu đang ở trạng thái Edit --%>
<c:if test="${not empty productEdit}">
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      var myModal = new bootstrap.Modal(document.getElementById('productModal'));
      myModal.show();
    });
  </script>
</c:if>
</body>
</html>