<%@ page contentType="text/html;charset=UTF-8" language="java" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Báo Cáo Doanh Thu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        html, body { height: 100%; margin: 0; background: #f4f6f9; font-family: 'Segoe UI', sans-serif; }
        .wrapper { display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background: #1e293b; color: white; flex-shrink: 0; }
        .sidebar-brand { font-size: 1.3rem; font-weight: 700; color: #38bdf8; padding: 1.5rem 1rem; border-bottom: 1px solid #334155; }
        .nav-menu .nav-link { color: #94a3b8; padding: .8rem 1rem; display: flex; align-items: center; gap: 10px; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { background: #334155; color: white; border-radius: 4px; }
        .main-content { flex-grow: 1; padding: 25px; }
        .card-box { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 0 10px rgba(0,0,0,.08); }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar">
        <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip"></i> CYBERCORE</div>
        <ul class="nav flex-column nav-menu px-3 gap-1">
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive"></i> Sản phẩm</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-list-ul"></i> Danh mục</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar"></i> Đơn hàng</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket"></i> Voucher</a></li>
            <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/admin/revenue"><i class="fa-solid fa-chart-line"></i> Doanh thu</a></li>
            <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users"></i> Khách hàng</a></li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="card-box">
            <h2 class="mb-4">Báo Cáo Thống Kê Doanh Thu</h2>

            <div class="table-responsive mb-5 shadow-sm">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th class="text-center">Tháng / Năm</th>
                        <th class="text-center">Tổng số đơn hàng</th>
                        <th class="text-end">Tổng doanh thu (VNĐ)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach var="item" items="${revenueList}">
                        <tr>
                            <td class="text-center">${item.reportMonth} / ${item.reportYear}</td>
                            <td class="text-center">${item.totalOrders}</td>
                            <td class="text-end">${item.totalRevenue}</td>
                        </tr>
                    </c:forEach>
                    <c:if test="${empty revenueList}">
                        <tr><td colspan="3" class="text-center text-danger">Chưa có dữ liệu doanh thu nào!</td></tr>
                    </c:if>
                    </tbody>
                </table>
            </div>

            <div style="width: 80%; margin: 0 auto;">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
    </main>
</div>

<script>
    const chartLabels = [];
    const chartData = [];
    <c:forEach var="item" items="${revenueList}">
    chartLabels.unshift('${item.reportMonth}/${item.reportYear}');
    chartData.unshift(${item.totalRevenue});
    </c:forEach>

    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: chartData,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: { responsive: true, scales: { y: { beginAtZero: true } } }
    });
</script>
</body>
</html>