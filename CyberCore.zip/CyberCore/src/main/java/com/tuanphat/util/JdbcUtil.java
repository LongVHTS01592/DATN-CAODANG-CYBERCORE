package com.tuanphat.util;

import java.sql.*;

public class JdbcUtil {

    // Kết nối đến Database ComputerStoreEnterpriseDB của dự án
    private static String url = "jdbc:sqlserver://localhost:1433;databaseName=ComputerStoreEnterpriseDB;encrypt=true;trustServerCertificate=true";
    private static String user = "sa";
    private static String pass = "1234";

    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, pass);
    }

    public static int executeUpdate(String sql, Object... args) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) {
                pstmt.setObject(i + 1, args[i]);
            }
            return pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public static ResultSet executeQuery(String sql, Object... args) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        for (int i = 0; i < args.length; i++) {
            pstmt.setObject(i + 1, args[i]);
        }
        return pstmt.executeQuery();
    }
}