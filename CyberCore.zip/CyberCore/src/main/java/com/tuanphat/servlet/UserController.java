package com.tuanphat.servlet;

import com.tuanphat.dao.UserDAO;
import com.tuanphat.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/UserController")
public class UserController extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT ADMIN
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("userAccount");
        if (currentUser == null || currentUser.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("toggle".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                User u = userDAO.findById(Integer.parseInt(idStr));
                // Không cho phép Admin tự khóa chính mình
                if (u != null && u.getUserID() != currentUser.getUserID()) {
                    u.setActive(!u.isActive());
                    userDAO.update(u);
                }
            }
            response.sendRedirect(request.getContextPath() + "/UserController");
            return;
        }

        List<User> users = userDAO.findAll();
        request.setAttribute("users", users);
        request.getRequestDispatcher("/admin/admin_user.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}