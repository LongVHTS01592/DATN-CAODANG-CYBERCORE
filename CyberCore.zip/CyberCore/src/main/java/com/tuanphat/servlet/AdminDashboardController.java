package com.tuanphat.servlet;

import com.tuanphat.dao.BillDAO;
import com.tuanphat.entity.Bill;
import com.tuanphat.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/admin/dashboard")
public class AdminDashboardController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT: Chỉ Admin(1) hoặc Staff(2) mới được vào
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Tính toán các chỉ số thống kê
        BigDecimal totalRevenue = billDAO.getTotalRevenue();
        int pendingOrders = billDAO.countPendingOrders();
        List<Bill> recentOrders = billDAO.getRecentOrders(5);

        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("newOrdersCount", pendingOrders);
        request.setAttribute("recentOrders", recentOrders);

        request.getRequestDispatcher("/admin/admin_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}