package com.tuanphat.servlet;

import com.tuanphat.dao.ReportDAO;
import com.tuanphat.entity.RevenueReport;
import com.tuanphat.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "RevenueController", urlPatterns = {"/admin/revenue"})
public class RevenueController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // CHỐT CHẶN BẢO MẬT: Phải là Admin hoặc Staff
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        ReportDAO reportDAO = new ReportDAO();

        Map<String, Object> stats = reportDAO.getDashboardStats();
        request.setAttribute("stats", stats);

        List<RevenueReport> revenueList = reportDAO.getMonthlyRevenue();
        request.setAttribute("revenueList", revenueList);

        // Đổi tên file jsp cho đồng bộ với dự án
        request.getRequestDispatcher("/admin/admin_revenue.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}