package com.tuanphat.servlet;

import com.tuanphat.dao.ProductDAO;
import com.tuanphat.entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet({"/home", "/index"})
public class HomeServlet extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // Lấy 4 sản phẩm mới nhất để show ra trang chủ
        List<Product> newProducts = productDAO.getNewestProducts(4);
        request.setAttribute("newProducts", newProducts);

        request.getRequestDispatcher("/views/index.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // Chuyển tiếp luồng Post về Get để xử lý đồng nhất, không để hàm rỗng
        doGet(request, response);
    }
}