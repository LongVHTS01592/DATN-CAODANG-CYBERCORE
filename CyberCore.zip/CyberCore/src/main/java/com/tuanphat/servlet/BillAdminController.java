package com.tuanphat.servlet;

import com.tuanphat.dao.BillDAO;
import com.tuanphat.dao.BillDetailDAO;
import com.tuanphat.dao.ProductDAO;
import com.tuanphat.entity.Bill;
import com.tuanphat.entity.BillDetail;
import com.tuanphat.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

@WebServlet("/BillAdminController")
public class BillAdminController extends HttpServlet {

    private final BillDAO billDAO = new BillDAO();
    private final BillDetailDAO billDetailDAO = new BillDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // BẢO MẬT ADMIN
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        List<Bill> bills = billDAO.findAll();

        // Vòng lặp nạp chi tiết các món hàng vào từng Bill (Fix lỗi rỗng modal)
        for (Bill b : bills) {
            List<BillDetail> details = billDetailDAO.findByBillId(b.getBillID());
            for (BillDetail d : details) {
                d.setProduct(productDAO.findById(d.getProductID())); // Nạp luôn thông tin linh kiện
            }
            b.setDetails(details); // Giả sử Entity Bill của bạn có thuộc tính List<BillDetail> details
        }

        request.setAttribute("bills", bills);
        request.getRequestDispatcher("/admin/admin_bill.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String billIdStr = request.getParameter("billId");
        String newStatus = request.getParameter("orderStatus");

        if (billIdStr != null && newStatus != null) {
            billDAO.updateStatus(Integer.parseInt(billIdStr), newStatus);
        }

        response.sendRedirect(request.getContextPath() + "/BillAdminController");
    }
}