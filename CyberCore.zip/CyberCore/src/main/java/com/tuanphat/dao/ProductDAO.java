package com.tuanphat.dao;

import com.tuanphat.entity.Product;
import com.tuanphat.util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    private Product map(ResultSet rs) throws SQLException {
        Product p = new Product();
        p.setProductID(rs.getInt("ProductID"));
        p.setProductName(rs.getString("ProductName"));
        p.setCategoryID(rs.getInt("CategoryID"));
        p.setBrandID(rs.getInt("BrandID"));
        p.setOriginalPrice(rs.getBigDecimal("OriginalPrice"));
        p.setSellPrice(rs.getBigDecimal("SellPrice"));
        p.setDiscountPrice(rs.getBigDecimal("DiscountPrice"));
        p.setMainImageURL(rs.getString("MainImageURL"));
        p.setDescriptionText(rs.getString("DescriptionText"));
        p.setWarrantyMonths(rs.getInt("WarrantyMonths"));
        p.setStatus(rs.getInt("Status"));
        p.setCreatedAt(rs.getTimestamp("CreatedAt"));
        return p;
    }

    public List<Product> findAll() {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products ORDER BY ProductID DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Product findById(int id) {
        String sql = "SELECT * FROM Products WHERE ProductID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public List<Product> findByCategory(int categoryId) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE CategoryID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, categoryId);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> findByBrand(int brandId) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE BrandID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, brandId);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> searchByName(String keyword) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE ProductName LIKE ?";
        try {
            // Tự động gán wildcard '%' vào 2 đầu từ khóa
            ResultSet rs = JdbcUtil.executeQuery(sql, "%" + keyword + "%");
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Product> getNewestProducts(int top) {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT TOP (?) * FROM Products ORDER BY CreatedAt DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, top);
            while (rs.next()) { list.add(map(rs)); }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public boolean insert(Product p) {
        String sql = "INSERT INTO Products (ProductName, CategoryID, BrandID, OriginalPrice, SellPrice, DiscountPrice, MainImageURL, DescriptionText, WarrantyMonths, Status) VALUES (?,?,?,?,?,?,?,?,?,?)";
        return JdbcUtil.executeUpdate(sql, p.getProductName(), p.getCategoryID(), p.getBrandID(), p.getOriginalPrice(), p.getSellPrice(), p.getDiscountPrice(), p.getMainImageURL(), p.getDescriptionText(), p.getWarrantyMonths(), p.getStatus()) > 0;
    }

    public boolean update(Product p) {
        String sql = "UPDATE Products SET ProductName=?, CategoryID=?, BrandID=?, OriginalPrice=?, SellPrice=?, DiscountPrice=?, MainImageURL=?, DescriptionText=?, WarrantyMonths=?, Status=? WHERE ProductID=?";
        return JdbcUtil.executeUpdate(sql, p.getProductName(), p.getCategoryID(), p.getBrandID(), p.getOriginalPrice(), p.getSellPrice(), p.getDiscountPrice(), p.getMainImageURL(), p.getDescriptionText(), p.getWarrantyMonths(), p.getStatus(), p.getProductID()) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Products WHERE ProductID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }
}