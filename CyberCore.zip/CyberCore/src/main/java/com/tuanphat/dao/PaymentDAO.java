package com.tuanphat.dao;

import com.tuanphat.entity.Payment;
import com.tuanphat.util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

    private Payment map(ResultSet rs) throws SQLException {
        Payment p = new Payment();
        p.setPaymentID(rs.getInt("PaymentID"));
        p.setBillID(rs.getInt("BillID"));
        p.setPaymentMethod(rs.getString("PaymentMethod"));
        p.setPaymentStatus(rs.getString("PaymentStatus"));
        p.setAmount(rs.getBigDecimal("Amount"));
        p.setTransactionCode(rs.getString("TransactionCode"));
        p.setPaymentDate(rs.getTimestamp("PaymentDate"));
        p.setCreatedAt(rs.getTimestamp("CreatedAt"));
        return p;
    }

    public List<Payment> findAll() {
        List<Payment> list = new ArrayList<>();
        String sql = "SELECT * FROM Payments";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Payment findByBillId(int billId) {
        String sql = "SELECT * FROM Payments WHERE BillID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, billId);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public boolean insert(Payment p) {
        String sql = "INSERT INTO Payments (BillID, PaymentMethod, PaymentStatus, Amount, TransactionCode, PaymentDate) VALUES (?,?,?,?,?,?)";
        return JdbcUtil.executeUpdate(sql, p.getBillID(), p.getPaymentMethod(), p.getPaymentStatus(), p.getAmount(), p.getTransactionCode(), p.getPaymentDate()) > 0;
    }

    public boolean updateStatus(int billId, String status) {
        String sql = "UPDATE Payments SET PaymentStatus=? WHERE BillID=?";
        return JdbcUtil.executeUpdate(sql, status, billId) > 0;
    }
}