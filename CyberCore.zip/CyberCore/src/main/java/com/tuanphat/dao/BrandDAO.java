package com.tuanphat.dao;

import com.tuanphat.entity.Brand;
import com.tuanphat.util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BrandDAO {

    private Brand map(ResultSet rs) throws SQLException {
        Brand b = new Brand();
        b.setBrandID(rs.getInt("BrandID"));
        b.setBrandName(rs.getString("BrandName"));
        b.setLogoURL(rs.getString("LogoURL"));
        b.setCountry(rs.getString("Country"));
        return b;
    }

    public List<Brand> findAll() {
        List<Brand> list = new ArrayList<>();
        String sql = "SELECT * FROM Brands";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while(rs.next()){
                list.add(map(rs));
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public Brand findById(int id) {
        String sql = "SELECT * FROM Brands WHERE BrandID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if(rs.next()){
                return map(rs);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return null;
    }

    public boolean insert(Brand b) {
        String sql = "INSERT INTO Brands (BrandName, LogoURL, Country) VALUES (?,?,?)";
        return JdbcUtil.executeUpdate(sql, b.getBrandName(), b.getLogoURL(), b.getCountry()) > 0;
    }

    public boolean update(Brand b) {
        String sql = "UPDATE Brands SET BrandName=?, LogoURL=?, Country=? WHERE BrandID=?";
        return JdbcUtil.executeUpdate(sql, b.getBrandName(), b.getLogoURL(), b.getCountry(), b.getBrandID()) > 0;
    }

    public boolean delete(int id) {
        String sql = "DELETE FROM Brands WHERE BrandID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }
}