package com.tuanphat.dao;

import com.tuanphat.entity.Cart;
import com.tuanphat.util.JdbcUtil;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CartDAO {

    private Cart map(ResultSet rs) throws SQLException {
        Cart c = new Cart();
        c.setCartID(rs.getInt("CartID"));
        c.setUserID(rs.getInt("UserID"));
        c.setCreatedAt(rs.getTimestamp("CreatedAt"));
        c.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
        return c;
    }

    public Cart findById(int id) {
        String sql = "SELECT * FROM Cart WHERE CartID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Cart findByUserId(int userId) {
        String sql = "SELECT * FROM Cart WHERE UserID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, userId);
            if (rs.next()) {
                return map(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean createCart(int userId) {
        String sql = "INSERT INTO Cart(UserID) VALUES(?)";
        return JdbcUtil.executeUpdate(sql, userId) > 0;
    }

    public boolean delete(int cartId) {
        String sql = "DELETE FROM Cart WHERE CartID=?";
        return JdbcUtil.executeUpdate(sql, cartId) > 0;
    }
}