package com.tuanphat.dao;

import com.tuanphat.entity.RevenueReport;
import com.tuanphat.util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportDAO {

    // Controller sẽ gọi hàm này để lấy dữ liệu doanh thu từng tháng
    public List<RevenueReport> getMonthlyRevenue() {
        List<RevenueReport> list = new ArrayList<>();

        // Câu lệnh SQL nhóm doanh thu theo Tháng/Năm từ bảng Bills
        String query = "SELECT YEAR(OrderDate) AS ReportYear, MONTH(OrderDate) AS ReportMonth, " +
                "SUM(TotalAmount) AS TotalRevenue, COUNT(BillID) AS TotalOrders " +
                "FROM Bills WHERE OrderStatus = N'Completed' " +
                "GROUP BY YEAR(OrderDate), MONTH(OrderDate) " +
                "ORDER BY ReportYear DESC, ReportMonth DESC";

        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                int year = rs.getInt("ReportYear");
                int month = rs.getInt("ReportMonth");
                double revenue = rs.getDouble("TotalRevenue");
                int orders = rs.getInt("TotalOrders");

                // Thêm đối tượng vào danh sách
                list.add(new RevenueReport(year, month, revenue, orders));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Lấy số liệu tổng hợp cho 4 thẻ phía trên Dashboard
    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalRevenue", 0.0);
        stats.put("totalOrders", 0);
        stats.put("totalProducts", 0);
        stats.put("totalUsers", 0);

        String queryRevenue = "SELECT SUM(TotalAmount) FROM Bills WHERE OrderStatus = N'Completed'";
        String queryOrders = "SELECT COUNT(BillID) FROM Bills";
        String queryProducts = "SELECT COUNT(ProductID) FROM Products";
        String queryUsers = "SELECT COUNT(UserID) FROM Users WHERE RoleID = 2";

        try (Connection conn = JdbcUtil.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(queryRevenue); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalRevenue", rs.getDouble(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryOrders); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalOrders", rs.getInt(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryProducts); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalProducts", rs.getInt(1));
            }
            try (PreparedStatement ps = conn.prepareStatement(queryUsers); ResultSet rs = ps.executeQuery()) {
                if (rs.next()) stats.put("totalUsers", rs.getInt(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stats;
    }
}