package com.tuanphat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Review {
    private int reviewID;
    private int userID;
    private int productID;
    private User user; // Cần Entity User
    private Product product; // Cần Entity Product
    private int rating;
    private String comment;
    private Timestamp createdAt;
}