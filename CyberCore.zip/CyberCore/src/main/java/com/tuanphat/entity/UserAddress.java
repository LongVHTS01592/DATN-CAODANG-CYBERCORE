package com.tuanphat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAddress {
    private int addressID;
    private int userID;
    private String recipientName;
    private String phone;
    private String provinceName;
    private String districtName;
    private String wardName;
    private String detailedAddress;
    private boolean isDefault;

    // --- CÁC HÀM TỰ VIẾT ĐỂ VÔ HIỆU HÓA LỖI CỦA LOMBOK ---

    // 1. Dành cho giao diện JSP EL (gọi ${addr.isDefault} không bị lỗi 500)
    public boolean getIsDefault() {
        return isDefault;
    }

    // 2. Dành cho DAO (khớp với lệnh a.setIsDefault trong UserAddressDAO)
    public void setIsDefault(boolean isDefault) {
        this.isDefault = isDefault;
    }

    // 3. Backup thêm hàm chuẩn phòng hờ
    public boolean isDefault() {
        return isDefault;
    }
}