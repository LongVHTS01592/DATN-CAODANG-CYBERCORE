package com.tuanphat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private int userID;
    private String username;
    private String passwordHash;
    private String fullName;
    private String email;
    private String phone;
    private int roleID;
    private Role role; // Cần Entity Role
    private boolean isActive;
    private Timestamp createdAt;
    private Timestamp updatedAt;
}