package com.tuanphat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillDetail {
    private int billDetailID;
    private int billID;
    private int productID;
    private Product product; // Lưu ý: Cần có file Product.java tương ứng
    private int quantity;
    private BigDecimal priceAtSale;
}