package com.tuanphat.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductImage {
    private int imageID;
    private int productID;
    private String imageURL;
    private int displayOrder;
}