<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>

<%-- Nhúng Header và Menu đồng bộ với trang danh sách sản phẩm --%>
<jsp:include page="/src/main/webapp/layout/header.jsp" />
<jsp:include page="/src/main/webapp/layout/menu.jsp" />

<div class="container py-5" style="min-height: 75vh; max-width: 900px;">
    <div class="d-flex align-items-center mb-4 pb-2 border-bottom">
        <h3 class="fw-bold text-dark mb-0">
            <i class="fa-solid fa-clock-rotate-left text-purple me-2"></i>Lịch Sử Đơn Hàng Của Bạn
        </h3>
    </div>

    <%-- VÒNG LẶP DUYỆT DANH SÁCH ĐƠN HÀNG THẬT TỪ DATABASE --%>
    <c:forEach items="${userBills}" var="bill">
        <div class="card shadow-sm border-0 rounded-4 mb-4 bg-white">
            <div class="card-header bg-transparent border-bottom-0 py-3 px-4 d-flex justify-content-between align-items-center">
                <div>
                    <span class="fw-bold text-dark me-2">Mã đơn: #ORD-${bill.billID}</span>
                    <small class="text-muted">Ngày đặt: <fmt:formatDate value="${bill.orderDate}" pattern="dd/MM/yyyy HH:mm"/></small>
                </div>
                <div>
                    <c:choose>
                        <c:when test="${bill.orderStatus == 'Completed'}">
                            <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-2">Thành công</span>
                        </c:when>
                        <c:when test="${bill.orderStatus == 'Cancelled'}">
                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-3 py-2">Đã hủy</span>
                        </c:when>
                        <c:otherwise>
                            <span class="badge bg-warning-subtle text-warning border border-warning-subtle rounded-pill px-3 py-2">Đang xử lý</span>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>

            <div class="card-body px-4 pb-4 pt-0">
                    <%-- Chi tiết đơn hàng giả lập --%>
                <div class="d-flex justify-content-between align-items-center py-2">
                    <div class="d-flex gap-3 align-items-center">
                        <div class="bg-light p-2 rounded-3 border" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                            <i class="fa-solid fa-microchip fs-3 text-secondary"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-dark mb-1">Kiện hàng linh kiện máy tính</h6>
                            <small class="text-muted">Xem chi tiết khi kết nối hóa đơn thật</small>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3 mt-2 border-top">
                    <div>
                        <span class="text-secondary small">Tổng tiền thanh toán:</span>
                        <span class="fs-5 fw-bold text-danger ms-1">
                            <fmt:formatNumber value="${bill.totalAmount}" type="currency" currencySymbol="đ"/>
                        </span>
                    </div>
                    <div>
                            <%-- Nếu đơn đã thành công, cho phép chuyển hướng sang phân hệ đánh giá sản phẩm --%>
                        <c:if test="${bill.orderStatus == 'Completed'}">
                            <a href="${pageContext.request.contextPath}/review?productId=${bill.billID}" class="btn btn-dark btn-sm fw-bold rounded-pill px-3">
                                <i class="fa-regular fa-star me-1"></i> Viết đánh giá
                            </a>
                        </c:if>
                    </div>
                </div>
            </div>
        </div>
    </c:forEach>

    <%-- TRẠNG THÁI TRỐNG: Tự động hiển thị khi chưa có kết nối Servlet --%>
    <c:if test="${empty userBills}">
        <div class="text-center py-5 bg-white rounded-4 shadow-sm border my-4">
            <div class="mb-3">
                <i class="fa-solid fa-receipt text-muted" style="font-size: 4rem;"></i>
            </div>
            <h5 class="fw-bold text-dark">Bạn chưa có lịch sử mua hàng</h5>
            <p class="text-secondary small mb-4">Hãy lướt qua danh sách linh kiện cực hot của CyberCore và chọn cho mình sản phẩm ưng ý nhé!</p>
            <a href="${pageContext.request.contextPath}/product" class="btn btn-dark fw-bold px-4 py-2 rounded-pill text-uppercase small">
                <i class="fa-solid fa-bag-shopping me-2"></i>Mua sắm ngay thôi
            </a>
        </div>
    </c:if>
</div>

<%-- Nhúng Footer đồng bộ --%>
<jsp:include page="/src/main/webapp/layout/footer.jsp" />