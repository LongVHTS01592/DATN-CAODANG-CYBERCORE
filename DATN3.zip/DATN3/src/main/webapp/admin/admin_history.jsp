<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<jsp:useBean id="now" class="java.util.Date" />

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberCore Admin - Nhật ký doanh thu & Giao dịch</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        html, body { height: 100%; margin: 0; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; }
        .wrapper { display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #1e293b; color: #f8fafc; flex-shrink: 0; }
        .sidebar-brand { font-size: 1.3rem; font-weight: 700; color: #38bdf8; padding: 1.5rem 1rem; border-bottom: 1px solid #334155; }
        .nav-menu .nav-link { color: #94a3b8; padding: 0.8rem 1rem; display: flex; align-items: center; gap: 10px; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { background-color: #334155; color: #fff; border-radius: 0.25rem; }

        .main-content { flex-grow: 1; padding: 1.5rem; }
        .admin-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 0.5rem; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
        .text-cyan { color: #0284c7 !important; }
        .btn-cyan { background-color: #0284c7; color: white; }
        .btn-cyan:hover { background-color: #0369a1; color: white; }
        .code-tx { font-family: 'Courier New', Courier, monospace; font-weight: bold; color: #0f766e; background: #f0fdfa; padding: 2px 6px; border-radius: 4px; border: 1px solid #ccfbf1; }
    </style>
</head>
<body>

<div class="wrapper">
    <nav class="sidebar">
        <div class="sidebar-brand text-center mb-3">
            <i class="fa-solid fa-microchip"></i> CYBERCORE ADMIN
        </div>
        <ul class="nav flex-column nav-menu px-3 gap-1">
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive"></i> Sản phẩm</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-list-ul"></i> Danh mục</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar"></i> Đơn hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users"></i> Khách hàng</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa-solid fa-ticket"></i> Mã giảm giá</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa-solid fa-star"></i> Đánh giá</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link active" href="#"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử hệ thống</a>
            </li>
            <li class="nav-item mt-4 pt-3 border-top border-secondary">
                <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <main class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h2 fw-bold text-dark mb-1">Báo Cáo & Lịch Sử Tổng Toàn Sàn</h1>
                <p class="text-muted small">Phân tích dòng tiền giao dịch lịch sử vĩ mô dành cho người quản trị Admin.</p>
            </div>
            <div class="text-muted">
                <i class="fa-regular fa-calendar-check me-2"></i>Hôm nay: <fmt:formatDate value="${now}" pattern="dd/MM/yyyy" />
            </div>
        </div>

        <div class="card admin-card p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-chart-area text-cyan me-2"></i>Thống kê lịch sử tăng trưởng doanh thu (2026)</h5>
            <canvas id="adminRevenueChart" style="max-height: 250px;"></canvas>
        </div>

        <div class="card admin-card p-4 mb-4">
            <h6 class="fw-bold text-dark mb-3"><i class="fa-solid fa-filter me-2 text-cyan"></i>Bộ lọc đối soát nâng cao</h6>
            <form class="row g-3" method="GET" action="${pageContext.request.contextPath}/AdminHistoryController">
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary">Từ ngày</label>
                    <input type="date" name="fromDate" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary">Đến ngày</label>
                    <input type="date" name="toDate" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary">Cổng xử lý</label>
                    <select name="payMethod" class="form-select">
                        <option value="">-- Tất cả cổng thanh toán --</option>
                        <option value="COD">Tiền mặt (COD)</option>
                        <option value="VNPAY">Cổng VNPay</option>
                        <option value="MOMO">Ví MoMo</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-cyan w-100 fw-bold py-2"><i class="fa-solid fa-magnifying-glass me-2"></i>Lọc dữ liệu</button>
                </div>
            </form>
        </div>

        <div class="card admin-card">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                    <tr>
                        <th>Mã đơn</th>
                        <th>Ngày hoàn tất</th>
                        <th>Giá trị giao dịch</th>
                        <th>Phương thức</th>
                        <th>Mã đối soát hệ thống</th>
                        <th>Trạng thái sổ cái</th>
                    </tr>
                    </thead>
                    <tbody>
                    <%-- Vòng lặp lấy dữ liệu thật --%>
                    <c:forEach items="${adminHistoryList}" var="item">
                        <tr>
                            <td class="fw-bold">#ORD-${item.billID}</td>
                            <td><fmt:formatDate value="${item.orderDate}" pattern="dd/MM/yyyy HH:mm"/></td>
                            <td class="fw-bold text-dark"><fmt:formatNumber value="${item.totalAmount}" type="currency" currencySymbol="đ"/></td>
                            <td><span class="badge bg-secondary-subtle text-secondary border">${item.paymentMethod}</span></td>
                            <td>
                                <c:choose>
                                    <c:when test="${not empty item.transactionCode}">
                                        <span class="code-tx">${item.transactionCode}</span>
                                    </c:when>
                                    <c:otherwise><span class="text-muted small">N/A (Tiền mặt)</span></c:otherwise>
                                </c:choose>
                            </td>
                            <td><span class="badge bg-success">Đã Khớp Khấu Trừ</span></td>
                        </tr>
                    </c:forEach>

                    <%-- TRẠNG THÁI TRỐNG KHI CHƯA CHẠY SERVLET --%>
                    <c:if test="${empty adminHistoryList}">
                        <tr>
                            <td colspan="6" class="text-center text-muted py-5">
                                <i class="fa-solid fa-chart-pie fs-1 text-secondary mb-3 d-block"></i>
                                <h5 class="fw-bold text-dark mb-1">Chưa có dữ liệu nhật ký giao dịch lịch sử</h5>
                                <p class="small mb-0 text-secondary">Vui lòng kết nối với AdminHistoryController để nạp danh sách `adminHistoryList` từ SQL Server.</p>
                            </td>
                        </tr>
                    </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<script>
    const ctx = document.getElementById('adminRevenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6'],
            datasets: [{
                label: 'Doanh thu tích lũy (Triệu đ)',
                data: [45, 90, 180, 140, 290, 420],
                borderColor: '#0284c7',
                backgroundColor: 'rgba(2, 132, 199, 0.05)',
                borderWidth: 2.5,
                fill: true,
                tension: 0.25
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>