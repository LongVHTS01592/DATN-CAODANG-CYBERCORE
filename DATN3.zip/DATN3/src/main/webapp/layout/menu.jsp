<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-uppercase" href="${pageContext.request.contextPath}/home">
            <i class="fa-solid fa-microchip text-warning"></i> CyberCore
        </a>


        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>


        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="${pageContext.request.contextPath}/home">Trang chủ</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="${pageContext.request.contextPath}/product">Thực đơn linh kiện</a>
                </li>
            </ul>


            <ul class="navbar-nav align-items-center">
                <li class="nav-item me-3">
                    <a class="nav-link" href="${pageContext.request.contextPath}/cart">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </a>
                </li>


                <c:if test="${empty sessionScope.userAccount}">
                    <li class="nav-item">
                        <a class="nav-link" href="${pageContext.request.contextPath}/login">Đăng nhập</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-warning fw-bold px-4 ms-2 rounded-pill" href="${pageContext.request.contextPath}/register">Đăng ký</a>
                    </li>
                </c:if>


                <c:if test="${not empty sessionScope.userAccount}">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle fw-bold text-warning" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            Xin chào, ${sessionScope.userAccount.fullName}
                        </a>
                        <ul class="dropdown-menu shadow border-0 dropdown-menu-end">
                                <%-- THÊM NÚT LỊCH SỬ VÀO ĐÂY NÈ --%>
                            <li>
                                <a class="dropdown-item fw-semibold text-dark" href="${pageContext.request.contextPath}/customer/history">
                                    <i class="fa-solid fa-clock-rotate-left text-secondary me-2"></i>Lịch sử mua hàng
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger fw-semibold" href="${pageContext.request.contextPath}/login?action=logout">
                                    <i class="fa-solid fa-arrow-right-from-bracket me-2"></i>Đăng xuất
                                </a>
                            </li>
                        </ul>
                    </li>
                </c:if>
            </ul>
        </div>
    </div>
</nav>

