package CyberCore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Brand {
    private int brandID;
    private String brandName;
    private String logoURL;
    private String country;
}

