package CyberCore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bill {
    private int billID;
    private int userID;
    private User user; // Cần có thực thể User tương ứng
    private Timestamp orderDate;
    private String shippingRecipientName;
    private String shippingPhone;
    private String shippingAddressText;
    private BigDecimal totalAmount;
    private String orderStatus;
    private String notes;
    private List<BillDetail> billDetails; // Cần có thực thể BillDetail tương ứng
}

