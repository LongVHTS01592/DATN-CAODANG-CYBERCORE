package CyberCore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Category {
    private int categoryID;
    private String categoryName;
    private Integer parentCategoryID;
    private String description;
    private String slug;
}

