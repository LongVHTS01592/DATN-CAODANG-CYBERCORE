package CyberCore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartDetail {
    private int cartDetailID;
    private int cartID;
    private int productID;
    private Product product; // Cần Entity Product tương ứng
    private int quantity;
}

