package CyberCore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAddress {
    private int addressID;
    private int userID;
    private String recipientName;
    private String phone;
    private String provinceName;
    private String districtName;
    private String wardName;
    private String detailedAddress;
    private boolean isDefault;
}

