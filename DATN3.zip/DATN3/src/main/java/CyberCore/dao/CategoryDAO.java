package CyberCore.dao;

import CyberCore.entity.Category;
import CyberCore.util.JdbcUtil;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CategoryDAO {


    private Category map(ResultSet rs) throws SQLException {
        Category c = new Category();
        c.setCategoryID(rs.getInt("CategoryID"));
        c.setCategoryName(rs.getString("CategoryName"));


        int parent = rs.getInt("ParentCategoryID");
        if (rs.wasNull()) {
            c.setParentCategoryID(null);
        } else {
            c.setParentCategoryID(parent);
        }
        c.setDescription(rs.getString("Description"));
        c.setSlug(rs.getString("Slug"));
        return c;
    }


    public List<Category> findAll() {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT * FROM Categories";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }


    public Category findById(int id) {
        String sql = "SELECT * FROM Categories WHERE CategoryID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }


    public boolean insert(Category c) {
        String sql = "INSERT INTO Categories (CategoryName, ParentCategoryID, Description, Slug) VALUES (?,?,?,?)";
        // Sử dụng Object để xử lý linh hoạt việc truyền giá trị Integer (hoặc null)
        Object parentId = (c.getParentCategoryID() == null) ? null : c.getParentCategoryID();
        return JdbcUtil.executeUpdate(sql, c.getCategoryName(), parentId, c.getDescription(), c.getSlug()) > 0;
    }


    public boolean update(Category c) {
        String sql = "UPDATE Categories SET CategoryName=?, ParentCategoryID=?, Description=?, Slug=? WHERE CategoryID=?";
        Object parentId = (c.getParentCategoryID() == null) ? null : c.getParentCategoryID();
        return JdbcUtil.executeUpdate(sql, c.getCategoryName(), parentId, c.getDescription(), c.getSlug(), c.getCategoryID()) > 0;
    }


    public boolean delete(int id) {
        String sql = "DELETE FROM Categories WHERE CategoryID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }
}


