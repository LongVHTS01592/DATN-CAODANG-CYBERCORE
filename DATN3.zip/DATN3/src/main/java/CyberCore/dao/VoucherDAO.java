package CyberCore.dao;

import CyberCore.entity.Voucher;
import CyberCore.util.JdbcUtil;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class VoucherDAO {


    private Voucher map(ResultSet rs) throws SQLException {
        Voucher v = new Voucher();
        v.setVoucherID(rs.getInt("VoucherID"));
        v.setVoucherCode(rs.getString("VoucherCode"));
        v.setDescription(rs.getString("Description"));
        v.setDiscountType(rs.getString("DiscountType"));
        v.setDiscountValue(rs.getBigDecimal("DiscountValue"));
        v.setMaxDiscountAmount(rs.getBigDecimal("MaxDiscountAmount"));
        v.setMinOrderValue(rs.getBigDecimal("MinOrderValue"));
        v.setStartDate(rs.getTimestamp("StartDate"));
        v.setEndDate(rs.getTimestamp("EndDate"));
        v.setUsageLimit(rs.getInt("UsageLimit"));
        v.setUsedCount(rs.getInt("UsedCount"));
        v.setStatus(rs.getBoolean("Status"));
        return v;
    }


    public List<Voucher> findAll() {
        List<Voucher> list = new ArrayList<>();
        String sql = "SELECT * FROM Vouchers ORDER BY VoucherID DESC";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }


    public Voucher findById(int id) {
        String sql = "SELECT * FROM Vouchers WHERE VoucherID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }


    public Voucher findByCode(String code) {
        String sql = "SELECT * FROM Vouchers WHERE VoucherCode=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, code);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }


    public boolean insert(Voucher v) {
        String sql = "INSERT INTO Vouchers (VoucherCode, Description, DiscountType, DiscountValue, MaxDiscountAmount, MinOrderValue, StartDate, EndDate, UsageLimit, UsedCount, Status) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        return JdbcUtil.executeUpdate(sql, v.getVoucherCode(), v.getDescription(), v.getDiscountType(), v.getDiscountValue(), v.getMaxDiscountAmount(), v.getMinOrderValue(), v.getStartDate(), v.getEndDate(), v.getUsageLimit(), v.getUsedCount(), v.isStatus()) > 0;
    }
}


