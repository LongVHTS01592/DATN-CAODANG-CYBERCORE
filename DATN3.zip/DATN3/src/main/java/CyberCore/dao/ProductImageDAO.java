package CyberCore.dao;

import CyberCore.entity.ProductImage;
import CyberCore.util.JdbcUtil;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProductImageDAO {


    private ProductImage map(ResultSet rs) throws SQLException {
        ProductImage p = new ProductImage();
        p.setImageID(rs.getInt("ImageID"));
        p.setProductID(rs.getInt("ProductID"));
        p.setImageURL(rs.getString("ImageURL"));
        p.setDisplayOrder(rs.getInt("DisplayOrder"));
        return p;
    }


    public List<ProductImage> findAll() {
        List<ProductImage> list = new ArrayList<>();
        String sql = "SELECT * FROM ProductImages";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }


    public ProductImage findById(int id) {
        String sql = "SELECT * FROM ProductImages WHERE ImageID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, id);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }


    public List<ProductImage> findByProductId(int productId) {
        List<ProductImage> list = new ArrayList<>();
        String sql = "SELECT * FROM ProductImages WHERE ProductID=? ORDER BY DisplayOrder";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, productId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }


    public boolean insert(ProductImage p) {
        String sql = "INSERT INTO ProductImages (ProductID, ImageURL, DisplayOrder) VALUES (?,?,?)";
        return JdbcUtil.executeUpdate(sql, p.getProductID(), p.getImageURL(), p.getDisplayOrder()) > 0;
    }


    public boolean update(ProductImage p) {
        String sql = "UPDATE ProductImages SET ProductID=?, ImageURL=?, DisplayOrder=? WHERE ImageID=?";
        return JdbcUtil.executeUpdate(sql, p.getProductID(), p.getImageURL(), p.getDisplayOrder(), p.getImageID()) > 0;
    }


    public boolean delete(int id) {
        String sql = "DELETE FROM ProductImages WHERE ImageID=?";
        return JdbcUtil.executeUpdate(sql, id) > 0;
    }


    public boolean deleteByProductId(int productId) {
        String sql = "DELETE FROM ProductImages WHERE ProductID=?";
        return JdbcUtil.executeUpdate(sql, productId) > 0;
    }
}


