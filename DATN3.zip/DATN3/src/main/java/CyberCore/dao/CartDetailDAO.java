package CyberCore.dao;

import CyberCore.entity.CartDetail;
import CyberCore.util.JdbcUtil;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class CartDetailDAO {


    private CartDetail map(ResultSet rs) throws SQLException {
        CartDetail c = new CartDetail();
        c.setCartDetailID(rs.getInt("CartDetailID"));
        c.setCartID(rs.getInt("CartID"));
        c.setProductID(rs.getInt("ProductID"));
        c.setQuantity(rs.getInt("Quantity"));
        return c;
    }


    public List<CartDetail> findByCartId(int cartId) {
        List<CartDetail> list = new ArrayList<>();
        String sql = "SELECT * FROM CartDetails WHERE CartID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, cartId);
            while (rs.next()) {
                list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }


    public CartDetail findProductInCart(int cartId, int productId) {
        String sql = "SELECT * FROM CartDetails WHERE CartID=? AND ProductID=?";
        try {
            ResultSet rs = JdbcUtil.executeQuery(sql, cartId, productId);
            if (rs.next()) { return map(rs); }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }


    public boolean addToCart(int cartId, int productId, int quantity) {
        String sql = "INSERT INTO CartDetails(CartID,ProductID,Quantity) VALUES(?,?,?)";
        return JdbcUtil.executeUpdate(sql, cartId, productId, quantity) > 0;
    }


    public boolean updateQuantity(int cartDetailId, int quantity) {
        String sql = "UPDATE CartDetails SET Quantity=? WHERE CartDetailID=?";
        return JdbcUtil.executeUpdate(sql, quantity, cartDetailId) > 0;
    }


    public boolean removeItem(int cartDetailId) {
        String sql = "DELETE FROM CartDetails WHERE CartDetailID=?";
        return JdbcUtil.executeUpdate(sql, cartDetailId) > 0;
    }


    public boolean clearCart(int cartId) {
        String sql = "DELETE FROM CartDetails WHERE CartID=?";
        return JdbcUtil.executeUpdate(sql, cartId) > 0;
    }
}

