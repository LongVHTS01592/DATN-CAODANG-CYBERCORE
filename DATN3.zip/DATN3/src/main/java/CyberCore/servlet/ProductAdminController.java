package CyberCore.servlet;

import CyberCore.dao.ProductDAO;
import CyberCore.entity.Product;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;


@WebServlet("/ProductAdminController")
public class ProductAdminController extends HttpServlet {


    private final ProductDAO productDAO = new ProductDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");


        // Xử lý nút Xóa sản phẩm
        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                productDAO.delete(Integer.parseInt(idStr));
            }
            response.sendRedirect(request.getContextPath() + "/ProductAdminController");
            return;
        }


        // Mặc định Load danh sách sản phẩm
        List<Product> products = productDAO.findAll();
        request.setAttribute("products", products);
        request.getRequestDispatcher("/admin/admin_product.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");


        // Lấy dữ liệu từ Form Modal
        String name = request.getParameter("productName");
        String priceStr = request.getParameter("sellPrice");
        String imgUrl = request.getParameter("mainImageURL");
        String warrantyStr = request.getParameter("warrantyMonths");
        String desc = request.getParameter("description");


        Product p = new Product();
        p.setProductName(name);
        p.setSellPrice(new BigDecimal(priceStr != null && !priceStr.isEmpty() ? priceStr : "0"));
        p.setMainImageURL(imgUrl);
        p.setWarrantyMonths(Integer.parseInt(warrantyStr != null && !warrantyStr.isEmpty() ? warrantyStr : "12"));
        p.setDescriptionText(desc);
        p.setStatus(1); // 1 = Đang bán


        if ("insert".equals(action)) {
            productDAO.insert(p);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                p.setProductID(Integer.parseInt(idStr));
                productDAO.update(p);
            }
        }


        // Reset lại trang sau khi thao tác
        response.sendRedirect(request.getContextPath() + "/ProductAdminController");
    }
}


