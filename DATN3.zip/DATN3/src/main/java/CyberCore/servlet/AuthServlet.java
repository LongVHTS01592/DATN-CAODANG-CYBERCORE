package CyberCore.servlet;

import CyberCore.dao.UserDAO;
import CyberCore.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;


@WebServlet({"/login", "/register", "/LogoutController"})
public class AuthServlet extends HttpServlet {


    private final UserDAO userDAO = new UserDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();


        if ("/login".equals(path)) {
            String action = request.getParameter("action");
            if ("logout".equals(action)) {
                request.getSession().invalidate();
                response.sendRedirect(request.getContextPath() + "/home");
            } else {
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }
        } else if ("/register".equals(path)) {
            request.getRequestDispatcher("/views/register.jsp").forward(request, response);
        } else if ("/LogoutController".equals(path)) { // Nút đăng xuất từ giao diện Admin
            request.getSession().invalidate();
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();


        if ("/login".equals(path)) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");


            // Tái sử dụng hàm login của UserDAO (coi email như username)
            User user = userDAO.login(email, password);


            if (user != null) {
                HttpSession session = request.getSession();
                session.setAttribute("userAccount", user);


                // Phân quyền điều hướng (Giả sử RoleID 1 là Admin, 2 là Khách)
                if (user.getRoleID() == 1) {
                    response.sendRedirect(request.getContextPath() + "/admin/admin_dashboard.jsp");
                } else {
                    response.sendRedirect(request.getContextPath() + "/home");
                }
            } else {
                request.setAttribute("error", "Sai email hoặc mật khẩu!");
                request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            }


        } else if ("/register".equals(path)) {
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String password = request.getParameter("password");


            User newUser = new User();
            newUser.setUsername(email);
            newUser.setPasswordHash(password);
            newUser.setFullName(fullname);
            newUser.setEmail(email);
            newUser.setPhone(phone);
            newUser.setRoleID(2); // Set mặc định quyền Khách hàng
            newUser.setActive(true);


            if (userDAO.insert(newUser)) {
                response.sendRedirect(request.getContextPath() + "/login");
            } else {
                request.setAttribute("error", "Đăng ký thất bại, email có thể đã tồn tại!");
                request.getRequestDispatcher("/views/register.jsp").forward(request, response);
            }
        }
    }
}


