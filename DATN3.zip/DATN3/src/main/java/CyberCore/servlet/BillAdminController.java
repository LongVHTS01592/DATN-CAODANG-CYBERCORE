package CyberCore.servlet;

import CyberCore.dao.BillDAO;
import CyberCore.entity.Bill;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.util.List;


@WebServlet("/BillAdminController")
public class BillAdminController extends HttpServlet {


    private final BillDAO billDAO = new BillDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Load danh sách toàn bộ đơn hàng (Mới nhất lên đầu)
        List<Bill> bills = billDAO.findAll();
        request.setAttribute("bills", bills);


        request.getRequestDispatcher("/admin/admin_bill.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Xử lý form cập nhật trạng thái đơn hàng (Duyệt, Đang giao, Đã hủy...)
        String billIdStr = request.getParameter("billId");
        String newStatus = request.getParameter("orderStatus");


        if (billIdStr != null && newStatus != null) {
            billDAO.updateStatus(Integer.parseInt(billIdStr), newStatus);
        }


        response.sendRedirect(request.getContextPath() + "/BillAdminController");
    }
}


