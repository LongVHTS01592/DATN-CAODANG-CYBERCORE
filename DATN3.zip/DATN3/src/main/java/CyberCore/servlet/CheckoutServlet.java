package CyberCore.servlet;

import CyberCore.dao.BillDAO;
import CyberCore.dao.CartDAO;
import CyberCore.dao.CartDetailDAO;
import CyberCore.dao.ProductDAO;
import CyberCore.entity.Bill;
import CyberCore.entity.Cart;
import CyberCore.entity.CartDetail;
import CyberCore.entity.Product;
import CyberCore.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;


@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {


    private final CartDAO cartDAO = new CartDAO();
    private final CartDetailDAO cartDetailDAO = new CartDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final BillDAO billDAO = new BillDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");


        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }


        // Tính toán tổng tiền để show ra trang xác nhận
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart != null) {
            List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
            BigDecimal total = BigDecimal.ZERO;
            for (CartDetail cd : details) {
                Product p = productDAO.findById(cd.getProductID());
                cd.setProduct(p);
                if (p != null && p.getSellPrice() != null) {
                    BigDecimal subtotal = p.getSellPrice().multiply(new BigDecimal(cd.getQuantity()));
                    total = total.add(subtotal);
                }
            }
            request.setAttribute("cartDetails", details);
            request.setAttribute("totalAmount", total);
        }


        // Có thể bạn cần tạo thêm 1 file views/checkout.jsp để khách điền địa chỉ
        request.getRequestDispatcher("/views/checkout.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");


        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }


        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) return;


        List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
        if (details == null || details.isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/cart");
            return;
        }


        // Lấy thông tin giao hàng từ form
        String recipientName = request.getParameter("recipientName");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String notes = request.getParameter("notes");


        // Tính tổng tiền lần cuối trước khi ghi DB
        BigDecimal totalAmount = BigDecimal.ZERO;
        for (CartDetail cd : details) {
            Product p = productDAO.findById(cd.getProductID());
            if (p != null && p.getSellPrice() != null) {
                totalAmount = totalAmount.add(p.getSellPrice().multiply(new BigDecimal(cd.getQuantity())));
            }
        }


        // Tạo hóa đơn
        Bill bill = new Bill();
        bill.setUserID(user.getUserID());
        bill.setShippingRecipientName(recipientName);
        bill.setShippingPhone(phone);
        bill.setShippingAddressText(address);
        bill.setTotalAmount(totalAmount);
        bill.setOrderStatus("Pending"); // Trạng thái chờ duyệt
        bill.setNotes(notes);


        int billId = billDAO.insert(bill);


        if (billId > 0) {
            // Đặt hàng thành công -> Xóa sạch giỏ hàng
            cartDetailDAO.clearCart(cart.getCartID());
            response.sendRedirect(request.getContextPath() + "/home?msg=order_success");
        } else {
            response.sendRedirect(request.getContextPath() + "/checkout?error=true");
        }
    }
}


