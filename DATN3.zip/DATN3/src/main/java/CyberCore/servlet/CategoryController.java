package CyberCore.servlet;

import CyberCore.dao.CategoryDAO;
import CyberCore.entity.Category;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.util.List;


@WebServlet("/CategoryController")
public class CategoryController extends HttpServlet {


    private final CategoryDAO categoryDAO = new CategoryDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");


        // Bắt sự kiện Xóa hoặc Load dữ liệu lên Form Sửa
        if ("edit".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                Category cat = categoryDAO.findById(Integer.parseInt(idStr));
                request.setAttribute("categoryEdit", cat); // Đẩy dữ liệu cũ lên form
            }
        } else if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                categoryDAO.delete(Integer.parseInt(idStr));
                response.sendRedirect(request.getContextPath() + "/CategoryController");
                return;
            }
        }


        // Luôn load lại danh sách sau mọi thao tác
        List<Category> listCategories = categoryDAO.findAll();
        request.setAttribute("listCategories", listCategories);
        request.getRequestDispatcher("/admin/admin_category.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Nhận dữ liệu từ form thêm/sửa
        String action = request.getParameter("action");
        String name = request.getParameter("name");
        String parentIdStr = request.getParameter("parentId");
        String slug = request.getParameter("slug");


        Category c = new Category();
        c.setCategoryName(name);
        c.setSlug(slug);


        // Xử lý Danh mục cha (nếu có chọn)
        if (parentIdStr != null && !parentIdStr.trim().isEmpty()) {
            c.setParentCategoryID(Integer.parseInt(parentIdStr));
        }


        if ("insert".equals(action)) {
            categoryDAO.insert(c);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.trim().isEmpty()) {
                c.setCategoryID(Integer.parseInt(idStr));
                categoryDAO.update(c);
            }
        }


        // Sau khi Insert/Update xong thì reload lại trang
        response.sendRedirect(request.getContextPath() + "/CategoryController");
    }
}

