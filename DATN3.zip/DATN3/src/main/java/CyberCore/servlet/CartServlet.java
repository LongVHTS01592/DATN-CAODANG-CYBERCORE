package CyberCore.servlet;

import CyberCore.dao.CartDAO;
import CyberCore.dao.CartDetailDAO;
import CyberCore.dao.ProductDAO;
import CyberCore.entity.Cart;
import CyberCore.entity.CartDetail;
import CyberCore.entity.Product;
import CyberCore.entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


import java.io.IOException;
import java.util.List;


@WebServlet("/cart")
public class CartServlet extends HttpServlet {


    private final CartDAO cartDAO = new CartDAO();
    private final CartDetailDAO cartDetailDAO = new CartDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");


        // Yêu cầu đăng nhập mới được xem giỏ hàng
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }


        // Lấy giỏ hàng của User, nếu chưa có thì tạo mới
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }


        // Kéo danh sách chi tiết và thông tin sản phẩm tương ứng
        List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
        for (CartDetail cd : details) {
            Product p = productDAO.findById(cd.getProductID());
            cd.setProduct(p);
        }


        request.setAttribute("cartDetails", details);
        request.getRequestDispatcher("/views/cart.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");


        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }


        String action = request.getParameter("action");
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }


        // Xử lý các thao tác: Thêm, Cập nhật số lượng, Xóa
        if ("add".equals(action)) {
            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));


            CartDetail existing = cartDetailDAO.findProductInCart(cart.getCartID(), productId);
            if (existing != null) {
                cartDetailDAO.updateQuantity(existing.getCartDetailID(), existing.getQuantity() + quantity);
            } else {
                cartDetailDAO.addToCart(cart.getCartID(), productId, quantity);
            }
        } else if ("update".equals(action)) {
            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            cartDetailDAO.updateQuantity(cartDetailId, quantity);
        } else if ("remove".equals(action)) {
            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            cartDetailDAO.removeItem(cartDetailId);
        }


        response.sendRedirect(request.getContextPath() + "/cart");
    }
}


