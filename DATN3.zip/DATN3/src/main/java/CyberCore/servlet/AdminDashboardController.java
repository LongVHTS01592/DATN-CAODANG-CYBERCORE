package CyberCore.servlet;

import CyberCore.dao.BillDAO;
import CyberCore.entity.Bill;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;


@WebServlet("/admin/dashboard")
public class AdminDashboardController extends HttpServlet {


    private final BillDAO billDAO = new BillDAO();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Tính toán các chỉ số thống kê
        BigDecimal totalRevenue = billDAO.getTotalRevenue();
        int pendingOrders = billDAO.countPendingOrders();
        List<Bill> recentOrders = billDAO.getRecentOrders(5);


        // Đẩy dữ liệu sang View
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("newOrdersCount", pendingOrders);
        request.setAttribute("recentOrders", recentOrders);


        // Điều hướng về giao diện
        request.getRequestDispatcher("/admin/admin_dashboard.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}


