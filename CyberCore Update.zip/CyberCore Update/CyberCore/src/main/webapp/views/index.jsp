<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<jsp:include page="/layout/header.jsp" />
<jsp:include page="/layout/menu.jsp" />

<div class="hero-banner text-center" style="min-height: 80vh; display: flex; flex-direction: column; justify-content: center;">
  <div class="container">
    <h1 class="display-4 fw-bold">Build PC Đỉnh Cao <br><span class="text-warning">Theo Cách Của Bạn</span></h1>
    <p class="lead mt-3">Nơi những cỗ máy sức mạnh bắt đầu từ một linh kiện nhỏ nhất.</p>
    <a href="${pageContext.request.contextPath}/product" class="btn btn-warning btn-lg mt-4 fw-bold rounded-pill px-4">KHÁM PHÁ MENU &rarr;</a>
  </div>
</div>

<jsp:include page="/layout/footer.jsp" />