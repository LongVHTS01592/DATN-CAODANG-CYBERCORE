<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý Voucher</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        html, body {
            height: 100%;
            margin: 0;
        }

        body {
            background: #f4f6f9;
            font-family: 'Segoe UI', sans-serif;
        }

        .wrapper {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #1e293b;
            color: white;
            flex-shrink: 0;
        }

        .sidebar-brand {
            font-size: 1.3rem;
            font-weight: 700;
            color: #38bdf8;
            padding: 1.5rem 1rem;
            border-bottom: 1px solid #334155;
        }

        .nav-menu .nav-link {
            color: #94a3b8;
            padding: .8rem 1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .nav-menu .nav-link:hover,
        .nav-menu .nav-link.active {
            background: #334155;
            color: white;
            border-radius: 4px;
        }

        .main-content {
            flex-grow: 1;
            padding: 25px;
        }

        .card-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,.08);
        }
    </style>
</head>
<body>

<div class="wrapper">

    <nav class="sidebar">

        <div class="sidebar-brand text-center mb-3">
            <i class="fa-solid fa-microchip"></i>
            CYBERCORE ADMIN
        </div>

        <ul class="nav flex-column nav-menu px-3 gap-1">

            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard">
                    <i class="fa-solid fa-house"></i> Dashboard
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController">
                    <i class="fa-solid fa-box-archive"></i> Sản phẩm
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/CategoryController">
                    <i class="fa-solid fa-list-ul"></i> Danh mục
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/BillAdminController">
                    <i class="fa-solid fa-file-invoice-dollar"></i> Đơn hàng
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link active" href="${pageContext.request.contextPath}/voucher">
                    <i class="fa-solid fa-ticket"></i> Voucher
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="${pageContext.request.contextPath}/UserController">
                    <i class="fa-solid fa-users"></i> Khách hàng
                </a>
            </li>

            <li class="nav-item mt-4 pt-3 border-top border-secondary">
                <a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất
                </a>
            </li>

        </ul>

    </nav>

    <main class="main-content">

        <div class="card-box">

            <h2 class="mb-4">Quản lý Voucher</h2>

            <c:if test="${not empty error}">
                <div class="alert alert-danger">
                        ${error}
                </div>
            </c:if>

            <form action="voucher" method="post">

                <input type="hidden" name="voucherID" value="${voucher.voucherID}">

                <div class="row">

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Mã Voucher</label>
                        <input type="text" name="voucherCode" class="form-control" value="${voucher.voucherCode}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Loại giảm giá</label>
                        <select name="discountType" class="form-select">
                            <option value="PERCENT" <c:if test="${voucher.discountType eq 'PERCENT'}">selected</c:if>>PERCENT</option>
                            <option value="AMOUNT" <c:if test="${voucher.discountType eq 'AMOUNT'}">selected</c:if>>AMOUNT</option>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Giá trị giảm</label>
                        <input type="number" step="0.01" min="1" name="discountValue" class="form-control" value="${voucher.discountValue}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Giảm tối đa</label>
                        <input type="number" step="0.01" min="0" name="maxDiscountAmount" class="form-control" value="${voucher.maxDiscountAmount}">
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Đơn tối thiểu</label>
                        <input type="number" step="0.01" min="0" name="minOrderValue" class="form-control" value="${voucher.minOrderValue}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Số lượt sử dụng</label>
                        <input type="number" min="1" name="usageLimit" class="form-control" value="${voucher.usageLimit}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ngày bắt đầu</label>
                        <input type="datetime-local" name="startDate" class="form-control" value="${startDateValue}" required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Ngày kết thúc</label>
                        <input type="datetime-local" name="endDate" class="form-control" value="${endDateValue}" required>
                    </div>

                    <div class="col-md-12 mb-3">
                        <label class="form-label">Mô tả</label>
                        <textarea name="description" class="form-control" rows="3" required>${voucher.description}</textarea>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="status" class="form-check-input" id="statusVoucher"
                                   <c:if test="${voucher == null || voucher.status}">checked</c:if>>
                            <label class="form-check-label" for="statusVoucher">Hoạt động</label>
                        </div>
                    </div>

                </div>

                <c:choose>
                    <c:when test="${voucher != null}">
                        <button type="submit" class="btn btn-warning" name="action" value="update">Cập nhật</button>
                        <a href="voucher" class="btn btn-secondary">Hủy</a>
                    </c:when>
                    <c:otherwise>
                        <button type="submit" class="btn btn-primary" name="action" value="add">Thêm mới</button>
                    </c:otherwise>
                </c:choose>

            </form>

            <hr class="my-4">

            <h4>Danh sách Voucher</h4>

            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Code</th>
                        <th>Loại</th>
                        <th>Giảm</th>
                        <th>Đơn tối thiểu</th>
                        <th>Đã dùng</th>
                        <th>Trạng thái</th>
                        <th width="150">Thao tác</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach items="${voucherList}" var="v">
                        <tr>
                            <td>${v.voucherID}</td>
                            <td><strong>${v.voucherCode}</strong></td>
                            <td>${v.discountType}</td>
                            <td>${v.discountValue}</td>
                            <td>${v.minOrderValue}</td>
                            <td>${v.usedCount}/${v.usageLimit}</td>
                            <td>
                                <c:choose>
                                    <c:when test="${v.status}">
                                        <span class="badge bg-success">Active</span>
                                    </c:when>
                                    <c:otherwise>
                                        <span class="badge bg-danger">Inactive</span>
                                    </c:otherwise>
                                </c:choose>
                            </td>
                            <td>
                                <a href="voucher?action=edit&id=${v.voucherID}" class="btn btn-warning btn-sm">Sửa</a>
                                <a href="voucher?action=delete&id=${v.voucherID}" class="btn btn-danger btn-sm"
                                   onclick="return confirm('Bạn có chắc muốn xóa voucher này?')">Xóa</a>
                            </td>
                        </tr>
                    </c:forEach>
                    </tbody>
                </table>
            </div>

        </div> </main> </div> </body>
</html>