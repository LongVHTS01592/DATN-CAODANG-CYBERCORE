<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Báo Cáo Doanh Thu</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="container mt-5">

<h2 class="mb-4 text-center">Báo Cáo Thống Kê Doanh Thu</h2>

<div class="table-responsive mb-5 shadow-sm">
    <table class="table table-bordered table-hover align-middle">
        <thead class="table-dark">
        <tr>
            <th class="text-center">Tháng / Năm</th>
            <th class="text-center">Tổng số đơn hàng</th>
            <th class="text-end">Tổng doanh thu (VNĐ)</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="item" items="${revenueList}">
            <tr>
                <td class="text-center">${item.reportMonth} / ${item.reportYear}</td>
                <td class="text-center">${item.totalOrders}</td>
                <td class="text-end">${item.totalRevenue}</td>
            </tr>
        </c:forEach>

        <c:if test="${empty revenueList}">
            <tr>
                <td colspan="3" class="text-center text-danger">Chưa có dữ liệu doanh thu nào!</td>
            </tr>
        </c:if>
        </tbody>
    </table>
</div>

<div style="width: 80%; margin: 0 auto;">
    <canvas id="revenueChart"></canvas>
</div>

<script>
    // Tạo 2 mảng rỗng để chứa dữ liệu vẽ biểu đồ
    const chartLabels = [];
    const chartData = [];

    // Lấy dữ liệu từ Java (qua JSTL) đẩy vào mảng Javascript
    <c:forEach var="item" items="${revenueList}">
    // Hàm unshift() giúp đẩy dữ liệu lên đầu mảng.
    // Vì SQL đang sắp xếp từ Mới -> Cũ, ta đảo lại để biểu đồ chạy từ Cũ -> Mới
    chartLabels.unshift('${item.reportMonth}/${item.reportYear}');
    chartData.unshift(${item.totalRevenue});
    </c:forEach>

    // Cấu hình vẽ biểu đồ
    const ctx = document.getElementById('revenueChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar', // Dạng biểu đồ cột (bạn có thể thử đổi thành 'line' cho biểu đồ đường)
        data: {
            labels: chartLabels, // Trục X: Tháng/Năm
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: chartData, // Trục Y: Tổng tiền
                backgroundColor: 'rgba(54, 162, 235, 0.6)', // Màu nền cột
                borderColor: 'rgba(54, 162, 235, 1)',       // Màu viền cột
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true // Đảm bảo trục Y luôn bắt đầu từ 0
                }
            }
        }
    });
</script>
</body>
</html>