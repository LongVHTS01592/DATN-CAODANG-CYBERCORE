<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<c:if test="${empty sessionScope.userAccount || sessionScope.userAccount.roleID > 2}"><c:redirect url="/login"/></c:if>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>CyberCore Admin - Quản Lý Đơn Hàng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .sidebar { min-height: 100vh; background-color: #1e293b; color: #f8fafc; }
        .sidebar-brand { font-size: 1.3rem; font-weight: 700; color: #38bdf8; padding: 1.5rem 1rem; border-bottom: 1px solid #334155; }
        .nav-menu .nav-link { color: #94a3b8; padding: 0.8rem 1rem; display: flex; align-items: center; gap: 10px; transition: all 0.3s; }
        .nav-menu .nav-link:hover, .nav-menu .nav-link.active { background-color: #334155; color: #fff; border-radius: 0.25rem; }
    </style>
</head>
<body>

<div class="container-fluid p-0">
    <div class="row g-0">
        <nav class="col-md-3 col-lg-2 d-md-block sidebar collapse px-3">
            <div class="sidebar-brand text-center mb-3"><i class="fa-solid fa-microchip"></i> CYBERCORE ADMIN</div>
            <div class="position-sticky">
                <ul class="nav flex-column nav-menu gap-1">
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/admin/dashboard"><i class="fa-solid fa-house"></i> Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/ProductAdminController"><i class="fa-solid fa-box-archive"></i> Sản phẩm</a></li>
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/CategoryController"><i class="fa-solid fa-list-ul"></i> Danh mục</a></li>
                    <li class="nav-item"><a class="nav-link active" href="${pageContext.request.contextPath}/BillAdminController"><i class="fa-solid fa-file-invoice-dollar"></i> Đơn hàng</a></li>
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/voucher"><i class="fa-solid fa-ticket"></i>Voucher</a></li>
                    <li class="nav-item"><a class="nav-link" href="${pageContext.request.contextPath}/UserController"><i class="fa-solid fa-users"></i> Khách hàng</a></li>
                    <li class="nav-item mt-4 pt-3 border-top border-secondary"><a class="nav-link text-danger" href="${pageContext.request.contextPath}/LogoutController"><i class="fa-solid fa-arrow-right-from-bracket"></i> Đăng xuất</a></li>
                </ul>
            </div>
        </nav>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
            <h2 class="fw-bold mb-4">Quản lý Đơn hàng</h2>
            <div class="card shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark"><tr><th>Mã ĐH</th><th>Khách hàng</th><th>Ngày đặt</th><th>Tổng tiền</th><th>Trạng thái</th><th class="text-center">Thao tác</th></tr></thead>
                        <tbody>
                        <c:forEach items="${bills}" var="b">
                            <tr>
                                <td>#${b.billID}</td><td>${b.shippingRecipientName}</td>
                                <td><fmt:formatDate value="${b.orderDate}" pattern="dd/MM/yyyy HH:mm" /></td>
                                <td class="fw-bold text-primary"><fmt:formatNumber value="${b.totalAmount}" type="currency" currencySymbol="đ"/></td>
                                <td><span class="badge ${b.orderStatus == 'Pending' ? 'bg-warning text-dark' : (b.orderStatus == 'Completed' ? 'bg-success' : 'bg-info')}">${b.orderStatus}</span></td>
                                <td class="text-center"><button class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#orderDetailModal${b.billID}"><i class="fa-solid fa-eye"></i></button></td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<c:forEach items="${bills}" var="b">
    <div class="modal fade" id="orderDetailModal${b.billID}" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title">Chi tiết đơn hàng #${b.billID}</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Người nhận:</strong> ${b.shippingRecipientName} - <strong>SĐT:</strong> ${b.shippingPhone}</p>
                    <p><strong>Địa chỉ:</strong> ${b.shippingAddressText}</p>
                    <hr>
                    <table class="table table-sm table-bordered">
                        <thead class="table-light"><tr><th>Sản phẩm</th><th>SL</th><th>Giá chốt</th></tr></thead>
                        <tbody>
                            <%-- Đổ danh sách chi tiết (Cần BillDAO load kèm details) --%>
                        <c:forEach items="${b.details}" var="detail">
                            <tr>
                                <td>${detail.product.productName}</td>
                                <td>${detail.quantity}</td>
                                <td class="text-danger fw-bold"><fmt:formatNumber value="${detail.priceAtSale}" type="currency" currencySymbol="đ"/></td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty b.details}">
                            <tr><td colspan="3" class="text-center text-muted">Vui lòng cập nhật DAO để nạp List Detail.</td></tr>
                        </c:if>
                        </tbody>
                    </table>
                    <form action="${pageContext.request.contextPath}/BillAdminController" method="post" class="mt-3">
                        <input type="hidden" name="billId" value="${b.billID}">
                        <div class="input-group">
                            <span class="input-group-text fw-bold">Trạng thái</span>
                            <select name="orderStatus" class="form-select">
                                <option value="Pending" ${b.orderStatus == 'Pending' ? 'selected' : ''}>Chờ duyệt</option>
                                <option value="Processing" ${b.orderStatus == 'Processing' ? 'selected' : ''}>Đang giao</option>
                                <option value="Completed" ${b.orderStatus == 'Completed' ? 'selected' : ''}>Hoàn thành</option>
                                <option value="Cancelled" ${b.orderStatus == 'Cancelled' ? 'selected' : ''}>Đã hủy</option>
                            </select>
                            <button type="submit" class="btn btn-primary fw-bold">Cập nhật</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</c:forEach>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>