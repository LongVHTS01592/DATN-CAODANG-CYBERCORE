package servlet;

import dao.CartDAO;
import dao.CartDetailDAO;
import dao.ProductDAO;
import dao.VoucherDAO;
import entity.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    private final CartDAO cartDAO = new CartDAO();
    private final CartDetailDAO cartDetailDAO = new CartDetailDAO();
    private final ProductDAO productDAO = new ProductDAO();
    private final VoucherDAO voucherDAO = new VoucherDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }

        List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());
        double totalPrice = 0;

        for (CartDetail cd : details) {
            Product p = productDAO.findById(cd.getProductID());
            cd.setProduct(p);
            if (p != null && p.getSellPrice() != null) {
                totalPrice += p.getSellPrice().doubleValue() * cd.getQuantity();
            }
        }

        // --- Tự động kiểm tra và tính toán lại Voucher hiện tại nếu có trong session ---
        String currentVoucherCode = (String) session.getAttribute("voucherCode");
        if (currentVoucherCode != null) {
            Voucher voucher = voucherDAO.findByCode(currentVoucherCode);

            if (voucher == null || BigDecimal.valueOf(totalPrice).compareTo(voucher.getMinOrderValue()) < 0) {
                session.removeAttribute("discountAmount");
                session.removeAttribute("voucherCode");
            } else {
                double discount = 0;
                if ("PERCENT".equals(voucher.getDiscountType())) {
                    discount = totalPrice * voucher.getDiscountValue().doubleValue() / 100;
                    if (voucher.getMaxDiscountAmount() != null) {
                        discount = Math.min(discount, voucher.getMaxDiscountAmount().doubleValue());
                    }
                } else {
                    discount = voucher.getDiscountValue().doubleValue();
                }

                if (discount > totalPrice) {
                    discount = totalPrice;
                }
                session.setAttribute("discountAmount", discount);
            }
        }

        // --- Đưa dữ liệu từ Session vào Request theo yêu cầu của bạn ---
        request.setAttribute("discountAmount", session.getAttribute("discountAmount"));
        request.setAttribute("voucherCode", session.getAttribute("voucherCode"));
        request.setAttribute("voucherMessage", session.getAttribute("voucherMessage"));

        // Xóa thông tin tin nhắn trong session ngay sau khi gán để tránh hiện tượng F5 bị lặp thông báo
        session.removeAttribute("voucherMessage");

        request.setAttribute("totalPrice", totalPrice);
        request.setAttribute("cartDetails", details);
        request.getRequestDispatcher("/views/cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");
        Cart cart = cartDAO.findByUserId(user.getUserID());
        if (cart == null) {
            cartDAO.createCart(user.getUserID());
            cart = cartDAO.findByUserId(user.getUserID());
        }

        if ("add".equals(action)) {
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int productId = Integer.parseInt(request.getParameter("productId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            CartDetail existing = cartDetailDAO.findProductInCart(cart.getCartID(), productId);
            if (existing != null) {
                cartDetailDAO.updateQuantity(existing.getCartDetailID(), existing.getQuantity() + quantity);
            } else {
                cartDetailDAO.addToCart(cart.getCartID(), productId, quantity);
            }
            session.setAttribute("voucherMessage", "Đã cập nhật giỏ hàng!");

        } else if ("update".equals(action)) {
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));
            cartDetailDAO.updateQuantity(cartDetailId, quantity);
            session.setAttribute("voucherMessage", "Đã cập nhật số lượng!");

        } else if ("remove".equals(action)) {
            session.removeAttribute("discountAmount");
            session.removeAttribute("voucherCode");

            int cartDetailId = Integer.parseInt(request.getParameter("cartDetailId"));
            cartDetailDAO.removeItem(cartDetailId);
            session.setAttribute("voucherMessage", "Đã xóa sản phẩm khỏi giỏ hàng!");

        } else if ("applyVoucher".equals(action)) {
            String code = request.getParameter("voucherCode");
            Voucher voucher = voucherDAO.findByCode(code);

            if (voucher == null) {
                session.removeAttribute("discountAmount");
                session.removeAttribute("voucherCode");
                session.setAttribute("voucherMessage", "Voucher không tồn tại hoặc đã hết hạn!");
            } else {
                double totalAmount = 0;
                List<CartDetail> details = cartDetailDAO.findByCartId(cart.getCartID());

                for (CartDetail item : details) {
                    Product p = productDAO.findById(item.getProductID());
                    if (p != null && p.getSellPrice() != null) {
                        totalAmount += p.getSellPrice().doubleValue() * item.getQuantity();
                    }
                }

                if (BigDecimal.valueOf(totalAmount).compareTo(voucher.getMinOrderValue()) < 0) {
                    session.removeAttribute("discountAmount");
                    session.removeAttribute("voucherCode");
                    session.setAttribute("voucherMessage", "Đơn hàng chưa đạt giá trị tối thiểu!");
                } else {
                    double discount = 0;

                    if ("PERCENT".equals(voucher.getDiscountType())) {
                        discount = totalAmount * voucher.getDiscountValue().doubleValue() / 100;

                        if (voucher.getMaxDiscountAmount() != null) {
                            discount = Math.min(discount, voucher.getMaxDiscountAmount().doubleValue());
                        }
                    } else {
                        discount = voucher.getDiscountValue().doubleValue();
                    }

                    if (discount > totalAmount) {
                        discount = totalAmount;
                    }

                    session.setAttribute("discountAmount", discount);
                    session.setAttribute("voucherCode", voucher.getVoucherCode());
                    session.setAttribute("voucherMessage", "Áp dụng voucher thành công!");
                }
            }
        }

        response.sendRedirect(request.getContextPath() + "/cart");
    }
}