package servlet;

import dao.ReportDAO;
import entity.RevenueReport;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@WebServlet(name = "RevenueController", urlPatterns = {"/admin/revenue"})
public class RevenueController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Khởi tạo đối tượng lớp DAO
        ReportDAO reportDAO = new ReportDAO();

        // 2. Lấy số liệu tổng hợp (Tổng tiền, tổng đơn, tổng SP, tổng User) cho 4 thẻ phía trên
        Map<String, Object> stats = reportDAO.getDashboardStats();
        request.setAttribute("stats", stats);

        // 3. Lấy danh sách thống kê doanh thu theo từng tháng cho bảng và biểu đồ
        List<RevenueReport> revenueList = reportDAO.getMonthlyRevenue();
        request.setAttribute("revenueList", revenueList);

        // 4. Chuyển tiếp (forward) yêu cầu sang đúng thư mục chứa giao diện Admin của bạn
        // Cập nhật lại đường dẫn từ "/admin/revenue-report.jsp" thành "/views/admin/index.jsp"
        // (Hoặc tên file JSP hiển thị Dashboard hiện tại của bạn)
        request.getRequestDispatcher("/views/admin/index.jsp").forward(request, response);
    }
}