package servlet;

import dao.ProductDAO;
import entity.Product;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/ProductAdminController")
public class ProductAdminController extends HttpServlet {

    private final ProductDAO productDAO = new ProductDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // CHỐT CHẶN BẢO MẬT ADMIN
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("userAccount");
        if (user == null || user.getRoleID() > 2) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                productDAO.delete(Integer.parseInt(idStr));
            }
            response.sendRedirect(request.getContextPath() + "/ProductAdminController");
            return;
        } else if ("edit".equals(action)) {
            // Lấy dữ liệu cũ đổ lên form Modal Sửa
            String idStr = request.getParameter("id");
            if (idStr != null) {
                Product p = productDAO.findById(Integer.parseInt(idStr));
                request.setAttribute("productEdit", p);
            }
        }

        List<Product> products = productDAO.findAll();
        request.setAttribute("products", products);
        request.getRequestDispatcher("/admin/admin_product.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8"); // Fix lỗi font tiếng Việt

        String action = request.getParameter("action");
        String name = request.getParameter("productName");
        String priceStr = request.getParameter("sellPrice");
        String imgUrl = request.getParameter("mainImageURL");
        String warrantyStr = request.getParameter("warrantyMonths");
        String desc = request.getParameter("description");

        Product p = new Product();
        p.setProductName(name);
        p.setSellPrice(new BigDecimal(priceStr != null && !priceStr.isEmpty() ? priceStr : "0"));

        // Database yêu cầu Not Null, set tạm giá trị mặc định là 1
        p.setCategoryID(1);
        p.setBrandID(1);
        p.setOriginalPrice(new BigDecimal("0")); // Set tạm giá nhập

        p.setMainImageURL(imgUrl);
        p.setWarrantyMonths(Integer.parseInt(warrantyStr != null && !warrantyStr.isEmpty() ? warrantyStr : "12"));
        p.setDescriptionText(desc);
        p.setStatus(1);

        if ("insert".equals(action)) {
            productDAO.insert(p);
        } else if ("update".equals(action)) {
            String idStr = request.getParameter("id");
            if (idStr != null) {
                p.setProductID(Integer.parseInt(idStr));
                productDAO.update(p);
            }
        }

        response.sendRedirect(request.getContextPath() + "/ProductAdminController");
    }
}